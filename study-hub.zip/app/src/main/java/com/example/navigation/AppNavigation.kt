package com.example.navigation

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.ui.MainUiState
import com.example.ui.MainViewModel
import com.example.ui.components.EditStudentProfileDialog
import com.example.ui.components.GradeSelectorHeader
import com.example.ui.components.StudentProfileDialog
import com.example.ui.screens.*

@Composable
fun StudyHubNavigationGraph(
    viewModel: MainViewModel,
    uiState: MainUiState,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Synchronize auth state with navigation destinations safely
    LaunchedEffect(uiState.currentStudent) {
        val isLoggedIn = uiState.currentStudent != null
        if (!isLoggedIn && currentRoute != Screen.Auth.route && currentRoute != null) {
            try {
                navController.navigate(Screen.Auth.route) {
                    popUpTo(Screen.Dashboard.route) { inclusive = false }
                    launchSingleTop = true
                }
            } catch (e: Exception) {
                android.util.Log.e("StudyNav", "Navigation to auth error", e)
            }
        } else if (isLoggedIn && currentRoute == Screen.Auth.route) {
            try {
                navController.navigate(Screen.Dashboard.route) {
                    popUpTo(Screen.Auth.route) { inclusive = true }
                    launchSingleTop = true
                }
            } catch (e: Exception) {
                android.util.Log.e("StudyNav", "Navigation to dashboard error", e)
            }
        }
    }

    val isAuthScreen = currentRoute == Screen.Auth.route || uiState.currentStudent == null

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (!isAuthScreen) {
                GradeSelectorHeader(
                    selectedGrade = uiState.selectedGrade,
                    onGradeSelected = { viewModel.setGrade(it) },
                    todayFocusMinutes = uiState.todayFocusMinutes,
                    dailyGoalMinutes = uiState.dailyGoalMinutes,
                    currentStudent = uiState.currentStudent,
                    onProfileClick = { viewModel.openProfileDialog() }
                )
            }
        },
        bottomBar = {
            if (!isAuthScreen) {
                NavigationBar(
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("bottom_navigation_bar"),
                    tonalElevation = 4.dp
                ) {
                    Screen.bottomNavItems.forEach { screen ->
                        val isSelected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                val icon = if (isSelected) screen.selectedIcon else screen.unselectedIcon
                                if (icon != null) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = screen.title
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            modifier = Modifier.testTag(screen.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(if (isAuthScreen) PaddingValues(0.dp) else innerPadding)
        ) {
            // 1. Authentication View
            composable(
                route = Screen.Auth.route,
                enterTransition = { fadeIn() },
                exitTransition = { fadeOut() }
            ) {
                AuthScreen(
                    uiState = uiState,
                    onLogin = { email, password -> viewModel.loginStudent(email, password) },
                    onRegister = { fullName, email, password, grade, school, targetAvg, goalMins, avatar, favSubj, bio ->
                        viewModel.registerStudent(
                            fullName = fullName,
                            email = email,
                            password = password,
                            gradeLevel = grade,
                            schoolName = school,
                            targetAverage = targetAvg,
                            dailyGoalMinutes = goalMins,
                            avatarKey = avatar,
                            favoriteSubject = favSubj,
                            bio = bio
                        )
                    },
                    onQuickLogin = { student ->
                        viewModel.loginStudent(student.email, student.passwordHash)
                    },
                    onClearMessages = { viewModel.clearAuthMessages() }
                )
            }

            // 2. Dashboard View
            composable(
                route = Screen.Dashboard.route,
                enterTransition = { fadeIn() },
                exitTransition = { fadeOut() }
            ) {
                HomeScreen(
                    uiState = uiState,
                    onNavigateTab = { tabIndex ->
                        val targetRoute = when (tabIndex) {
                            1 -> Screen.TaskManagement.route
                            2 -> Screen.StudySchedule.route
                            3 -> Screen.ExamPrep.route
                            else -> Screen.Dashboard.route
                        }
                        navController.navigate(targetRoute) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onToggleAssignment = { viewModel.toggleAssignmentStatus(it) },
                    onStartFocusSession = {
                        navController.navigate(Screen.StudySchedule.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }

            // 3. Task Management View (Assignments)
            composable(
                route = Screen.TaskManagement.route,
                enterTransition = { fadeIn() },
                exitTransition = { fadeOut() }
            ) {
                AssignmentsScreen(
                    uiState = uiState,
                    onAddAssignment = { title, subject, grade, dueDate, priority, weight, estHours, notes, checklist ->
                        viewModel.addAssignment(title, subject, grade, dueDate, priority, weight, estHours, notes, checklist)
                    },
                    onUpdateAssignment = { viewModel.updateAssignment(it) },
                    onToggleStatus = { viewModel.toggleAssignmentStatus(it) },
                    onDeleteAssignment = { viewModel.deleteAssignment(it) },
                    onSearchChange = { viewModel.setAssignmentSearch(it) },
                    onStatusFilterChange = { viewModel.setAssignmentFilter(it) },
                    onSubjectFilterChange = { viewModel.setAssignmentSubjectFilter(it) }
                )
            }

            // 4. Study Schedule & Pomodoro Timer View
            composable(
                route = Screen.StudySchedule.route,
                enterTransition = { fadeIn() },
                exitTransition = { fadeOut() }
            ) {
                StudyScheduleScreen(
                    uiState = uiState,
                    onAddSlot = { day, hour, min, dur, subj, top, grade, color ->
                        viewModel.addTimetableSlot(day, hour, min, dur, subj, top, grade, color)
                    },
                    onDeleteSlot = { viewModel.deleteTimetableSlot(it) },
                    onSetTimerMode = { viewModel.setTimerMode(it) },
                    onSetTimerSubject = { viewModel.setTimerSubject(it) },
                    onSetAmbientSound = { viewModel.setAmbientSound(it) },
                    onToggleTimer = { viewModel.toggleTimer() },
                    onResetTimer = { viewModel.resetTimer() },
                    onSendGeminiQuestion = { viewModel.sendGeminiStudyQuestion(it) },
                    onExplainConcept = { topic, subject -> viewModel.requestGeminiConceptExplanation(topic, subject) },
                    onGeneratePracticeQuiz = { topic, subject -> viewModel.requestGeminiPracticeQuestions(topic, subject) },
                    onGenerateCheatSheet = { topic, subject -> viewModel.requestGeminiCheatSheet(topic, subject) },
                    onClearGeminiChat = { viewModel.clearGeminiStudyChat() },
                    onRetryLastQuestion = { viewModel.retryLastGeminiQuestion() },
                    onSetGeminiInput = { viewModel.setGeminiStudyInput(it) },
                    onSetGeminiSubject = { viewModel.setGeminiStudySubject(it) },
                    onSetGeminiTopic = { viewModel.setGeminiStudyTopic(it) }
                )
            }

            // 5. Exam Prep & Past Papers View
            composable(
                route = Screen.ExamPrep.route,
                enterTransition = { fadeIn() },
                exitTransition = { fadeOut() }
            ) {
                ExamPrepScreen(
                    uiState = uiState,
                    onToggleCardFlip = { viewModel.toggleCardFlip() },
                    onNextCard = { viewModel.nextCard(it) },
                    onPrevCard = { viewModel.prevCard(it) },
                    onMarkMastery = { card, isMastered, list -> viewModel.markCardMastery(card, isMastered, list) },
                    onAddFlashcard = { grade, subj, topic, q, a, hint ->
                        viewModel.addCustomFlashcard(grade, subj, topic, q, a, hint)
                    },
                    onAddExam = { title, subj, grade, date, paper, topics, readiness ->
                        viewModel.addExam(title, subj, grade, date, paper, topics, readiness)
                    },
                    onUpdateExamReadiness = { exam, score -> viewModel.updateExamReadiness(exam, score) },
                    onDeleteExam = { viewModel.deleteExam(it) },
                    onAddPastPaper = { grade, subj, yr, term, paper, marks, score, completed, timed, notes ->
                        viewModel.addPastPaper(grade, subj, yr, term, paper, marks, score, completed, timed, notes)
                    },
                    onUpdatePastPaper = { viewModel.updatePastPaper(it) }
                )
            }
        }

        // Student Profile & Edit Profile Dialogs
        if (uiState.isProfileDialogOpen) {
            StudentProfileDialog(
                uiState = uiState,
                onDismiss = { viewModel.closeProfileDialog() },
                onOpenEditProfile = { viewModel.openEditProfileDialog() },
                onLogout = { viewModel.logout() },
                onSwitchAccount = { viewModel.switchStudentAccount(it) }
            )
        }

        if (uiState.isEditProfileDialogOpen && uiState.currentStudent != null) {
            EditStudentProfileDialog(
                student = uiState.currentStudent!!,
                onDismiss = { viewModel.closeEditProfileDialog() },
                onSave = { fullName, schoolName, gradeLevel, targetAverage, dailyGoalMinutes, avatarKey, favoriteSubject, bio ->
                    viewModel.updateStudentProfile(
                        fullName = fullName,
                        schoolName = schoolName,
                        gradeLevel = gradeLevel,
                        targetAverage = targetAverage,
                        dailyGoalMinutes = dailyGoalMinutes,
                        avatarKey = avatarKey,
                        favoriteSubject = favoriteSubject,
                        bio = bio
                    )
                }
            )
        }
    }
}
