package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.StudentEntity
import com.example.data.repository.StudyHubRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: StudyHubRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = StudyHubRepository(
            db.assignmentDao(),
            db.timetableDao(),
            db.studySessionDao(),
            db.examCountdownDao(),
            db.flashcardDao(),
            db.pastPaperDao(),
            db.studentDao()
        )
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Study Hub", appName)
    }

    @Test
    fun `test student registration login and logout flow`() = runBlocking {
        // 1. Register new student
        val regResult = repository.registerStudent(
            fullName = "Hendry Langa",
            email = "hendry@school.edu",
            passwordHash = "securepass123",
            gradeLevel = "GRADE_12",
            schoolName = "Westlake High",
            targetAverage = 92,
            dailyGoalMinutes = 120,
            avatarKey = "grad_cap"
        )
        assertTrue("Registration should succeed", regResult.isSuccess)
        val registeredStudent = regResult.getOrNull()
        assertNotNull(registeredStudent)
        assertEquals("Hendry Langa", registeredStudent?.fullName)

        // 2. Verify student is currently logged in
        val current = repository.currentStudent.first()
        assertNotNull(current)
        assertEquals("hendry@school.edu", current?.email)

        // 3. Log out
        val logoutResult = repository.logout()
        assertTrue(logoutResult.isSuccess)
        val afterLogout = repository.currentStudent.first()
        assertNull("After logout, current student should be null", afterLogout)

        // 4. Log in again with wrong password
        val wrongLogin = repository.loginStudent("hendry@school.edu", "wrongpassword")
        assertTrue("Login with wrong password should fail", wrongLogin.isFailure)

        // 5. Log in with correct password
        val correctLogin = repository.loginStudent("hendry@school.edu", "securepass123")
        assertTrue("Login with correct password should succeed", correctLogin.isSuccess)
        val loggedIn = repository.currentStudent.first()
        assertNotNull(loggedIn)
        assertEquals("Hendry Langa", loggedIn?.fullName)

        // 6. Update student profile
        repository.updateStudentProfile(
            loggedIn!!.copy(
                targetAverage = 95,
                bio = "Aiming for 95% distinction in final exams!"
            )
        )
        val updated = repository.currentStudent.first()
        assertEquals(95, updated?.targetAverage)
        assertEquals("Aiming for 95% distinction in final exams!", updated?.bio)
    }
}

