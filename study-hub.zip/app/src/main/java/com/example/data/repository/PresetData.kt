package com.example.data.repository

import com.example.data.local.AssignmentEntity
import com.example.data.local.ExamCountdownEntity
import com.example.data.local.FlashcardEntity
import com.example.data.local.PastPaperEntity
import com.example.data.local.StudentEntity
import com.example.data.local.TimetableSlotEntity
import java.util.Calendar

data class RevisionGuideItem(
    val id: String,
    val gradeLevel: String,
    val subject: String,
    val title: String,
    val category: String, // "Formulas & Equations", "Key Concepts & Summary", "Exam Strategies & Tips"
    val summary: String,
    val bulletPoints: List<String>,
    val highYieldTip: String
)

object PresetData {

    fun getDefaultAssignments(): List<AssignmentEntity> {
        val now = System.currentTimeMillis()
        val oneDay = 86400000L
        return listOf(
            AssignmentEntity(
                title = "Calculus & Derivative Applications Problem Set",
                subject = "Mathematics & Calculus",
                gradeLevel = "GRADE_12",
                dueDateEpochMs = now + oneDay * 2,
                priority = "URGENT",
                status = "IN_PROGRESS",
                weightPercent = 15,
                estimatedHours = 3.5,
                notes = "Complete exercises 4.2 to 4.8 on optimization and curve sketching. Show all intermediate steps.",
                checklistJson = """[{"text":"Review first and second derivative tests","done":true},{"text":"Solve optimization word problems (Q1-Q5)","done":true},{"text":"Plot cubic functions and identify inflection points","done":false},{"text":"Double check tangent line equations","done":false}]"""
            ),
            AssignmentEntity(
                title = "Organic Reactions & Ester Synthesis Lab Report",
                subject = "Physical Sciences (Physics/Chem)",
                gradeLevel = "GRADE_12",
                dueDateEpochMs = now + oneDay * 4,
                priority = "URGENT",
                status = "TODO",
                weightPercent = 20,
                estimatedHours = 4.0,
                notes = "Include esterification balanced equations, intermolecular forces explanation, and percentage yield calculation.",
                checklistJson = """[{"text":"Write introduction & hypothesis","done":false},{"text":"Draw structural formulas of alcohol & carboxylic acid","done":false},{"text":"Calculate actual vs theoretical yield","done":false},{"text":"Format references in APA style","done":false}]"""
            ),
            AssignmentEntity(
                title = "Genetics & Monohybrid Cross Analysis",
                subject = "Life Sciences (Biology)",
                gradeLevel = "GRADE_11",
                dueDateEpochMs = now + oneDay * 5,
                priority = "MEDIUM",
                status = "TODO",
                weightPercent = 10,
                estimatedHours = 2.0,
                notes = "Punnett squares for dominant/recessive alleles and sex-linked pedigree diagram interpretation.",
                checklistJson = """[{"text":"Define homozygous vs heterozygous alleles","done":true},{"text":"Draw 3 pedigree charts","done":false},{"text":"Calculate phenotypic and genotypic ratios","done":false}]"""
            ),
            AssignmentEntity(
                title = "Literary Essay: Theme of Power & Corruption",
                subject = "English Language & Lit",
                gradeLevel = "GRADE_11",
                dueDateEpochMs = now + oneDay * 7,
                priority = "MEDIUM",
                status = "IN_PROGRESS",
                weightPercent = 25,
                estimatedHours = 5.0,
                notes = "Minimum 800 words. Use PEEL paragraph structure (Point, Evidence, Explanation, Link).",
                checklistJson = """[{"text":"Brainstorm thesis statement","done":true},{"text":"Gather 6 direct textual quotes with line numbers","done":true},{"text":"Write body paragraph 1 & 2","done":false},{"text":"Proofread for grammar and MLA citations","done":false}]"""
            ),
            AssignmentEntity(
                title = "Trigonometric Identities & Reduction Formulas",
                subject = "Mathematics & Calculus",
                gradeLevel = "GRADE_10",
                dueDateEpochMs = now + oneDay * 3,
                priority = "LOW",
                status = "COMPLETED",
                weightPercent = 10,
                estimatedHours = 1.5,
                notes = "Special angles (30°, 45°, 60°) and CAST diagram proof exercises.",
                checklistJson = """[{"text":"Memorize CAST diagram rules","done":true},{"text":"Solve reduction formula proofs","done":true},{"text":"Self-check answers against solution manual","done":true}]"""
            )
        )
    }

    fun getDefaultTimetableSlots(): List<TimetableSlotEntity> {
        return listOf(
            TimetableSlotEntity(dayOfWeek = 1, startHour = 15, startMinute = 30, durationMinutes = 60, subject = "Mathematics & Calculus", topic = "Differential Calculus & Max/Min", gradeLevel = "GRADE_12", colorHex = 0xFF3B82F6),
            TimetableSlotEntity(dayOfWeek = 1, startHour = 17, startMinute = 0, durationMinutes = 45, subject = "Physical Sciences (Physics/Chem)", topic = "Newton's 2nd Law & Friction", gradeLevel = "GRADE_12", colorHex = 0xFF8B5CF6),
            TimetableSlotEntity(dayOfWeek = 2, startHour = 16, startMinute = 0, durationMinutes = 60, subject = "Life Sciences (Biology)", topic = "DNA Replication & Transcription", gradeLevel = "GRADE_12", colorHex = 0xFF10B981),
            TimetableSlotEntity(dayOfWeek = 3, startHour = 15, startMinute = 0, durationMinutes = 50, subject = "English Language & Lit", topic = "Poetry Analysis & Unseen Comprehension", gradeLevel = "GRADE_11", colorHex = 0xFFF59E0B),
            TimetableSlotEntity(dayOfWeek = 3, startHour = 16, startMinute = 30, durationMinutes = 60, subject = "Mathematics & Calculus", topic = "Analytical Geometry: Circles & Tangents", gradeLevel = "GRADE_11", colorHex = 0xFF3B82F6),
            TimetableSlotEntity(dayOfWeek = 4, startHour = 16, startMinute = 0, durationMinutes = 60, subject = "Physical Sciences (Physics/Chem)", topic = "Doppler Effect & Electric Circuits", gradeLevel = "GRADE_12", colorHex = 0xFF8B5CF6),
            TimetableSlotEntity(dayOfWeek = 5, startHour = 15, startMinute = 30, durationMinutes = 90, subject = "History & Social Studies", topic = "Cold War & Source-Based Skills", gradeLevel = "GRADE_12", colorHex = 0xFFEC4899),
            TimetableSlotEntity(dayOfWeek = 6, startHour = 10, startMinute = 0, durationMinutes = 120, subject = "Mathematics & Calculus", topic = "Past Exam Paper 1 Timed Simulation", gradeLevel = "GRADE_12", colorHex = 0xFF3B82F6),
            TimetableSlotEntity(dayOfWeek = 7, startHour = 14, startMinute = 0, durationMinutes = 60, subject = "Exam Prep", topic = "Weekly Weakness Review & Flashcards", gradeLevel = "GRADE_12", colorHex = 0xFF6366F1)
        )
    }

    fun getDefaultExams(): List<ExamCountdownEntity> {
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis
        val oneDay = 86400000L

        return listOf(
            ExamCountdownEntity(
                title = "Mathematics Paper 1 (Algebra, Calculus, Sequences)",
                subject = "Mathematics & Calculus",
                gradeLevel = "GRADE_12",
                examDateEpochMs = now + oneDay * 18,
                paperName = "Final Exam Paper 1",
                syllabusTopics = "Algebra & Equations, Patterns & Sequences, Functions & Inverses, Differential Calculus, Financial Mathematics, Probability",
                readinessScore = 78
            ),
            ExamCountdownEntity(
                title = "Physical Sciences Paper 1 (Physics)",
                subject = "Physical Sciences (Physics/Chem)",
                gradeLevel = "GRADE_12",
                examDateEpochMs = now + oneDay * 24,
                paperName = "Final Exam Paper 1 (Physics)",
                syllabusTopics = "Newtonian Mechanics, Momentum & Impulse, Work Energy & Power, Doppler Effect, Electrostatics, Electric Circuits, Electrodynamics",
                readinessScore = 65
            ),
            ExamCountdownEntity(
                title = "Life Sciences Paper 1",
                subject = "Life Sciences (Biology)",
                gradeLevel = "GRADE_12",
                examDateEpochMs = now + oneDay * 30,
                paperName = "Paper 1 (Systems & Ecology)",
                syllabusTopics = "Human Nervous System, Endocrine System, Homeostasis, Plant Responding to Environment, Human Reproduction",
                readinessScore = 82
            ),
            ExamCountdownEntity(
                title = "English Home Language Paper 2 (Literature)",
                subject = "English Language & Lit",
                gradeLevel = "GRADE_11",
                examDateEpochMs = now + oneDay * 14,
                paperName = "Paper 2 (Prescribed Novel & Poetry)",
                syllabusTopics = "Prescribed Drama Contextual, Novel Essay, Seen Poetry, Unseen Poetry Technique",
                readinessScore = 70
            )
        )
    }

    fun getDefaultFlashcards(): List<FlashcardEntity> {
        return listOf(
            // GRADE 12 MATHS
            FlashcardEntity(
                gradeLevel = "GRADE_12",
                subject = "Mathematics & Calculus",
                topic = "Calculus",
                question = "What is the First Principle Definition of the derivative f'(x)?",
                answer = "f'(x) = lim(h -> 0) [f(x + h) - f(x)] / h",
                formulaOrHint = "Remember: Always evaluate f(x+h) first, expand fully, factor out h, then take limit as h→0.",
                isMastered = true,
                timesReviewed = 4
            ),
            FlashcardEntity(
                gradeLevel = "GRADE_12",
                subject = "Mathematics & Calculus",
                topic = "Financial Maths",
                question = "When do you use the Present Value Annuity vs Future Value Annuity formula?",
                answer = "Present Value (P_v): Used for loans, mortgages, paying off debt now.\nFuture Value (F_v): Used for sinking funds, savings, retirement investments accumulating over time.",
                formulaOrHint = "Pv = x[1 - (1+i)^(-n)] / i   |   Fv = x[(1+i)^n - 1] / i",
                isMastered = false,
                timesReviewed = 2
            ),
            FlashcardEntity(
                gradeLevel = "GRADE_12",
                subject = "Mathematics & Calculus",
                topic = "Sequences & Series",
                question = "Under what condition does an Infinite Geometric Series converge, and what is its sum to infinity?",
                answer = "Converges ONLY when common ratio |r| < 1 (i.e. -1 < r < 1).\nSum to infinity: S_inf = a / (1 - r)",
                formulaOrHint = "If |r| >= 1, the series diverges and has no finite sum.",
                isMastered = true,
                timesReviewed = 5
            ),

            // GRADE 12 PHYSICAL SCIENCES
            FlashcardEntity(
                gradeLevel = "GRADE_12",
                subject = "Physical Sciences (Physics/Chem)",
                topic = "Doppler Effect",
                question = "What is the Doppler Effect formula for sound, and what happens to frequency as source approaches observer?",
                answer = "f_L = [(v ± v_L) / (v ∓ v_s)] * f_s\nAs source approaches stationary observer: frequency detected INCREASES (pitch is higher) because wavefronts are compressed in front of source.",
                formulaOrHint = "Top sign = moving towards each other (+v_L / -v_s)",
                isMastered = false,
                timesReviewed = 1
            ),
            FlashcardEntity(
                gradeLevel = "GRADE_12",
                subject = "Physical Sciences (Physics/Chem)",
                topic = "Organic Chemistry",
                question = "Define a Functional Isomer with an example.",
                answer = "Compounds with the SAME molecular formula but DIFFERENT functional groups.\nExample: Propanal (aldehyde) and Propanone (ketone) both have formula C3H6O.",
                formulaOrHint = "Esters and Carboxylic acids are also functional isomers of each other (e.g. C2H4O2).",
                isMastered = true,
                timesReviewed = 3
            ),
            FlashcardEntity(
                gradeLevel = "GRADE_12",
                subject = "Physical Sciences (Physics/Chem)",
                topic = "Work, Energy & Power",
                question = "State the Work-Energy Theorem in words and equation.",
                answer = "The net work done on an object is equal to the change in the object's kinetic energy.\nW_net = ΔE_k = (1/2)m(v_f)^2 - (1/2)m(v_i)^2",
                formulaOrHint = "W_nc = ΔE_k + ΔE_p (Work done by non-conservative forces)",
                isMastered = false,
                timesReviewed = 2
            ),

            // GRADE 11 & 12 LIFE SCIENCES
            FlashcardEntity(
                gradeLevel = "GRADE_12",
                subject = "Life Sciences (Biology)",
                topic = "Genetics & DNA",
                question = "State the differences between DNA and RNA (Structure, Sugar, Bases).",
                answer = "1. Structure: DNA is double-stranded helix; RNA is single-stranded.\n2. Sugar: DNA has Deoxyribose sugar; RNA has Ribose sugar.\n3. Bases: DNA has Thymine (A-T, C-G); RNA has Uracil instead of Thymine (A-U, C-G).",
                formulaOrHint = "Remember: Transcription happens in nucleus; Translation occurs at ribosomes in cytoplasm.",
                isMastered = true,
                timesReviewed = 6
            ),
            FlashcardEntity(
                gradeLevel = "GRADE_11",
                subject = "Life Sciences (Biology)",
                topic = "Cellular Respiration",
                question = "What are the 3 main stages of Aerobic Cellular Respiration and where do they occur?",
                answer = "1. Glycolysis (Cytoplasm - anaerobic, yields 2 ATP)\n2. Krebs Cycle / Citric Acid Cycle (Mitochondrial Matrix - yields 2 ATP & NADH/FADH2)\n3. Oxidative Phosphorylation (Mitochondrial Cristae - yields ~32-34 ATP)",
                formulaOrHint = "Total yield: ~36 to 38 ATP per glucose molecule.",
                isMastered = false,
                timesReviewed = 1
            ),

            // GRADE 10 & 11 MATHEMATICS
            FlashcardEntity(
                gradeLevel = "GRADE_10",
                subject = "Mathematics & Calculus",
                topic = "Trigonometry",
                question = "What are the definitions of sin, cos, and tan in terms of a right-angled triangle?",
                answer = "sin θ = Opposite / Hypotenuse\ncos θ = Adjacent / Hypotenuse\ntan θ = Opposite / Adjacent\n(Mnemonic: SOH CAH TOA)",
                formulaOrHint = "Special values: sin(30°)=1/2, cos(60°)=1/2, tan(45°)=1, sin(90°)=1",
                isMastered = true,
                timesReviewed = 8
            ),
            FlashcardEntity(
                gradeLevel = "GRADE_11",
                subject = "Mathematics & Calculus",
                topic = "Analytical Geometry",
                question = "How do you determine if two straight lines are perpendicular from their gradients?",
                answer = "Two lines with gradients m1 and m2 are perpendicular if and only if m1 * m2 = -1 (negative reciprocals).",
                formulaOrHint = "Parallel lines have equal gradients: m1 = m2.",
                isMastered = true,
                timesReviewed = 4
            ),

            // ENGLISH / ESSAYS
            FlashcardEntity(
                gradeLevel = "GRADE_11",
                subject = "English Language & Lit",
                topic = "Essay Strategy",
                question = "What does the PEEL paragraph structure stand for in high school literary essays?",
                answer = "P = Point (Topic sentence stating the argument)\nE = Evidence (Direct quote or specific scene reference)\nE = Explanation / Analysis (Unpack literary devices, tone, character motive)\nL = Link (Connect back to the essay question/thesis)",
                formulaOrHint = "Never drop a quote without analyzing the exact words/metaphors inside it!",
                isMastered = true,
                timesReviewed = 3
            )
        )
    }

    fun getDefaultPastPapers(): List<PastPaperEntity> {
        val list = mutableListOf<PastPaperEntity>()
        val years = (2016..2026).toList().reversed() // 2026 down to 2016 (11 years of papers)
        val terms = listOf(
            "Term 1 (March Control Test)",
            "Term 2 (June Mid-Year Exam)",
            "Term 3 (September Prelim/Trial)",
            "Term 4 (November Final / NSC Exam)"
        )

        // For Grade 12 (Matriculation)
        for (year in years) {
            for (term in terms) {
                // Mathematics
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_12",
                        subject = "Mathematics & Calculus",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Algebra, Calculus & Probability)",
                        totalMarks = 150,
                        userScore = if (year == 2025 && term.contains("Term 4")) 128 else if (year == 2024 && term.contains("Term 3")) 115 else null,
                        isCompleted = year == 2025 && term.contains("Term 4") || year == 2024 && term.contains("Term 3"),
                        isTimed = true,
                        keyLearnings = if (year == 2025 && term.contains("Term 4")) "Mastered cubic graph sketching. Revise annuity loans." else ""
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_12",
                        subject = "Mathematics & Calculus",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 2 (Trigonometry & Euclidean Geometry)",
                        totalMarks = 150,
                        userScore = if (year == 2025 && term.contains("Term 2")) 120 else null,
                        isCompleted = year == 2025 && term.contains("Term 2"),
                        isTimed = true,
                        keyLearnings = if (year == 2025 && term.contains("Term 2")) "Review cyclic quadrilateral proofs and CAST diagram." else ""
                    )
                )

                // Physical Sciences
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_12",
                        subject = "Physical Sciences (Physics/Chem)",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Physics - Mechanics & Electricity)",
                        totalMarks = 150,
                        userScore = if (year == 2025 && term.contains("Term 3")) 112 else null,
                        isCompleted = year == 2025 && term.contains("Term 3"),
                        isTimed = true,
                        keyLearnings = if (year == 2025 && term.contains("Term 3")) "Doppler effect calculations solid. Practice internal resistance." else ""
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_12",
                        subject = "Physical Sciences (Physics/Chem)",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 2 (Chemistry - Organic & Equilibrium)",
                        totalMarks = 150,
                        userScore = null,
                        isCompleted = false,
                        isTimed = true,
                        keyLearnings = ""
                    )
                )

                // Life Sciences
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_12",
                        subject = "Life Sciences (Biology)",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Nervous System, Endocrine & Homeostasis)",
                        totalMarks = 150,
                        userScore = if (year == 2024 && term.contains("Term 4")) 135 else null,
                        isCompleted = year == 2024 && term.contains("Term 4"),
                        isTimed = true,
                        keyLearnings = if (year == 2024 && term.contains("Term 4")) "High accuracy on nephron function and negative feedback loops." else ""
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_12",
                        subject = "Life Sciences (Biology)",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 2 (Genetics, Meiosis & Evolution)",
                        totalMarks = 150,
                        userScore = null,
                        isCompleted = false,
                        isTimed = true,
                        keyLearnings = ""
                    )
                )

                // English Language & Literature
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_12",
                        subject = "English Language & Lit",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Language in Context & Comprehension)",
                        totalMarks = 70,
                        userScore = if (year == 2025 && term.contains("Term 1")) 58 else null,
                        isCompleted = year == 2025 && term.contains("Term 1"),
                        isTimed = true,
                        keyLearnings = ""
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_12",
                        subject = "English Language & Lit",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 2 (Literature, Poetry & Drama Essay)",
                        totalMarks = 80,
                        userScore = null,
                        isCompleted = false,
                        isTimed = true,
                        keyLearnings = ""
                    )
                )

                // Accounting & Business
                if (term.contains("Term 2") || term.contains("Term 4")) {
                    list.add(
                        PastPaperEntity(
                            gradeLevel = "GRADE_12",
                            subject = "Accounting & Business",
                            year = year,
                            termOrSeason = term,
                            paperNumber = "Paper 1 (Financial Reporting & Balance Sheets)",
                            totalMarks = 150,
                            userScore = null,
                            isCompleted = false,
                            isTimed = true,
                            keyLearnings = ""
                        )
                    )
                }

                // History & Social Studies
                if (term.contains("Term 3") || term.contains("Term 4")) {
                    list.add(
                        PastPaperEntity(
                            gradeLevel = "GRADE_12",
                            subject = "History & Social Studies",
                            year = year,
                            termOrSeason = term,
                            paperNumber = "Paper 1 (Cold War & Source Analysis)",
                            totalMarks = 100,
                            userScore = null,
                            isCompleted = false,
                            isTimed = true,
                            keyLearnings = ""
                        )
                    )
                }
            }
        }

        // For Grade 11
        for (year in years) {
            for (term in terms) {
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_11",
                        subject = "Mathematics & Calculus",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Algebra, Equations & Sequences)",
                        totalMarks = 100,
                        userScore = if (year == 2024 && term.contains("Term 4")) 86 else null,
                        isCompleted = year == 2024 && term.contains("Term 4"),
                        isTimed = true,
                        keyLearnings = ""
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_11",
                        subject = "Mathematics & Calculus",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 2 (Analytical Geometry & Trigonometry)",
                        totalMarks = 100,
                        userScore = null,
                        isCompleted = false,
                        isTimed = true,
                        keyLearnings = ""
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_11",
                        subject = "Physical Sciences (Physics/Chem)",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Vectors, Forces & Newton's Laws)",
                        totalMarks = 100,
                        userScore = if (year == 2024 && term.contains("Term 2")) 79 else null,
                        isCompleted = year == 2024 && term.contains("Term 2"),
                        isTimed = true,
                        keyLearnings = ""
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_11",
                        subject = "Life Sciences (Biology)",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Photosynthesis & Respiration)",
                        totalMarks = 100,
                        userScore = if (year == 2024 && term.contains("Term 4")) 91 else null,
                        isCompleted = year == 2024 && term.contains("Term 4"),
                        isTimed = true,
                        keyLearnings = "Solid understanding of chloroplast light phase."
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_11",
                        subject = "English Language & Lit",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Comprehension & Language Skills)",
                        totalMarks = 70,
                        userScore = null,
                        isCompleted = false,
                        isTimed = true,
                        keyLearnings = ""
                    )
                )
            }
        }

        // For Grade 10
        for (year in years) {
            for (term in terms) {
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_10",
                        subject = "Mathematics & Calculus",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Algebraic Factorization & Linear Functions)",
                        totalMarks = 100,
                        userScore = if (year == 2023 && term.contains("Term 4")) 88 else null,
                        isCompleted = year == 2023 && term.contains("Term 4"),
                        isTimed = true,
                        keyLearnings = ""
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_10",
                        subject = "Physical Sciences (Physics/Chem)",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Waves, Sound & Light Basics)",
                        totalMarks = 100,
                        userScore = null,
                        isCompleted = false,
                        isTimed = true,
                        keyLearnings = ""
                    )
                )
                list.add(
                    PastPaperEntity(
                        gradeLevel = "GRADE_10",
                        subject = "English Language & Lit",
                        year = year,
                        termOrSeason = term,
                        paperNumber = "Paper 1 (Language Conventions & Reading)",
                        totalMarks = 70,
                        userScore = null,
                        isCompleted = false,
                        isTimed = true,
                        keyLearnings = ""
                    )
                )
            }
        }

        return list
    }

    fun getRevisionGuides(): List<RevisionGuideItem> {
        return listOf(
            RevisionGuideItem(
                id = "m12_calc",
                gradeLevel = "GRADE_12",
                subject = "Mathematics & Calculus",
                title = "Calculus: Rules, Graphs & Optimization",
                category = "Formulas & Equations",
                summary = "Complete mastery guide for finding derivatives, sketching cubic polynomials, and solving max/min word problems.",
                bulletPoints = listOf(
                    "Power Rule: d/dx [a*x^n] = a*n*x^(n-1)",
                    "Stationary / Turning Points: Set first derivative f'(x) = 0 and solve for x",
                    "Point of Inflection: Set second derivative f''(x) = 0 (where concavity changes)",
                    "Cubic Graph Shape: If a > 0, graph starts down-left and ends up-right (N-shape). If a < 0, inverted N-shape.",
                    "Tangent Line equation at x = a: y - f(a) = f'(a)(x - a)"
                ),
                highYieldTip = "In optimization word problems, always express the quantity to be maximized in terms of ONE single variable before differentiating!"
            ),
            RevisionGuideItem(
                id = "p12_physics_mech",
                gradeLevel = "GRADE_12",
                subject = "Physical Sciences (Physics/Chem)",
                title = "Mechanics, Momentum & Work-Energy",
                category = "Key Concepts & Summary",
                summary = "High-yield physics laws, vector conventions, and energy conservation equations for Paper 1.",
                bulletPoints = listOf(
                    "Newton's 2nd Law: F_net = m*a (Always draw a complete Free Body Diagram first)",
                    "Momentum: p = m*v (Vector quantity — choose a positive direction strictly)",
                    "Conservation of Linear Momentum: Σp_initial = Σp_final in an isolated system",
                    "Work: W = F * Δx * cos(θ), where θ is angle between force and displacement",
                    "Doppler Effect: Frequency observed increases when approaching, decreases when receding"
                ),
                highYieldTip = "Examiners deduct marks if you omit direction in momentum and velocity final answers!"
            ),
            RevisionGuideItem(
                id = "p12_chem_organic",
                gradeLevel = "GRADE_12",
                subject = "Physical Sciences (Physics/Chem)",
                title = "Organic Chemistry & Intermolecular Forces",
                category = "Formulas & Equations",
                summary = "Homologous series, IUPAC naming rules, boiling point trends, and reaction types (Substitution, Addition, Elimination).",
                bulletPoints = listOf(
                    "Alkanes (C_n H_2n+2), Alkenes (C_n H_2n), Alkynes (C_n H_2n-2), Alcohols (-OH), Carboxylic Acids (-COOH), Esters (-COO-)",
                    "Boiling Point hierarchy: Carboxylic acids (2 hydrogen bonds) > Alcohols (1 hydrogen bond) > Aldehydes/Ketones/Esters (Dipole-Dipole) > Hydrocarbons (London/Dispersion forces)",
                    "Addition Reactions: Hydration (+H2O to alkene), Halogenation (+X2), Hydrohalogenation (+HX)",
                    "Esterification: Carboxylic acid + Alcohol in presence of concentrated H2SO4 catalyst -> Ester + H2O"
                ),
                highYieldTip = "When explaining boiling point differences in exam questions, structure your answer in 4 distinct sentences: 1. Identify IMF type for each compound; 2. Compare IMF strengths; 3. Compare energy required to overcome forces; 4. State which has higher boiling point."
            ),
            RevisionGuideItem(
                id = "b12_genetics",
                gradeLevel = "GRADE_12",
                subject = "Life Sciences (Biology)",
                title = "Genetics, Meiosis & DNA Fingerprinting",
                category = "Key Concepts & Summary",
                summary = "Essential chromosome rules, crossing over, Mendelian crosses, and blood group inheritance.",
                bulletPoints = listOf(
                    "Meiosis: Crossing over occurs in Prophase I to introduce genetic variation; Independent assortment in Metaphase I",
                    "Phenotype vs Genotype: Phenotype is physical appearance; Genotype is genetic makeup (alleles)",
                    "Blood Groups: Alleles I^A and I^B are co-dominant, allele i is recessive (Group O = ii)",
                    "Sex-linked disorders: Hemophilia and Red-green color blindness are carried on X-chromosome (X^h / X^H)"
                ),
                highYieldTip = "In Punnett squares, always clearly write out: P1 Phenotype, P1 Genotype, Meiosis/Gametes, Fertilization, F1 Genotypes, F1 Phenotypes and Ratios to earn all 6 marks."
            ),
            RevisionGuideItem(
                id = "eng_exam_tactics",
                gradeLevel = "GRADE_11",
                subject = "English Language & Lit",
                title = "Essay Writing & Command Words Glossary",
                category = "Exam Strategies & Tips",
                summary = "Essential action verbs decoded and pacing strategies for language & literature papers.",
                bulletPoints = listOf(
                    "'Critique / Evaluate': Weigh strengths vs weaknesses and give a reasoned judgment with textual evidence",
                    "'Analyze': Break down how the author uses diction, figurative language, syntax, or tone to create effect",
                    "'Account for': Explain WHY something happened, giving reasons and context",
                    "'Deduce / Infer': Read between the lines — extract meaning not directly stated",
                    "Time budget: Spend 10 minutes planning essay outline before writing"
                ),
                highYieldTip = "Never retell the plot! Literary essays test your ability to argue a thesis, not summarize what happens in the book."
            ),
            RevisionGuideItem(
                id = "m10_trig_geometry",
                gradeLevel = "GRADE_10",
                subject = "Mathematics & Calculus",
                title = "Grade 10 Foundation: Quadratics & Euclidean Geometry",
                category = "Formulas & Equations",
                summary = "Core algebraic factorization patterns, quadratic formula, and circle/triangle geometry theorems.",
                bulletPoints = listOf(
                    "Quadratic formula: x = [-b ± √(b^2 - 4ac)] / (2a)",
                    "Difference of Two Squares: a^2 - b^2 = (a - b)(a + b)",
                    "Sum/Difference of Cubes: a^3 ± b^3 = (a ± b)(a^2 ∓ ab + b^2)",
                    "Pythagoras Theorem: a^2 + b^2 = c^2 (in right angled triangle)",
                    "Angles on a straight line add to 180°; vertically opposite angles are equal"
                ),
                highYieldTip = "Always test your factorization by expanding it back out before continuing to the next question."
            )
        )
    }

    fun getDefaultStudents(): List<StudentEntity> {
        return listOf(
            StudentEntity(
                id = 1,
                fullName = "Hendry Langa",
                email = "langa.hendry@gmail.com",
                passwordHash = "password123",
                gradeLevel = "GRADE_12",
                schoolName = "Westlake High School",
                targetAverage = 90,
                dailyGoalMinutes = 120,
                avatarKey = "grad_cap",
                favoriteSubject = "Mathematics & Calculus",
                bio = "Grade 12 STEM Scholar preparing for final matric and university admissions.",
                isLoggedIn = true
            ),
            StudentEntity(
                id = 2,
                fullName = "Sarah Jenkins",
                email = "sarah.j@school.edu",
                passwordHash = "study123",
                gradeLevel = "GRADE_11",
                schoolName = "St. Marks Academy",
                targetAverage = 85,
                dailyGoalMinutes = 90,
                avatarKey = "science",
                favoriteSubject = "Life Sciences (Biology)",
                bio = "Passionate biology and chemistry student working towards medical school.",
                isLoggedIn = false
            ),
            StudentEntity(
                id = 3,
                fullName = "Marcus Vance",
                email = "marcus.v@academy.org",
                passwordHash = "pass1234",
                gradeLevel = "GRADE_10",
                schoolName = "Oakridge High",
                targetAverage = 80,
                dailyGoalMinutes = 60,
                avatarKey = "rocket",
                favoriteSubject = "Physical Sciences (Physics/Chem)",
                bio = "Grade 10 explorer building solid foundation in STEM and essay analysis.",
                isLoggedIn = false
            )
        )
    }
}

