package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.ExamCountdownEntity
import com.example.data.local.FlashcardEntity
import com.example.data.local.PastPaperEntity
import com.example.data.repository.RevisionGuideItem
import com.example.model.GradeLevel
import com.example.model.SubjectCategory
import com.example.ui.MainUiState
import com.example.ui.components.PastPaperDocumentViewerDialog
import com.example.ui.components.formatEpochDate
import com.example.ui.components.getDaysRemaining

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamPrepScreen(
    uiState: MainUiState,
    onToggleCardFlip: () -> Unit,
    onNextCard: (List<FlashcardEntity>) -> Unit,
    onPrevCard: (List<FlashcardEntity>) -> Unit,
    onMarkMastery: (FlashcardEntity, Boolean, List<FlashcardEntity>) -> Unit,
    onAddFlashcard: (grade: GradeLevel, subject: String, topic: String, q: String, a: String, hint: String) -> Unit,
    onAddExam: (title: String, subject: String, grade: GradeLevel, date: Long, paperName: String, topics: String, readiness: Int) -> Unit,
    onUpdateExamReadiness: (ExamCountdownEntity, Int) -> Unit,
    onDeleteExam: (ExamCountdownEntity) -> Unit,
    onAddPastPaper: (grade: GradeLevel, subject: String, year: Int, term: String, paper: String, marks: Int, score: Int?, isCompleted: Boolean, isTimed: Boolean, notes: String) -> Unit,
    onUpdatePastPaper: (PastPaperEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSection by remember { mutableStateOf(0) } // 0 = Flashcards, 1 = Formula & Concept Guides, 2 = Exam Countdowns, 3 = Past Papers Tracker
    var selectedSubjectFilter by remember { mutableStateOf("All") }
    var showAddFlashcardDialog by remember { mutableStateOf(false) }
    var showAddExamDialog by remember { mutableStateOf(false) }
    var showAddPastPaperDialog by remember { mutableStateOf(false) }

    val gradeFlashcards = uiState.flashcards.filter {
        it.gradeLevel == uiState.selectedGrade.name &&
                (selectedSubjectFilter == "All" || it.subject.contains(selectedSubjectFilter, ignoreCase = true))
    }

    val gradeExams = uiState.exams.filter { it.gradeLevel == uiState.selectedGrade.name }

    val gradeGuides = uiState.revisionGuides.filter {
        (it.gradeLevel == uiState.selectedGrade.name || it.gradeLevel == "GRADE_ALL") &&
                (selectedSubjectFilter == "All" || it.subject.contains(selectedSubjectFilter, ignoreCase = true))
    }

    val gradePastPapers = uiState.pastPapers.filter {
        it.gradeLevel == uiState.selectedGrade.name &&
                (selectedSubjectFilter == "All" || it.subject.contains(selectedSubjectFilter, ignoreCase = true))
    }

    Scaffold(modifier = modifier.fillMaxSize()) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Resource Category Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedSection,
                edgePadding = 0.dp,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .height(44.dp)
            ) {
                Tab(
                    selected = selectedSection == 0,
                    onClick = { selectedSection = 0 },
                    text = { Text("Flashcards", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_flashcards")
                )
                Tab(
                    selected = selectedSection == 1,
                    onClick = { selectedSection = 1 },
                    text = { Text("Formulas & Summaries", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_formula_guides")
                )
                Tab(
                    selected = selectedSection == 2,
                    onClick = { selectedSection = 2 },
                    text = { Text("Exam Countdowns", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_exam_countdowns")
                )
                Tab(
                    selected = selectedSection == 3,
                    onClick = { selectedSection = 3 },
                    text = { Text("Past Papers", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_past_papers")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Subject Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedSubjectFilter == "All",
                        onClick = { selectedSubjectFilter = "All" },
                        label = { Text("All Subjects") },
                        modifier = Modifier.testTag("filter_all_subjects")
                    )
                }
                SubjectCategory.entries.take(5).forEach { cat ->
                    item {
                        FilterChip(
                            selected = selectedSubjectFilter == cat.displayName,
                            onClick = { selectedSubjectFilter = cat.displayName },
                            label = { Text(cat.displayName) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (selectedSection) {
                0 -> FlashcardsSection(
                    grade = uiState.selectedGrade,
                    flashcards = gradeFlashcards,
                    activeIndex = uiState.activeFlashcardIndex,
                    isFlipped = uiState.isCardFlipped,
                    onToggleFlip = onToggleCardFlip,
                    onNext = { onNextCard(gradeFlashcards) },
                    onPrev = { onPrevCard(gradeFlashcards) },
                    onMarkMastery = { card, isMastered -> onMarkMastery(card, isMastered, gradeFlashcards) },
                    onOpenAdd = { showAddFlashcardDialog = true }
                )
                1 -> FormulaGuidesSection(guides = gradeGuides)
                2 -> ExamCountdownsSection(
                    exams = gradeExams,
                    onOpenAdd = { showAddExamDialog = true },
                    onUpdateReadiness = onUpdateExamReadiness,
                    onDelete = onDeleteExam
                )
                3 -> PastPapersSection(
                    pastPapers = gradePastPapers,
                    onOpenAdd = { showAddPastPaperDialog = true },
                    onUpdate = onUpdatePastPaper
                )
            }
        }
    }

    if (showAddFlashcardDialog) {
        AddFlashcardDialog(
            gradeLevel = uiState.selectedGrade,
            onDismiss = { showAddFlashcardDialog = false },
            onSave = { subj, topic, q, a, hint ->
                onAddFlashcard(uiState.selectedGrade, subj, topic, q, a, hint)
                showAddFlashcardDialog = false
            }
        )
    }

    if (showAddExamDialog) {
        AddExamDialog(
            gradeLevel = uiState.selectedGrade,
            onDismiss = { showAddExamDialog = false },
            onSave = { title, subj, date, paper, topics, readiness ->
                onAddExam(title, subj, uiState.selectedGrade, date, paper, topics, readiness)
                showAddExamDialog = false
            }
        )
    }

    if (showAddPastPaperDialog) {
        AddPastPaperDialog(
            gradeLevel = uiState.selectedGrade,
            onDismiss = { showAddPastPaperDialog = false },
            onSave = { subj, yr, term, pNum, marks, score, timed, notes ->
                onAddPastPaper(uiState.selectedGrade, subj, yr, term, pNum, marks, score, score != null, timed, notes)
                showAddPastPaperDialog = false
            }
        )
    }
}

@Composable
fun FlashcardsSection(
    grade: GradeLevel,
    flashcards: List<FlashcardEntity>,
    activeIndex: Int,
    isFlipped: Boolean,
    onToggleFlip: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onMarkMastery: (FlashcardEntity, Boolean) -> Unit,
    onOpenAdd: () -> Unit
) {
    if (flashcards.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.Layers, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.height(8.dp))
                Text("No flashcards found for this filter", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = onOpenAdd) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Custom Flashcard")
                }
            }
        }
        return
    }

    val currentCard = flashcards.getOrNull(activeIndex.coerceIn(0, flashcards.size - 1)) ?: flashcards[0]
    val masteredCount = flashcards.count { it.isMastered }

    val rotation by animateFloatAsState(
        targetValue = if (isFlipped) 180f else 0f,
        animationSpec = tween(durationMillis = 350),
        label = "cardFlip"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Progress & Mastery Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Card ${activeIndex + 1} of ${flashcards.size} • $masteredCount Mastered",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onOpenAdd, modifier = Modifier.testTag("add_flashcard_btn")) {
                    Icon(Icons.Default.AddCircle, contentDescription = "Add Card", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }

        // 3D Flip Card Container
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .graphicsLayer {
                        rotationY = rotation
                        cameraDistance = 12f * density
                    }
                    .clickable { onToggleFlip() }
                    .testTag("active_flashcard"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isFlipped) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (rotation <= 90f) {
                        // FRONT: Question
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "${currentCard.subject} • ${currentCard.topic}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                if (currentCard.isMastered) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = "Mastered", tint = Color(0xFF10B981))
                                }
                            }

                            Text(
                                text = currentCard.question,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.outline)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Tap card to flip & reveal answer",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    } else {
                        // BACK: Answer (mirrored text correction)
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer { rotationY = 180f },
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Answer & Solution:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )

                            Text(
                                text = currentCard.answer,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )

                            if (currentCard.formulaOrHint.isNotBlank()) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
                                ) {
                                    Text(
                                        text = "💡 Tip / Formula: ${currentCard.formulaOrHint}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                            }

                            Text(
                                text = "Tap again to flip back",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        // Navigation & Mastery Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedIconButton(onClick = onPrev, modifier = Modifier.testTag("prev_flashcard_btn")) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Previous")
                }

                Button(
                    onClick = { onMarkMastery(currentCard, false) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("need_practice_btn")
                ) {
                    Text("Need Practice", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onMarkMastery(currentCard, true) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mastered_btn")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Mastered!", fontWeight = FontWeight.Bold)
                }

                OutlinedIconButton(onClick = onNext, modifier = Modifier.testTag("next_flashcard_btn")) {
                    Icon(Icons.Default.ArrowForward, contentDescription = "Next")
                }
            }
        }
    }
}

@Composable
fun FormulaGuidesSection(guides: List<RevisionGuideItem>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        items(guides, key = { it.id }) { guide ->
            var expanded by remember { mutableStateOf(false) }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .testTag("guide_card_${guide.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "${guide.subject} • ${guide.category}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = guide.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = guide.summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    AnimatedVisibility(visible = expanded) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "High-Yield Concepts & Equations:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            guide.bulletPoints.forEach { point ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Text(
                                        text = "•",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = point,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontFamily = if (point.contains("=")) FontFamily.Monospace else FontFamily.Default
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFFEF3C7)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lightbulb,
                                        contentDescription = null,
                                        tint = Color(0xFFD97706),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = guide.highYieldTip,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF92400E),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ExamCountdownsSection(
    exams: List<ExamCountdownEntity>,
    onOpenAdd: () -> Unit,
    onUpdateReadiness: (ExamCountdownEntity, Int) -> Unit,
    onDelete: (ExamCountdownEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Upcoming Exam Dates", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Button(onClick = onOpenAdd, shape = RoundedCornerShape(10.dp), modifier = Modifier.testTag("add_exam_btn")) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Exam")
                }
            }
        }

        if (exams.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Outlined.EventNote, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No exam dates logged", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        } else {
            items(exams, key = { it.id }) { exam ->
                val daysLeft = getDaysRemaining(exam.examDateEpochMs)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("exam_card_${exam.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = exam.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${exam.subject} • ${exam.paperName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (daysLeft <= 7) Color(0xFFFEE2E2) else MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = if (daysLeft == 0L) "Today!" else "$daysLeft Days",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (daysLeft <= 7) Color(0xFFDC2626) else MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Date: ${formatEpochDate(exam.examDateEpochMs)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (exam.syllabusTopics.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Syllabus: ${exam.syllabusTopics}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Readiness Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Readiness Confidence:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${exam.readinessScore}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Slider(
                            value = exam.readinessScore.toFloat(),
                            onValueChange = { onUpdateReadiness(exam, it.toInt()) },
                            valueRange = 0f..100f,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            IconButton(onClick = { onDelete(exam) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Exam", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PastPapersSection(
    pastPapers: List<PastPaperEntity>,
    onOpenAdd: () -> Unit,
    onUpdate: (PastPaperEntity) -> Unit
) {
    var selectedYearFilter by remember { mutableStateOf<Int?>(null) }
    var selectedTermFilter by remember { mutableStateOf("All Terms") }
    var selectedStatusFilter by remember { mutableStateOf("All") } // "All", "Completed", "Pending"
    var searchQuery by remember { mutableStateOf("") }
    var editingPaper by remember { mutableStateOf<PastPaperEntity?>(null) }
    var viewingPaperDocument by remember { mutableStateOf<PastPaperEntity?>(null) }

    val allYears = remember { (2016..2026).toList().reversed() }
    val termOptions = listOf(
        "All Terms",
        "Term 1 (March Control Test)",
        "Term 2 (June Mid-Year Exam)",
        "Term 3 (September Prelim/Trial)",
        "Term 4 (November Final / NSC Exam)"
    )

    val filteredPapers = pastPapers.filter { paper ->
        val matchesYear = selectedYearFilter == null || paper.year == selectedYearFilter
        val matchesTerm = selectedTermFilter == "All Terms" || paper.termOrSeason.contains(selectedTermFilter.substringBefore(" ("), ignoreCase = true)
        val matchesStatus = when (selectedStatusFilter) {
            "Completed" -> paper.isCompleted || paper.userScore != null
            "Pending" -> !paper.isCompleted && paper.userScore == null
            else -> true
        }
        val matchesSearch = searchQuery.isBlank() ||
                paper.subject.contains(searchQuery, ignoreCase = true) ||
                paper.paperNumber.contains(searchQuery, ignoreCase = true) ||
                paper.termOrSeason.contains(searchQuery, ignoreCase = true) ||
                paper.year.toString().contains(searchQuery)

        matchesYear && matchesTerm && matchesStatus && matchesSearch
    }

    val completedCount = pastPapers.count { it.isCompleted || it.userScore != null }
    val scoredPapers = pastPapers.filter { it.userScore != null && it.totalMarks > 0 }
    val avgScorePercent = if (scoredPapers.isNotEmpty()) {
        scoredPapers.map { (it.userScore!! * 100) / it.totalMarks }.average().toInt()
    } else 0

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Vault Header & Stats
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("past_papers_vault_banner"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "10+ Years Exam Vault (2016 – 2026)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Complete past paper catalog for Terms 1, 2, 3 & 4",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                        Button(
                            onClick = onOpenAdd,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("add_past_paper_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Log Custom")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${pastPapers.size}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Total Papers",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "$completedCount",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF059669)
                                )
                                Text(
                                    text = "Completed",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = if (avgScorePercent > 0) "$avgScorePercent%" else "--",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFD97706)
                                )
                                Text(
                                    text = "Avg Score",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("past_papers_search_input"),
                placeholder = { Text("Search by subject, topic or paper number...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
        }

        // Year Filter Chip Row (2026 to 2016)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Filter by Examination Year (10+ Years):",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedYearFilter == null,
                            onClick = { selectedYearFilter = null },
                            label = { Text("All (2016–2026)") },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("filter_year_all")
                        )
                    }
                    items(allYears) { year ->
                        FilterChip(
                            selected = selectedYearFilter == year,
                            onClick = { selectedYearFilter = if (selectedYearFilter == year) null else year },
                            label = { Text("$year") },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("filter_year_$year")
                        )
                    }
                }
            }
        }

        // Term Filter Chip Row
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Filter by Term:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedTermFilter == "All Terms",
                            onClick = { selectedTermFilter = "All Terms" },
                            label = { Text("All Terms") },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("filter_term_all")
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTermFilter.contains("Term 1"),
                            onClick = { selectedTermFilter = "Term 1" },
                            label = { Text("Term 1 (March)") },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("filter_term_1")
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTermFilter.contains("Term 2"),
                            onClick = { selectedTermFilter = "Term 2" },
                            label = { Text("Term 2 (June Mid-Year)") },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("filter_term_2")
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTermFilter.contains("Term 3"),
                            onClick = { selectedTermFilter = "Term 3" },
                            label = { Text("Term 3 (Prelim/Trial)") },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("filter_term_3")
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedTermFilter.contains("Term 4"),
                            onClick = { selectedTermFilter = "Term 4" },
                            label = { Text("Term 4 (Final / NSC)") },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("filter_term_4")
                        )
                    }
                }
            }
        }

        // Status Filter Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Showing ${filteredPapers.size} Past Papers",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.SemiBold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("All", "Completed", "Pending").forEach { status ->
                        FilterChip(
                            selected = selectedStatusFilter == status,
                            onClick = { selectedStatusFilter = status },
                            label = { Text(status, style = MaterialTheme.typography.labelSmall) },
                            shape = RoundedCornerShape(6.dp)
                        )
                    }
                }
            }
        }

        // List of Past Papers
        if (filteredPapers.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Outlined.HistoryEdu,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "No matching past papers found",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "Try clearing or adjusting your search, year, or term filters",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredPapers, key = { it.id }) { paper ->
                val termColor = when {
                    paper.termOrSeason.contains("Term 1") -> Color(0xFF2563EB)
                    paper.termOrSeason.contains("Term 2") -> Color(0xFF059669)
                    paper.termOrSeason.contains("Term 3") -> Color(0xFFD97706)
                    else -> Color(0xFF7C3AED)
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewingPaperDocument = paper }
                        .testTag("past_paper_${paper.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = termColor.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "${paper.year}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = termColor,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant
                                    ) {
                                        Text(
                                            text = paper.termOrSeason,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = paper.paperNumber,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = "${paper.subject} • Total: ${paper.totalMarks} Marks",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            if (paper.userScore != null) {
                                val percentage = (paper.userScore * 100) / paper.totalMarks
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (percentage >= 75) Color(0xFFD1FAE5) else Color(0xFFFEF3C7)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.End
                                    ) {
                                        Text(
                                            text = "${paper.userScore}/${paper.totalMarks}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (percentage >= 75) Color(0xFF059669) else Color(0xFFD97706)
                                        )
                                        Text(
                                            text = "$percentage%",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (percentage >= 75) Color(0xFF059669) else Color(0xFFD97706)
                                        )
                                    }
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        text = "Unscored",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        if (paper.keyLearnings.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Info,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "Learnings: ${paper.keyLearnings}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { viewingPaperDocument = paper },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .weight(1.3f)
                                    .testTag("view_doc_paper_${paper.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "View Paper & Memo",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedButton(
                                onClick = { editingPaper = paper },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("edit_paper_${paper.id}")
                            ) {
                                Icon(
                                    imageVector = if (paper.userScore != null) Icons.Default.Edit else Icons.Default.CheckCircleOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (paper.userScore != null) "Edit Score" else "Record Marks",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (viewingPaperDocument != null) {
        PastPaperDocumentViewerDialog(
            paper = viewingPaperDocument!!,
            onDismiss = { viewingPaperDocument = null },
            onLogScore = { updated ->
                onUpdate(updated)
                viewingPaperDocument = updated
            }
        )
    }

    if (editingPaper != null) {
        EditPastPaperDialog(
            paper = editingPaper!!,
            onDismiss = { editingPaper = null },
            onSave = { updated ->
                onUpdate(updated)
                editingPaper = null
            }
        )
    }
}

// Dialogs
@Composable
fun AddFlashcardDialog(
    gradeLevel: GradeLevel,
    onDismiss: () -> Unit,
    onSave: (subject: String, topic: String, q: String, a: String, hint: String) -> Unit
) {
    var subject by remember { mutableStateOf(SubjectCategory.MATHEMATICS.displayName) }
    var topic by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var hint by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Text("Add New Flashcard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                item {
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text("Topic (e.g. Calculus)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = question,
                        onValueChange = { question = it },
                        label = { Text("Question / Concept Prompt *") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
                item {
                    OutlinedTextField(
                        value = answer,
                        onValueChange = { answer = it },
                        label = { Text("Detailed Answer / Solution *") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
                item {
                    OutlinedTextField(
                        value = hint,
                        onValueChange = { hint = it },
                        label = { Text("Formula / Key Mnemonic Hint") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(onClick = {
                            if (question.isNotBlank() && answer.isNotBlank()) {
                                onSave(subject, topic.ifBlank { "General" }, question.trim(), answer.trim(), hint.trim())
                            }
                        }) {
                            Text("Save Card")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddExamDialog(
    gradeLevel: GradeLevel,
    onDismiss: () -> Unit,
    onSave: (title: String, subject: String, date: Long, paper: String, topics: String, readiness: Int) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf(SubjectCategory.MATHEMATICS.displayName) }
    var paperName by remember { mutableStateOf("Paper 1") }
    var daysAhead by remember { mutableStateOf("14") }
    var topics by remember { mutableStateOf("") }
    var readiness by remember { mutableStateOf(60) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Text("Add Exam Countdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Exam Name *") },
                        placeholder = { Text("e.g. Trial Final Physics Paper 1") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = paperName,
                            onValueChange = { paperName = it },
                            label = { Text("Paper") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = daysAhead,
                            onValueChange = { daysAhead = it.filter { c -> c.isDigit() } },
                            label = { Text("Days from Now") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = topics,
                        onValueChange = { topics = it },
                        label = { Text("Topics Covered") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(onClick = {
                            if (title.isNotBlank()) {
                                val d = daysAhead.toLongOrNull() ?: 14L
                                val epoch = System.currentTimeMillis() + d * 86400000L
                                onSave(title.trim(), subject, epoch, paperName, topics.trim(), readiness)
                            }
                        }) {
                            Text("Save Exam")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddPastPaperDialog(
    gradeLevel: GradeLevel,
    onDismiss: () -> Unit,
    onSave: (subject: String, year: Int, term: String, paper: String, marks: Int, score: Int?, timed: Boolean, notes: String) -> Unit
) {
    var subject by remember { mutableStateOf(SubjectCategory.MATHEMATICS.displayName) }
    var year by remember { mutableStateOf("2025") }
    var term by remember { mutableStateOf("Final Exam") }
    var paper by remember { mutableStateOf("Paper 1") }
    var totalMarks by remember { mutableStateOf("150") }
    var score by remember { mutableStateOf("") }
    var isTimed by remember { mutableStateOf(true) }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Text("Log Past Exam Paper", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = year,
                            onValueChange = { year = it },
                            label = { Text("Year") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = term,
                            onValueChange = { term = it },
                            label = { Text("Exam Term") },
                            modifier = Modifier.weight(1.5f),
                            singleLine = true
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = paper,
                            onValueChange = { paper = it },
                            label = { Text("Paper Name") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = score,
                            onValueChange = { score = it.filter { c -> c.isDigit() } },
                            label = { Text("Score") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = totalMarks,
                            onValueChange = { totalMarks = it.filter { c -> c.isDigit() } },
                            label = { Text("Total") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Key Feedback & Mistakes to Fix") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(onClick = {
                            onSave(
                                subject,
                                year.toIntOrNull() ?: 2025,
                                term,
                                paper,
                                totalMarks.toIntOrNull() ?: 150,
                                score.toIntOrNull(),
                                isTimed,
                                notes.trim()
                            )
                        }) {
                            Text("Save Log")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditPastPaperDialog(
    paper: PastPaperEntity,
    onDismiss: () -> Unit,
    onSave: (PastPaperEntity) -> Unit
) {
    var scoreText by remember { mutableStateOf(paper.userScore?.toString() ?: "") }
    var totalMarksText by remember { mutableStateOf(paper.totalMarks.toString()) }
    var isCompleted by remember { mutableStateOf(paper.isCompleted || paper.userScore != null) }
    var isTimed by remember { mutableStateOf(paper.isTimed) }
    var keyLearnings by remember { mutableStateOf(paper.keyLearnings) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Column {
                        Text(
                            text = "${paper.year} ${paper.termOrSeason}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${paper.subject} • ${paper.paperNumber}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = scoreText,
                            onValueChange = {
                                scoreText = it.filter { c -> c.isDigit() }
                                if (scoreText.isNotBlank()) {
                                    isCompleted = true
                                }
                            },
                            label = { Text("Score Obtained") },
                            placeholder = { Text("e.g. 125") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = totalMarksText,
                            onValueChange = { totalMarksText = it.filter { c -> c.isDigit() } },
                            label = { Text("Total Marks") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                if (scoreText.isNotBlank() && totalMarksText.isNotBlank()) {
                    val sc = scoreText.toIntOrNull() ?: 0
                    val tot = totalMarksText.toIntOrNull() ?: 1
                    if (tot > 0) {
                        val pct = (sc * 100) / tot
                        item {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (pct >= 75) Color(0xFFD1FAE5) else Color(0xFFFEF3C7),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Calculated Percentage:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                    Text(
                                        "$pct%",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (pct >= 75) Color(0xFF059669) else Color(0xFFD97706)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Practice under timed conditions", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = isTimed,
                            onCheckedChange = { isTimed = it }
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Mark as Completed", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = isCompleted,
                            onCheckedChange = { isCompleted = it }
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = keyLearnings,
                        onValueChange = { keyLearnings = it },
                        label = { Text("Key Learnings & Questions to Revise") },
                        placeholder = { Text("e.g. Lost marks on optimization word problem...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val s = scoreText.toIntOrNull()
                                val t = totalMarksText.toIntOrNull() ?: paper.totalMarks
                                onSave(
                                    paper.copy(
                                        userScore = s,
                                        totalMarks = t,
                                        isCompleted = isCompleted || s != null,
                                        isTimed = isTimed,
                                        keyLearnings = keyLearnings.trim()
                                    )
                                )
                            }
                        ) {
                            Text("Save Simulation")
                        }
                    }
                }
            }
        }
    }
}
