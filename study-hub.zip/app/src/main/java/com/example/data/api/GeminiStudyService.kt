package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.example.model.GradeLevel
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface GeminiStudyApi {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

class GeminiStudyService {
    companion object {
        private const val TAG = "GeminiStudyService"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/"
        const val PRIMARY_MODEL = "gemini-3.5-flash"
        const val FALLBACK_MODEL = "gemini-3.1-flash-lite-preview"
    }

    private val api: GeminiStudyApi

    init {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }

        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .build()

        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        api = retrofit.create(GeminiStudyApi::class.java)
    }

    /**
     * Ask the Gemini Study Coach with automatic retry and model fallback for 429 rate limits.
     */
    suspend fun askStudyTutor(
        question: String,
        subject: String,
        gradeLevel: GradeLevel,
        conversationHistory: List<StudyChatMessage> = emptyList()
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is not configured. Please add your key in the AI Studio Secrets panel.")
            )
        }

        val systemInstructionText = """
            You are a patient, encouraging, and highly knowledgeable High School AI Study Tutor (named Gemini Study Coach).
            Your sole purpose is to help high school students with studying, understanding concepts, exam preparation, and homework explanations.
            Current Student Grade: ${gradeLevel.displayName}.
            Current Subject Focus: $subject.
            
            Guidelines:
            1. Provide clear, step-by-step explanations suited to ${gradeLevel.displayName} curriculum level.
            2. Use intuitive real-world examples, analogies, formulas, and bullet points.
            3. Include 1-2 active-recall check questions or "Key Exam Takeaway" at the end.
            4. Maintain a supportive, focused, and academic tone. Keep explanations structured and easy to read.
        """.trimIndent()

        val contents = mutableListOf<GeminiContent>()

        // Add recent history
        conversationHistory.takeLast(4).forEach { msg ->
            val role = if (msg.sender == MessageSender.STUDENT) "user" else "model"
            contents.add(
                GeminiContent(
                    role = role,
                    parts = listOf(GeminiPart(text = msg.text))
                )
            )
        }

        // Add current question
        contents.add(
            GeminiContent(
                role = "user",
                parts = listOf(GeminiPart(text = question))
            )
        )

        val request = GeminiRequest(
            contents = contents,
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = systemInstructionText))
            ),
            generationConfig = GeminiGenerationConfig(
                temperature = 0.7f,
                topP = 0.95f,
                topK = 40
            )
        )

        // Try primary model first with exponential backoff, then fallback to lite model
        val modelsToTry = listOf(PRIMARY_MODEL, FALLBACK_MODEL)
        var lastException: Exception? = null

        for (model in modelsToTry) {
            var retries = 2
            var backoffMs = 1500L

            while (retries >= 0) {
                try {
                    val response = api.generateContent(
                        model = model,
                        apiKey = apiKey,
                        request = request
                    )
                    val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!responseText.isNullOrBlank()) {
                        return@withContext Result.success(responseText)
                    } else {
                        return@withContext Result.failure(
                            IllegalStateException("No response received from Gemini Study Assistant.")
                        )
                    }
                } catch (e: HttpException) {
                    lastException = e
                    if (e.code() == 429) {
                        Log.w(TAG, "HTTP 429 on model $model (retries left: $retries). Waiting ${backoffMs}ms...")
                        if (retries > 0) {
                            delay(backoffMs)
                            backoffMs *= 2
                            retries--
                            continue
                        } else {
                            // Break out of retry loop to try fallback model
                            break
                        }
                    } else if (e.code() == 503 && retries > 0) {
                        delay(1000L)
                        retries--
                        continue
                    } else {
                        val errorMsg = when (e.code()) {
                            400 -> "Invalid request format to Gemini API."
                            403 -> "Gemini API key is invalid or unauthorized."
                            404 -> "Requested Gemini model is unavailable."
                            else -> "Gemini API error (HTTP ${e.code()})."
                        }
                        return@withContext Result.failure(IllegalStateException(errorMsg, e))
                    }
                } catch (e: Exception) {
                    lastException = e
                    Log.e(TAG, "Error executing request with model $model: ${e.message}", e)
                    break
                }
            }
        }

        // If we reach here, all retries and fallback models were exhausted
        val finalErrorMessage = if (lastException is HttpException && lastException.code() == 429) {
            "Rate limit reached (HTTP 429 - Too Many Requests). Please wait 15–30 seconds before sending another question or check your API quota in AI Studio."
        } else {
            lastException?.message ?: "Unable to connect to Gemini Study Coach. Please check your internet connection."
        }

        Result.failure(IllegalStateException(finalErrorMessage, lastException))
    }

    /**
     * Generate quick step-by-step concept breakdown.
     */
    suspend fun explainConcept(
        topic: String,
        subject: String,
        gradeLevel: GradeLevel
    ): Result<String> {
        val prompt = "Please provide a comprehensive yet concise revision explanation of '$topic' for $subject at ${gradeLevel.displayName} level. Include definition, key formulas/laws, a practical worked example, and common exam pitfalls to avoid."
        return askStudyTutor(prompt, subject, gradeLevel)
    }

    /**
     * Generate active-recall practice questions.
     */
    suspend fun generatePracticeQuiz(
        topic: String,
        subject: String,
        gradeLevel: GradeLevel
    ): Result<String> {
        val prompt = "Generate 3 high-yield exam practice questions on '$topic' for $subject (${gradeLevel.displayName}). Include the questions first, followed by clear step-by-step model solutions and marking criteria."
        return askStudyTutor(prompt, subject, gradeLevel)
    }

    /**
     * Generate quick formula sheet & key summary notes.
     */
    suspend fun generateCheatSheet(
        topic: String,
        subject: String,
        gradeLevel: GradeLevel
    ): Result<String> {
        val prompt = "Generate a quick revision cheat sheet for '$topic' in $subject (${gradeLevel.displayName}). Include core definitions, essential equations/dates/rules, and 3 memory mnemonics."
        return askStudyTutor(prompt, subject, gradeLevel)
    }
}
