package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.TimetableSlotEntity
import com.example.model.GradeLevel
import com.example.model.SubjectCategory
import com.example.model.TimerMode
import com.example.ui.MainUiState
import com.example.ui.components.formatEpochTime
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyScheduleScreen(
    uiState: MainUiState,
    onAddSlot: (day: Int, hour: Int, min: Int, duration: Int, subject: String, topic: String, grade: GradeLevel, color: Long) -> Unit,
    onDeleteSlot: (TimetableSlotEntity) -> Unit,
    onSetTimerMode: (TimerMode) -> Unit,
    onSetTimerSubject: (String) -> Unit,
    onSetAmbientSound: (String) -> Unit,
    onToggleTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onSendGeminiQuestion: (String?) -> Unit = {},
    onExplainConcept: (topic: String, subject: String) -> Unit = { _, _ -> },
    onGeneratePracticeQuiz: (topic: String, subject: String) -> Unit = { _, _ -> },
    onGenerateCheatSheet: (topic: String, subject: String) -> Unit = { _, _ -> },
    onClearGeminiChat: () -> Unit = {},
    onRetryLastQuestion: () -> Unit = {},
    onSetGeminiInput: (String) -> Unit = {},
    onSetGeminiSubject: (String) -> Unit = {},
    onSetGeminiTopic: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedSection by remember { mutableStateOf(0) } // 0 = Focus Timer, 1 = Weekly Timetable, 2 = Gemini Study Coach
    var selectedDayOfWeek by remember {
        val cal = Calendar.getInstance()
        val dow = when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            Calendar.SUNDAY -> 7
            else -> 1
        }
        mutableStateOf(dow)
    }
    var showAddSlotDialog by remember { mutableStateOf(false) }

    val days = listOf(
        1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu", 5 to "Fri", 6 to "Sat", 7 to "Sun"
    )

    val daySlots = uiState.timetableSlots.filter { it.dayOfWeek == selectedDayOfWeek }

    Scaffold(
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Sub-Navigation Tabs: Focus Timer, Weekly Timetable, and Gemini Study Coach
            TabRow(
                selectedTabIndex = selectedSection,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .height(44.dp)
            ) {
                Tab(
                    selected = selectedSection == 0,
                    onClick = { selectedSection = 0 },
                    text = { Text("Timer", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_focus_timer")
                )
                Tab(
                    selected = selectedSection == 1,
                    onClick = { selectedSection = 1 },
                    text = { Text("Timetable", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_timetable")
                )
                Tab(
                    selected = selectedSection == 2,
                    onClick = { selectedSection = 2 },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (selectedSection == 2) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text("Gemini Study", fontWeight = FontWeight.Bold)
                        }
                    },
                    modifier = Modifier.testTag("tab_gemini_study")
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (selectedSection) {
                0 -> {
                    // Focus / Pomodoro Timer View
                    FocusTimerSection(
                        uiState = uiState,
                        onSetTimerMode = onSetTimerMode,
                        onSetTimerSubject = onSetTimerSubject,
                        onSetAmbientSound = onSetAmbientSound,
                        onToggleTimer = onToggleTimer,
                        onResetTimer = onResetTimer
                    )
                }
                1 -> {
                    // Weekly Timetable View
                    WeeklyTimetableSection(
                        selectedDayOfWeek = selectedDayOfWeek,
                        days = days,
                        daySlots = daySlots,
                        onSelectDay = { selectedDayOfWeek = it },
                        onOpenAddSlot = { showAddSlotDialog = true },
                        onDeleteSlot = onDeleteSlot
                    )
                }
                else -> {
                    // Gemini Study Coach View (Exclusively for Study)
                    GeminiStudyCoachSection(
                        uiState = uiState,
                        onSendQuestion = onSendGeminiQuestion,
                        onExplainConcept = onExplainConcept,
                        onGeneratePracticeQuiz = onGeneratePracticeQuiz,
                        onGenerateCheatSheet = onGenerateCheatSheet,
                        onClearChat = onClearGeminiChat,
                        onRetryLastQuestion = onRetryLastQuestion,
                        onSetInput = onSetGeminiInput,
                        onSetSubject = onSetGeminiSubject,
                        onSetTopic = onSetGeminiTopic
                    )
                }
            }
        }
    }

    if (showAddSlotDialog) {
        AddSlotDialog(
            gradeLevel = uiState.selectedGrade,
            initialDay = selectedDayOfWeek,
            onDismiss = { showAddSlotDialog = false },
            onSave = { day, hour, min, dur, subj, top, grade, color ->
                onAddSlot(day, hour, min, dur, subj, top, grade, color)
                showAddSlotDialog = false
            }
        )
    }
}

@Composable
fun FocusTimerSection(
    uiState: MainUiState,
    onSetTimerMode: (TimerMode) -> Unit,
    onSetTimerSubject: (String) -> Unit,
    onSetAmbientSound: (String) -> Unit,
    onToggleTimer: () -> Unit,
    onResetTimer: () -> Unit
) {
    val minutes = uiState.timerSecondsRemaining / 60
    val seconds = uiState.timerSecondsRemaining % 60
    val formattedTime = String.format("%02d:%02d", minutes, seconds)

    val totalDurationSeconds = if (uiState.isBreakActive) {
        uiState.timerMode.breakMinutes * 60
    } else {
        uiState.timerMode.workMinutes * 60
    }

    val progress = (uiState.timerSecondsRemaining.toFloat() / totalDurationSeconds.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Mode Selector Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                TimerMode.entries.forEach { mode ->
                    val isSelected = uiState.timerMode == mode
                    item {
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetTimerMode(mode) },
                            label = { Text(mode.title) },
                            leadingIcon = if (isSelected) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            modifier = Modifier.testTag("mode_${mode.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // Circular Timer Display
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("timer_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Status tag: Study vs Rest
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (uiState.isBreakActive) Color(0xFFD1FAE5) else MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = if (uiState.isBreakActive) "Rest Break Active" else "${uiState.timerSubject} Study",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.isBreakActive) Color(0xFF059669) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Circular Progress Canvas
                    val primaryColor = if (uiState.isBreakActive) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                    val trackColor = MaterialTheme.colorScheme.surfaceVariant

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(200.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeWidth = 14.dp.toPx()
                            val radius = (size.minDimension - strokeWidth) / 2
                            val center = Offset(size.width / 2, size.height / 2)

                            // Track
                            drawCircle(
                                color = trackColor,
                                radius = radius,
                                center = center,
                                style = Stroke(width = strokeWidth)
                            )

                            // Animated Sweep
                            drawArc(
                                color = primaryColor,
                                startAngle = -90f,
                                sweepAngle = progress * 360f,
                                useCenter = false,
                                topLeft = Offset(center.x - radius, center.y - radius),
                                size = Size(radius * 2, radius * 2),
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = formattedTime,
                                style = MaterialTheme.typography.displayMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (uiState.isTimerRunning) "In Flow State" else "Paused",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Timer Control Buttons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedIconButton(
                            onClick = onResetTimer,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("reset_timer_btn")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reset Timer")
                        }

                        Button(
                            onClick = onToggleTimer,
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (uiState.isTimerRunning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier
                                .size(64.dp)
                                .testTag("toggle_timer_btn")
                        ) {
                            Icon(
                                imageVector = if (uiState.isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (uiState.isTimerRunning) "Pause" else "Start",
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Cycle indicator
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${uiState.pomodoroCyclesCompleted}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Cycles",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Subject Selector for Study Session
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Studying for Subject:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SubjectCategory.entries.forEach { cat ->
                            val isSelected = uiState.timerSubject == cat.displayName
                            item {
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { onSetTimerSubject(cat.displayName) },
                                    label = { Text(cat.displayName) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Focus Soundscapes / Ambient White Noise
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Headphones, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "Focus Ambient Soundscape:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("None", "Lofi Rain", "Library Silence", "Alpha Waves", "Forest Breeze").forEach { sound ->
                            val isSelected = uiState.selectedAmbientSound == sound
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSetAmbientSound(sound) },
                                label = { Text(sound) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Recent Study Sessions Log
        if (uiState.studySessions.isNotEmpty()) {
            item {
                Text(
                    text = "Recent Study Sessions",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            items(uiState.studySessions.take(4), key = { it.id }) { session ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = session.subject,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${session.mode} • ${session.durationMinutes} minutes",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Text(
                            text = formatEpochTime(session.timestampEpochMs),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WeeklyTimetableSection(
    selectedDayOfWeek: Int,
    days: List<Pair<Int, String>>,
    daySlots: List<TimetableSlotEntity>,
    onSelectDay: (Int) -> Unit,
    onOpenAddSlot: () -> Unit,
    onDeleteSlot: (TimetableSlotEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Day of week selector bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                days.forEach { (dow, name) ->
                    val isSelected = selectedDayOfWeek == dow
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectDay(dow) }
                            .testTag("timetable_day_$name")
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = name,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val dayName = days.firstOrNull { it.first == selectedDayOfWeek }?.second ?: "Day"
                Text(
                    text = "$dayName's Revision Plan",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = onOpenAddSlot,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("add_study_slot_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Block")
                }
            }
        }

        if (daySlots.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CalendarMonth,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "No study blocks scheduled for this day",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Add regular revision intervals to build steady exam readiness",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(daySlots, key = { it.id }) { slot ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("timetable_slot_${slot.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp, 50.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(slot.colorHex))
                            )
                            Column {
                                val timeFormatted = String.format("%02d:%02d", slot.startHour, slot.startMinute)
                                Text(
                                    text = "$timeFormatted • ${slot.durationMinutes} mins",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = slot.subject,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = slot.topic,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        IconButton(
                            onClick = { onDeleteSlot(slot) },
                            modifier = Modifier.testTag("delete_slot_${slot.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Delete block",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSlotDialog(
    gradeLevel: GradeLevel,
    initialDay: Int,
    onDismiss: () -> Unit,
    onSave: (day: Int, hour: Int, min: Int, duration: Int, subject: String, topic: String, grade: GradeLevel, color: Long) -> Unit
) {
    var selectedDay by remember { mutableStateOf(initialDay) }
    var selectedSubjectCategory by remember { mutableStateOf(SubjectCategory.MATHEMATICS) }
    var topic by remember { mutableStateOf("") }
    var startHour by remember { mutableStateOf("16") }
    var startMin by remember { mutableStateOf("00") }
    var durationMins by remember { mutableStateOf("60") }

    val days = listOf(1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu", 5 to "Fri", 6 to "Sat", 7 to "Sun")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("add_slot_dialog")
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("Add Study Block", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                item {
                    Text("Day of Week:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        days.forEach { (d, name) ->
                            FilterChip(
                                selected = selectedDay == d,
                                onClick = { selectedDay = d },
                                label = { Text(name) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                item {
                    Text("Subject:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SubjectCategory.entries.forEach { cat ->
                            item {
                                FilterChip(
                                    selected = selectedSubjectCategory == cat,
                                    onClick = { selectedSubjectCategory = cat },
                                    label = { Text(cat.displayName) }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text("Topic / Chapter Focus *") },
                        placeholder = { Text("e.g. Organic Chemistry Reactions") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("slot_topic_input"),
                        singleLine = true
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = startHour,
                            onValueChange = { startHour = it.filter { c -> c.isDigit() } },
                            label = { Text("Hour (0-23)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = startMin,
                            onValueChange = { startMin = it.filter { c -> c.isDigit() } },
                            label = { Text("Min (0-59)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = durationMins,
                            onValueChange = { durationMins = it.filter { c -> c.isDigit() } },
                            label = { Text("Duration (m)") },
                            modifier = Modifier.weight(1.2f),
                            singleLine = true
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (topic.isNotBlank()) {
                                    onSave(
                                        selectedDay,
                                        startHour.toIntOrNull() ?: 16,
                                        startMin.toIntOrNull() ?: 0,
                                        durationMins.toIntOrNull() ?: 60,
                                        selectedSubjectCategory.displayName,
                                        topic.trim(),
                                        gradeLevel,
                                        selectedSubjectCategory.colorHex
                                    )
                                }
                            },
                            modifier = Modifier.testTag("save_slot_btn")
                        ) {
                            Text("Save Block")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GeminiStudyCoachSection(
    uiState: MainUiState,
    onSendQuestion: (String?) -> Unit,
    onExplainConcept: (topic: String, subject: String) -> Unit,
    onGeneratePracticeQuiz: (topic: String, subject: String) -> Unit,
    onGenerateCheatSheet: (topic: String, subject: String) -> Unit,
    onClearChat: () -> Unit,
    onRetryLastQuestion: () -> Unit,
    onSetInput: (String) -> Unit,
    onSetSubject: (String) -> Unit,
    onSetTopic: (String) -> Unit
) {
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
    var customTopic by remember { mutableStateOf("") }

    val suggestedTopics = when (uiState.geminiStudySelectedSubject) {
        "Mathematics & Calculus" -> listOf("Quadratic Equations", "Differential Calculus", "Trigonometric Identities", "Euclidean Geometry", "Probability")
        "Physical Sciences" -> listOf("Newton's Laws of Motion", "Organic Chemistry", "Electric Circuits", "Doppler Effect", "Chemical Equilibrium")
        "Life Sciences / Biology" -> listOf("Cellular Respiration", "DNA Replication & RNA", "Human Endocrine System", "Genetics & Inheritance", "Meiosis")
        "English Home Language" -> listOf("Shakespeare Literary Analysis", "Poetry Analysis Techniques", "Argumentative Essay Structure", "Figurative Language")
        "History & Social Studies" -> listOf("Cold War Tensions", "The French Revolution", "Civil Rights Movement", "South African Democratic Transition")
        "Accounting & Business" -> listOf("Balance Sheet Adjustments", "Cash Flow Statements", "Break-Even Analysis", "Cost Accounting")
        else -> listOf("Key Chapter Summary", "Exam Definitions", "Worked Problem Examples", "Formula Memory Sheet")
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Study Coach Header Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("gemini_study_banner"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gemini AI Study Coach",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Dedicated High School study tutor for ${uiState.selectedGrade.displayName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                        if (uiState.geminiStudyMessages.isNotEmpty()) {
                            IconButton(
                                onClick = onClearChat,
                                modifier = Modifier.testTag("clear_gemini_chat_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Clear Chat",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }
            }
        }

        // Subject Selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Subject Focus:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SubjectCategory.entries.forEach { cat ->
                            val isSelected = uiState.geminiStudySelectedSubject == cat.displayName
                            item {
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        onSetSubject(cat.displayName)
                                    },
                                    label = { Text(cat.displayName) },
                                    modifier = Modifier.testTag("gemini_subject_${cat.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        }

        // Topic Input & Quick Study Generators
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Study Topic or Question:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = customTopic,
                        onValueChange = {
                            customTopic = it
                            onSetTopic(it)
                        },
                        placeholder = { Text("e.g. Organic Chemistry reactions, Calculus rules...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gemini_topic_input"),
                        singleLine = true,
                        leadingIcon = {
                            Icon(Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                    )

                    // Suggested high-yield topics
                    Text(
                        text = "Suggested High-Yield Topics:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        suggestedTopics.forEach { topic ->
                            item {
                                SuggestionChip(
                                    onClick = {
                                        customTopic = topic
                                        onSetTopic(topic)
                                    },
                                    label = { Text(topic) }
                                )
                            }
                        }
                    }

                    // 3 Study Generator Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val topic = customTopic.ifBlank { "Core Summary" }
                                onExplainConcept(topic, uiState.geminiStudySelectedSubject)
                            },
                            enabled = !uiState.isGeminiStudyLoading,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("explain_concept_btn"),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                        ) {
                            Icon(Icons.Default.Lightbulb, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Explain", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val topic = customTopic.ifBlank { "Exam Questions" }
                                onGeneratePracticeQuiz(topic, uiState.geminiStudySelectedSubject)
                            },
                            enabled = !uiState.isGeminiStudyLoading,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("practice_quiz_btn"),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                        ) {
                            Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Practice", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val topic = customTopic.ifBlank { "Formulas" }
                                onGenerateCheatSheet(topic, uiState.geminiStudySelectedSubject)
                            },
                            enabled = !uiState.isGeminiStudyLoading,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1.1f)
                                .testTag("cheat_sheet_btn"),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                        ) {
                            Icon(Icons.Default.Notes, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Cheat Sheet", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Error message if any
        if (uiState.geminiStudyError != null) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gemini_error_container"),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error
                            )
                            Text(
                                text = "Study Coach Notice",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Text(
                            text = uiState.geminiStudyError,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            FilledTonalButton(
                                onClick = onRetryLastQuestion,
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("gemini_retry_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Retry Question", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        // Chat History & Q&A Stream
        if (uiState.geminiStudyMessages.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = "Ask Gemini Any High School Study Question",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Get step-by-step concept breakdowns, practice exam questions, formula summaries, and homework assistance.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(uiState.geminiStudyMessages, key = { it.id }) { message ->
                val isStudent = message.sender == com.example.data.api.MessageSender.STUDENT

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalAlignment = if (isStudent) Alignment.End else Alignment.Start
                ) {
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = if (isStudent) Arrangement.End else Arrangement.Start,
                        modifier = Modifier.fillMaxWidth(0.95f)
                    ) {
                        if (!isStudent) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(30.dp)
                                    .padding(top = 2.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        Surface(
                            shape = RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isStudent) 16.dp else 4.dp,
                                bottomEnd = if (isStudent) 4.dp else 16.dp
                            ),
                            color = if (isStudent) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.surface
                            },
                            tonalElevation = if (isStudent) 0.dp else 3.dp,
                            modifier = Modifier.testTag("gemini_message_${message.id}")
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                if (!isStudent) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Gemini Study Coach",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        IconButton(
                                            onClick = {
                                                clipboardManager.setText(
                                                    androidx.compose.ui.text.AnnotatedString(message.text)
                                                )
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ContentCopy,
                                                contentDescription = "Copy Study Notes",
                                                modifier = Modifier.size(14.dp),
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                }

                                Text(
                                    text = message.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isStudent) {
                                        MaterialTheme.colorScheme.onPrimary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Loading Indicator
        if (uiState.isGeminiStudyLoading) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.5.dp)
                        Text(
                            text = "Gemini Study Coach is preparing your answer...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Bottom Direct Chat Input
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = uiState.geminiStudyPromptInput,
                        onValueChange = onSetInput,
                        placeholder = { Text("Ask a specific study or homework question...") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("gemini_study_input"),
                        maxLines = 3,
                        shape = RoundedCornerShape(12.dp)
                    )

                    IconButton(
                        onClick = { onSendQuestion(null) },
                        enabled = uiState.geminiStudyPromptInput.isNotBlank() && !uiState.isGeminiStudyLoading,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (uiState.geminiStudyPromptInput.isNotBlank() && !uiState.isGeminiStudyLoading)
                                    MaterialTheme.colorScheme.primary
                                else
                                    MaterialTheme.colorScheme.surfaceVariant
                            )
                            .testTag("gemini_study_send_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send to Gemini",
                            tint = if (uiState.geminiStudyPromptInput.isNotBlank() && !uiState.isGeminiStudyLoading)
                                MaterialTheme.colorScheme.onPrimary
                            else
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

