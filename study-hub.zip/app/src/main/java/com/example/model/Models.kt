package com.example.model

enum class GradeLevel(val displayName: String, val shortName: String) {
    GRADE_10("Grade 10", "Gr 10"),
    GRADE_11("Grade 11", "Gr 11"),
    GRADE_12("Grade 12", "Gr 12");

    companion object {
        fun fromString(value: String): GradeLevel {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) || it.displayName.equals(value, ignoreCase = true) || it.shortName.equals(value, ignoreCase = true) } ?: GRADE_11
        }
        fun fromName(value: String): GradeLevel = fromString(value)
    }
}

enum class SubjectCategory(val displayName: String, val colorHex: Long) {
    MATHEMATICS("Mathematics & Calculus", 0xFF3B82F6), // Blue
    PHYSICAL_SCIENCES("Physical Sciences (Physics/Chem)", 0xFF8B5CF6), // Purple
    LIFE_SCIENCES("Life Sciences (Biology)", 0xFF10B981), // Green
    ENGLISH("English Language & Lit", 0xFFF59E0B), // Amber
    HISTORY("History & Social Studies", 0xFFEC4899), // Pink
    GEOGRAPHY("Geography", 0xFF06B6D4), // Cyan
    ECONOMICS("Economics & Business", 0xFF6366F1), // Indigo
    COMPUTER_SCIENCE("Computer Science / IT", 0xFF14B8A6), // Teal
    ACCOUNTING("Accounting", 0xFF84CC16), // Lime
    OTHER("Other Subject", 0xFF64748B); // Slate
}

enum class AssignmentPriority(val displayName: String, val colorHex: Long) {
    URGENT("Urgent & High", 0xFFEF4444),
    MEDIUM("Medium Priority", 0xFFF59E0B),
    LOW("Low Priority", 0xFF10B981)
}

enum class AssignmentStatus(val displayName: String) {
    TODO("To Do"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed")
}

enum class TimerMode(val title: String, val workMinutes: Int, val breakMinutes: Int, val description: String) {
    CLASSIC_POMODORO("Classic Pomodoro", 25, 5, "25m Study • 5m Rest"),
    DEEP_FOCUS("Deep Work", 50, 10, "50m Intensive • 10m Rest"),
    EXAM_SPRINT("Exam Sprint", 45, 15, "45m Test Prep • 15m Rest"),
    QUICK_REVISION("Quick Revision", 15, 3, "15m Rapid Review")
}
