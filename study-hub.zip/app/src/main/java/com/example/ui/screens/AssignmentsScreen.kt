package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.AssignmentEntity
import com.example.model.*
import com.example.ui.MainUiState
import com.example.ui.components.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class ChecklistItem(val text: String, var done: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignmentsScreen(
    uiState: MainUiState,
    onAddAssignment: (title: String, subject: String, grade: GradeLevel, dueDate: Long, priority: AssignmentPriority, weight: Int, estHours: Double, notes: String, checklist: String) -> Unit,
    onUpdateAssignment: (AssignmentEntity) -> Unit,
    onToggleStatus: (AssignmentEntity) -> Unit,
    onDeleteAssignment: (AssignmentEntity) -> Unit,
    onSearchChange: (String) -> Unit,
    onStatusFilterChange: (AssignmentStatus?) -> Unit,
    onSubjectFilterChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var editingAssignment by remember { mutableStateOf<AssignmentEntity?>(null) }

    val gradeAssignments = uiState.assignments.filter { it.gradeLevel == uiState.selectedGrade.name }

    val filteredAssignments = gradeAssignments.filter { assignment ->
        val matchesSearch = assignment.title.contains(uiState.assignmentSearchQuery, ignoreCase = true) ||
                assignment.subject.contains(uiState.assignmentSearchQuery, ignoreCase = true) ||
                assignment.notes.contains(uiState.assignmentSearchQuery, ignoreCase = true)

        val matchesStatus = if (uiState.assignmentFilterStatus == null) true else assignment.status == uiState.assignmentFilterStatus.name
        val matchesSubject = if (uiState.assignmentSelectedSubject == "All") true else assignment.subject.contains(uiState.assignmentSelectedSubject, ignoreCase = true)

        matchesSearch && matchesStatus && matchesSubject
    }

    val completedCount = gradeAssignments.count { it.status == AssignmentStatus.COMPLETED.name }
    val totalCount = gradeAssignments.size

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Assignment") },
                text = { Text("New Assignment", fontWeight = FontWeight.Bold) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_assignment_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Search Box
            OutlinedTextField(
                value = uiState.assignmentSearchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("assignment_search_input"),
                placeholder = { Text("Search assignments, subjects, notes...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (uiState.assignmentSearchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Status Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = uiState.assignmentFilterStatus == null,
                        onClick = { onStatusFilterChange(null) },
                        label = { Text("All ($totalCount)") },
                        modifier = Modifier.testTag("filter_all")
                    )
                }
                AssignmentStatus.entries.forEach { status ->
                    val count = gradeAssignments.count { it.status == status.name }
                    item {
                        FilterChip(
                            selected = uiState.assignmentFilterStatus == status,
                            onClick = {
                                if (uiState.assignmentFilterStatus == status) {
                                    onStatusFilterChange(null)
                                } else {
                                    onStatusFilterChange(status)
                                }
                            },
                            label = { Text("${status.displayName} ($count)") },
                            modifier = Modifier.testTag("filter_${status.name.lowercase()}")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Completion Progress bar
            if (totalCount > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$completedCount of $totalCount completed (${(completedCount * 100 / totalCount)}%)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { (completedCount.toFloat() / totalCount.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = Color(0xFF10B981),
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Assignments List
            if (filteredAssignments.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Assignment,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = "No assignments found",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tap '+ New Assignment' to track a project or task for ${uiState.selectedGrade.displayName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    items(filteredAssignments, key = { it.id }) { assignment ->
                        AssignmentCard(
                            assignment = assignment,
                            onToggleStatus = { onToggleStatus(assignment) },
                            onEdit = { editingAssignment = assignment },
                            onDelete = { onDeleteAssignment(assignment) },
                            onChecklistUpdate = { updatedChecklistJson ->
                                onUpdateAssignment(assignment.copy(checklistJson = updatedChecklistJson))
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AssignmentDialog(
            gradeLevel = uiState.selectedGrade,
            initialAssignment = null,
            onDismiss = { showAddDialog = false },
            onSave = { title, subject, grade, dueDate, priority, weight, estHours, notes, checklist ->
                onAddAssignment(title, subject, grade, dueDate, priority, weight, estHours, notes, checklist)
                showAddDialog = false
            }
        )
    }

    if (editingAssignment != null) {
        AssignmentDialog(
            gradeLevel = uiState.selectedGrade,
            initialAssignment = editingAssignment,
            onDismiss = { editingAssignment = null },
            onSave = { title, subject, grade, dueDate, priority, weight, estHours, notes, checklist ->
                val current = editingAssignment!!
                onUpdateAssignment(
                    current.copy(
                        title = title,
                        subject = subject,
                        gradeLevel = grade.name,
                        dueDateEpochMs = dueDate,
                        priority = priority.name,
                        weightPercent = weight,
                        estimatedHours = estHours,
                        notes = notes,
                        checklistJson = checklist
                    )
                )
                editingAssignment = null
            }
        )
    }
}

@Composable
fun AssignmentCard(
    assignment: AssignmentEntity,
    onToggleStatus: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onChecklistUpdate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }
    val isCompleted = assignment.status == AssignmentStatus.COMPLETED.name

    val checklistItems = remember(assignment.checklistJson) {
        parseChecklist(assignment.checklistJson)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("assignment_card_${assignment.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleStatus,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("assignment_checkbox_${assignment.id}")
                    ) {
                        Icon(
                            imageVector = when (assignment.status) {
                                AssignmentStatus.COMPLETED.name -> Icons.Default.CheckCircle
                                AssignmentStatus.IN_PROGRESS.name -> Icons.Default.Pending
                                else -> Icons.Default.RadioButtonUnchecked
                            },
                            contentDescription = "Status",
                            tint = when (assignment.status) {
                                AssignmentStatus.COMPLETED.name -> Color(0xFF10B981)
                                AssignmentStatus.IN_PROGRESS.name -> Color(0xFF3B82F6)
                                else -> MaterialTheme.colorScheme.outline
                            },
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Text(
                            text = assignment.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                            textDecoration = if (isCompleted) TextDecoration.LineThrough else TextDecoration.None
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = assignment.subject,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(text = "•", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            Text(
                                text = "${assignment.weightPercent}% weight",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                PriorityBadge(priority = assignment.priority)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Due Date & Hours Info Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val daysLeft = getDaysRemaining(assignment.dueDateEpochMs)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Due ${formatEpochDate(assignment.dueDateEpochMs)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!isCompleted) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (daysLeft <= 1) Color(0xFFFEE2E2) else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = if (daysLeft == 0L) "Due Today!" else "${daysLeft}d left",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (daysLeft <= 1) Color(0xFFDC2626) else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    StatusBadge(status = assignment.status)
                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expand details"
                        )
                    }
                }
            }

            // Expandable Details (Notes, Checklist, Edit/Delete)
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(10.dp))

                    if (assignment.notes.isNotBlank()) {
                        Text(
                            text = "Instructions / Rubric Notes:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = assignment.notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Checklist items
                    if (checklistItems.isNotEmpty()) {
                        Text(
                            text = "Milestones & Subtasks:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        checklistItems.forEachIndexed { idx, item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        checklistItems[idx].done = !checklistItems[idx].done
                                        onChecklistUpdate(serializeChecklist(checklistItems))
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = item.done,
                                    onCheckedChange = { isChecked ->
                                        checklistItems[idx].done = isChecked
                                        onChecklistUpdate(serializeChecklist(checklistItems))
                                    },
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = item.text,
                                    style = MaterialTheme.typography.bodySmall,
                                    textDecoration = if (item.done) TextDecoration.LineThrough else TextDecoration.None,
                                    color = if (item.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onDelete,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("delete_assignment_${assignment.id}")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Delete")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onEdit,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("edit_assignment_${assignment.id}")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignmentDialog(
    gradeLevel: GradeLevel,
    initialAssignment: AssignmentEntity?,
    onDismiss: () -> Unit,
    onSave: (title: String, subject: String, grade: GradeLevel, dueDate: Long, priority: AssignmentPriority, weight: Int, estHours: Double, notes: String, checklist: String) -> Unit
) {
    var title by remember { mutableStateOf(initialAssignment?.title ?: "") }
    var selectedSubject by remember { mutableStateOf(initialAssignment?.subject ?: SubjectCategory.MATHEMATICS.displayName) }
    var priority by remember { mutableStateOf(if (initialAssignment != null) AssignmentPriority.valueOf(initialAssignment.priority) else AssignmentPriority.MEDIUM) }
    var weightPercent by remember { mutableStateOf(initialAssignment?.weightPercent?.toString() ?: "15") }
    var estimatedHours by remember { mutableStateOf(initialAssignment?.estimatedHours?.toString() ?: "2.5") }
    var notes by remember { mutableStateOf(initialAssignment?.notes ?: "") }
    var newChecklistText by remember { mutableStateOf("") }
    val checklist = remember {
        mutableStateListOf<ChecklistItem>().apply {
            if (initialAssignment != null) {
                addAll(parseChecklist(initialAssignment.checklistJson))
            }
        }
    }

    var daysFromNow by remember { mutableStateOf(3) }
    val dueDateEpochMs = remember(daysFromNow) {
        System.currentTimeMillis() + daysFromNow * 86400000L
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .testTag("assignment_dialog")
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = if (initialAssignment == null) "New Assignment for ${gradeLevel.displayName}" else "Edit Assignment",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Assignment Title *") },
                        placeholder = { Text("e.g. Calculus Curve Sketching Report") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("assignment_title_input"),
                        singleLine = true
                    )
                }

                item {
                    Text("Subject:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SubjectCategory.entries.take(6).forEach { category ->
                            val isSelected = selectedSubject == category.displayName
                            item {
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedSubject = category.displayName },
                                    label = { Text(category.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                                )
                            }
                        }
                    }
                }

                item {
                    Text("Priority:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AssignmentPriority.entries.forEach { p ->
                            FilterChip(
                                selected = priority == p,
                                onClick = { priority = p },
                                label = { Text(p.displayName) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = weightPercent,
                            onValueChange = { weightPercent = it.filter { c -> c.isDigit() } },
                            label = { Text("Weight (%)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = estimatedHours,
                            onValueChange = { estimatedHours = it },
                            label = { Text("Est. Hours") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                item {
                    Text("Due in Days:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1, 2, 3, 5, 7, 14).forEach { d ->
                            FilterChip(
                                selected = daysFromNow == d,
                                onClick = { daysFromNow = d },
                                label = { Text("${d}d") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Instructions & Rubric Notes") },
                        placeholder = { Text("Specific chapters, APA style, minimum word count...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }

                // Checklist builder
                item {
                    Text("Subtasks & Checklist:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newChecklistText,
                            onValueChange = { newChecklistText = it },
                            placeholder = { Text("Add milestone (e.g. Draft 1)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        FilledTonalIconButton(
                            onClick = {
                                if (newChecklistText.isNotBlank()) {
                                    checklist.add(ChecklistItem(newChecklistText.trim(), false))
                                    newChecklistText = ""
                                }
                            }
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add subtask")
                        }
                    }

                    checklist.forEachIndexed { idx, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "• ${item.text}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { checklist.removeAt(idx) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (title.isNotBlank()) {
                                    onSave(
                                        title.trim(),
                                        selectedSubject,
                                        gradeLevel,
                                        dueDateEpochMs,
                                        priority,
                                        weightPercent.toIntOrNull() ?: 10,
                                        estimatedHours.toDoubleOrNull() ?: 2.0,
                                        notes.trim(),
                                        serializeChecklist(checklist)
                                    )
                                }
                            },
                            modifier = Modifier.testTag("save_assignment_btn")
                        ) {
                            Text("Save")
                        }
                    }
                }
            }
        }
    }
}

fun parseChecklist(jsonStr: String): List<ChecklistItem> {
    val result = mutableListOf<ChecklistItem>()
    try {
        val array = JSONArray(jsonStr)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            result.add(ChecklistItem(obj.getString("text"), obj.getBoolean("done")))
        }
    } catch (e: Exception) {
        // empty fallback
    }
    return result
}

fun serializeChecklist(items: List<ChecklistItem>): String {
    val array = JSONArray()
    for (item in items) {
        val obj = JSONObject()
        obj.put("text", item.text)
        obj.put("done", item.done)
        array.put(obj)
    }
    return array.toString()
}
