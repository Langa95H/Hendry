package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.PastPaperEntity
import com.example.data.repository.PastPaperDocumentProvider
import com.example.model.ExamQuestion
import com.example.model.ExamSection
import com.example.model.ExamSubQuestion
import com.example.model.PastPaperDocument
import kotlinx.coroutines.delay

enum class DocumentViewMode(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    QUESTIONS_ONLY("Question Paper", Icons.Default.Description),
    MEMORANDUM_ONLY("Marking Memo", Icons.Default.FactCheck),
    PRACTICE_REVEAL("Practice & Reveal", Icons.Default.AutoStories)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PastPaperDocumentViewerDialog(
    paper: PastPaperEntity,
    onDismiss: () -> Unit,
    onLogScore: (PastPaperEntity) -> Unit,
    onAskGeminiQuestion: ((questionText: String, subject: String) -> Unit)? = null
) {
    val document: PastPaperDocument = remember(paper) {
        PastPaperDocumentProvider.getDocumentForPaper(paper)
    }

    var currentMode by remember { mutableStateOf(DocumentViewMode.QUESTIONS_ONLY) }
    var isLargeFont by remember { mutableStateOf(false) }
    var selectedQuestionIndex by remember { mutableStateOf<Int?>(null) } // null = All
    var showInstructionsDialog by remember { mutableStateOf(false) }
    var showScoreDialog by remember { mutableStateOf(false) }

    // Floating Simulation Timer state
    var isTimerRunning by remember { mutableStateOf(false) }
    var elapsedSeconds by remember { mutableStateOf(0) }

    val clipboardManager = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(isTimerRunning) {
        while (isTimerRunning) {
            delay(1000L)
            elapsedSeconds++
        }
    }

    val timerFormatted = remember(elapsedSeconds) {
        val hrs = elapsedSeconds / 3600
        val mins = (elapsedSeconds % 3600) / 60
        val secs = elapsedSeconds % 60
        if (hrs > 0) "%02d:%02d:%02d".format(hrs, mins, secs) else "%02d:%02d".format(mins, secs)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("past_paper_document_viewer"),
            color = MaterialTheme.colorScheme.background
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "${paper.year} ${paper.termOrSeason}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${paper.subject} • ${paper.paperNumber}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onDismiss, modifier = Modifier.testTag("doc_viewer_back_btn")) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                        },
                        actions = {
                            // Timer Chip
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = if (isTimerRunning) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clickable { isTimerRunning = !isTimerRunning }
                                    .padding(end = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (isTimerRunning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = timerFormatted,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            // Font size toggle
                            IconButton(onClick = { isLargeFont = !isLargeFont }) {
                                Icon(
                                    imageVector = if (isLargeFont) Icons.Default.FormatSize else Icons.Outlined.FormatSize,
                                    contentDescription = "Toggle Font Size",
                                    tint = if (isLargeFont) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }

                            // Log Score Button
                            IconButton(
                                onClick = { showScoreDialog = true },
                                modifier = Modifier.testTag("doc_viewer_score_btn")
                            ) {
                                Icon(Icons.Default.BookmarkAdded, contentDescription = "Log Score", tint = MaterialTheme.colorScheme.primary)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    // Mode Selector Tabs (Questions | Memo | Practice & Reveal)
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ) {
                        TabRow(
                            selectedTabIndex = currentMode.ordinal,
                            containerColor = Color.Transparent,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            DocumentViewMode.entries.forEach { mode ->
                                Tab(
                                    selected = currentMode == mode,
                                    onClick = { currentMode = mode },
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(mode.icon, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Text(
                                                text = mode.title,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = if (currentMode == mode) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }
                                    },
                                    modifier = Modifier.testTag("doc_tab_${mode.name.lowercase()}")
                                )
                            }
                        }
                    }

                    // Question Quick Jump Navigation Row
                    val allQuestions = remember(document) {
                        document.sections.flatMap { it.questions }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            item {
                                FilterChip(
                                    selected = selectedQuestionIndex == null,
                                    onClick = { selectedQuestionIndex = null },
                                    label = { Text("All Questions") },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("filter_q_all")
                                )
                            }
                            itemsIndexed(allQuestions) { index, q ->
                                FilterChip(
                                    selected = selectedQuestionIndex == index,
                                    onClick = { selectedQuestionIndex = if (selectedQuestionIndex == index) null else index },
                                    label = { Text("${q.questionNumber} (${q.totalMarks}m)") },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("filter_q_$index")
                                )
                            }
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // Render Sections and Questions
                    val visibleQuestionsWithSection = remember(selectedQuestionIndex, document) {
                        if (selectedQuestionIndex != null && selectedQuestionIndex!! in allQuestions.indices) {
                            val targetQ = allQuestions[selectedQuestionIndex!!]
                            val sec = document.sections.firstOrNull { it.questions.contains(targetQ) }
                            if (sec != null) listOf(sec to listOf(targetQ)) else emptyList()
                        } else {
                            document.sections.map { it to it.questions }
                        }
                    }

                    // Document Body
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
                    ) {
                        // Official Exam Document Header Banner
                        item {
                            OfficialExamHeaderBanner(
                                document = document,
                                onOpenInstructions = { showInstructionsDialog = true }
                            )
                        }

                        visibleQuestionsWithSection.forEach { (section, questions) ->
                            item {
                                SectionHeaderCard(section = section, isLargeFont = isLargeFont)
                            }

                            items(questions, key = { "${section.sectionLetter}_${it.questionNumber}" }) { question ->
                                QuestionCard(
                                    question = question,
                                    subject = paper.subject,
                                    mode = currentMode,
                                    isLargeFont = isLargeFont,
                                    onAskGemini = onAskGeminiQuestion
                                )
                            }
                        }

                        // Bottom Action Footer
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "Finished Practicing This Paper?",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Record your test marks to track your 10-year trend analysis.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        textAlign = TextAlign.Center
                                    )
                                    Button(
                                        onClick = { showScoreDialog = true },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.testTag("doc_footer_log_score")
                                    ) {
                                        Icon(Icons.Default.Scoreboard, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Log Marks & Key Feedback")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Instructions Dialog
    if (showInstructionsDialog) {
        AlertDialog(
            onDismissRequest = { showInstructionsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Examination Instructions")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    document.generalInstructions.forEachIndexed { i, inst ->
                        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${i + 1}.", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text(inst, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showInstructionsDialog = false }) {
                    Text("Understood")
                }
            }
        )
    }

    // Score Logging Dialog
    if (showScoreDialog) {
        com.example.ui.screens.EditPastPaperDialog(
            paper = paper,
            onDismiss = { showScoreDialog = false },
            onSave = { updated ->
                onLogScore(updated)
                showScoreDialog = false
            }
        )
    }
}

@Composable
fun OfficialExamHeaderBanner(
    document: PastPaperDocument,
    onOpenInstructions: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("official_exam_header"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Republic / Header Crest line
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = document.examTitle,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Text(
                    text = "${document.year} • ${document.grade}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = document.subject,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "${document.paperCode} • ${document.termOrSeason}",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )

            Divider(modifier = Modifier.padding(vertical = 4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Outlined.Timer, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.outline)
                        Text(
                            text = "${document.durationMinutes / 60} Hours (${document.durationMinutes} mins)",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Outlined.Grade, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.outline)
                        Text(
                            text = "Total: ${document.totalMarks} Marks",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                TextButton(
                    onClick = onOpenInstructions,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Outlined.HelpOutline, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Instructions", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun SectionHeaderCard(
    section: ExamSection,
    isLargeFont: Boolean
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = section.sectionLetter,
                    style = if (isLargeFont) MaterialTheme.typography.labelLarge else MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
                Text(
                    text = section.sectionTitle,
                    style = if (isLargeFont) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Text(
                    text = "[${section.totalMarks} Marks]",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun QuestionCard(
    question: ExamQuestion,
    subject: String,
    mode: DocumentViewMode,
    isLargeFont: Boolean,
    onAskGemini: ((questionText: String, subject: String) -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("question_card_${question.questionNumber.replace(" ", "_")}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Question Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = question.questionNumber,
                        style = if (isLargeFont) MaterialTheme.typography.titleMedium else MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = question.topicTitle,
                        style = if (isLargeFont) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = "[${question.totalMarks} Marks]",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Context / Stimulus text if any (e.g. Text Passage, Circuit description)
            if (!question.contextOrStimulus.isNullOrBlank()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            Icons.Default.MenuBook,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = question.contextOrStimulus,
                            style = if (isLargeFont) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Serif,
                            lineHeight = if (isLargeFont) 22.sp else 18.sp
                        )
                    }
                }
            }

            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // Sub Questions
            question.subQuestions.forEach { subQ ->
                SubQuestionItemView(
                    subQ = subQ,
                    subject = subject,
                    mode = mode,
                    isLargeFont = isLargeFont,
                    onAskGemini = onAskGemini
                )
            }
        }
    }
}

@Composable
fun SubQuestionItemView(
    subQ: ExamSubQuestion,
    subject: String,
    mode: DocumentViewMode,
    isLargeFont: Boolean,
    onAskGemini: ((questionText: String, subject: String) -> Unit)? = null
) {
    var isAnswerRevealed by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Question Text Row (shown in QUESTIONS_ONLY and PRACTICE_REVEAL modes)
        if (mode == DocumentViewMode.QUESTIONS_ONLY || mode == DocumentViewMode.PRACTICE_REVEAL) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = subQ.label,
                        style = if (isLargeFont) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subQ.questionText,
                        style = if (isLargeFont) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.bodyMedium,
                        lineHeight = if (isLargeFont) 24.sp else 20.sp
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = "(${subQ.marks})",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        // Practice & Reveal Action Bar
        if (mode == DocumentViewMode.PRACTICE_REVEAL) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { isAnswerRevealed = !isAnswerRevealed },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (isAnswerRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isAnswerRevealed) "Hide Model Solution" else "Reveal Model Solution",
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                if (onAskGemini != null) {
                    FilledTonalButton(
                        onClick = { onAskGemini(subQ.questionText, subject) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ask AI Tutor", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // Memorandum / Model Solution Box
        // Shown always in MEMORANDUM_ONLY mode, or when revealed in PRACTICE_REVEAL mode
        val showMemo = mode == DocumentViewMode.MEMORANDUM_ONLY || (mode == DocumentViewMode.PRACTICE_REVEAL && isAnswerRevealed)

        AnimatedVisibility(visible = showMemo) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF0FDF4), // Gentle mint green for memo
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF86EFAC))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = Color(0xFF16A34A)
                            )
                            Text(
                                text = "MEMORANDUM / MODEL SOLUTION [${subQ.label}]",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D)
                            )
                        }

                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString("${subQ.label}: ${subQ.memoAnswer}\nCriteria: ${subQ.markingTips}"))
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.ContentCopy,
                                contentDescription = "Copy solution",
                                modifier = Modifier.size(14.dp),
                                tint = Color(0xFF15803D)
                            )
                        }
                    }

                    Text(
                        text = subQ.memoAnswer,
                        style = if (isLargeFont) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF14532D),
                        lineHeight = if (isLargeFont) 22.sp else 18.sp
                    )

                    if (subQ.markingTips.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFDCFCE7),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(6.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    Icons.Default.FactCheck,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = Color(0xFF15803D)
                                )
                                Text(
                                    text = "Marking Guideline: ${subQ.markingTips}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF166534)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
