package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class StudyHubRepository(
    private val assignmentDao: AssignmentDao,
    private val timetableDao: TimetableDao,
    private val studySessionDao: StudySessionDao,
    private val examCountdownDao: ExamCountdownDao,
    private val flashcardDao: FlashcardDao,
    private val pastPaperDao: PastPaperDao,
    private val studentDao: StudentDao
) {
    val allAssignments: Flow<List<AssignmentEntity>> = assignmentDao.getAllAssignments()
    val allTimetableSlots: Flow<List<TimetableSlotEntity>> = timetableDao.getAllSlots()
    val allStudySessions: Flow<List<StudySessionEntity>> = studySessionDao.getAllSessions()
    val allExams: Flow<List<ExamCountdownEntity>> = examCountdownDao.getAllExams()
    val allFlashcards: Flow<List<FlashcardEntity>> = flashcardDao.getAllFlashcards()
    val allPastPapers: Flow<List<PastPaperEntity>> = pastPaperDao.getAllPastPapers()
    val currentStudent: Flow<StudentEntity?> = studentDao.getCurrentLoggedInStudent()
    val allStudents: Flow<List<StudentEntity>> = studentDao.getAllStudents()

    fun getTodayFocusMinutes(todayStartEpochMs: Long): Flow<Int?> {
        return studySessionDao.getMinutesSince(todayStartEpochMs)
    }

    suspend fun initializePresetDataIfEmpty() {
        if (flashcardDao.getCount() == 0) {
            PresetData.getDefaultAssignments().forEach { assignmentDao.insertAssignment(it) }
            timetableDao.insertSlots(PresetData.getDefaultTimetableSlots())
            examCountdownDao.insertExams(PresetData.getDefaultExams())
            flashcardDao.insertFlashcards(PresetData.getDefaultFlashcards())
            pastPaperDao.insertPastPapers(PresetData.getDefaultPastPapers())
        } else if (pastPaperDao.getCount() < 30) {
            pastPaperDao.insertPastPapers(PresetData.getDefaultPastPapers())
        }
        if (studentDao.getStudentCount() == 0) {
            PresetData.getDefaultStudents().forEach { studentDao.insertStudent(it) }
        }
    }

    // Student Authentication & Profile
    suspend fun registerStudent(
        fullName: String,
        email: String,
        passwordHash: String,
        gradeLevel: String,
        schoolName: String,
        targetAverage: Int,
        dailyGoalMinutes: Int,
        avatarKey: String,
        favoriteSubject: String = "Mathematics & Sciences",
        bio: String = ""
    ): Result<StudentEntity> {
        val existing = studentDao.getStudentByEmail(email.trim().lowercase())
        if (existing != null) {
            return Result.failure(Exception("An account with this email address already exists."))
        }
        // Log out any other logged in students first
        studentDao.logOutAllStudents()

        val newStudent = StudentEntity(
            fullName = fullName.trim(),
            email = email.trim().lowercase(),
            passwordHash = passwordHash,
            gradeLevel = gradeLevel,
            schoolName = schoolName.ifBlank { "High School Academy" },
            targetAverage = targetAverage,
            dailyGoalMinutes = dailyGoalMinutes,
            avatarKey = avatarKey,
            favoriteSubject = favoriteSubject,
            bio = bio,
            isLoggedIn = true
        )
        val generatedId = studentDao.insertStudent(newStudent)
        return Result.success(newStudent.copy(id = generatedId))
    }

    suspend fun loginStudent(email: String, password: String): Result<StudentEntity> {
        val student = studentDao.getStudentByEmail(email.trim().lowercase())
            ?: return Result.failure(Exception("No student account found with this email."))
        if (student.passwordHash != password) {
            return Result.failure(Exception("Incorrect password. Please try again."))
        }
        studentDao.logOutAllStudents()
        studentDao.setLoggedInStudent(student.id)
        return Result.success(student.copy(isLoggedIn = true))
    }

    suspend fun logout(): Result<Unit> {
        studentDao.logOutAllStudents()
        return Result.success(Unit)
    }

    suspend fun switchStudentAccount(studentId: Long): Result<Unit> {
        studentDao.setLoggedInStudent(studentId)
        return Result.success(Unit)
    }

    suspend fun updateStudentProfile(student: StudentEntity) {
        studentDao.updateStudent(student)
    }

    // Assignment actions
    suspend fun insertAssignment(assignment: AssignmentEntity): Long = assignmentDao.insertAssignment(assignment)
    suspend fun updateAssignment(assignment: AssignmentEntity) = assignmentDao.updateAssignment(assignment)
    suspend fun updateAssignmentStatus(id: Long, status: String) = assignmentDao.updateStatus(id, status)
    suspend fun deleteAssignment(assignment: AssignmentEntity) = assignmentDao.deleteAssignment(assignment)
    suspend fun deleteAssignmentById(id: Long) = assignmentDao.deleteAssignmentById(id)

    // Timetable actions
    suspend fun insertTimetableSlot(slot: TimetableSlotEntity): Long = timetableDao.insertSlot(slot)
    suspend fun updateTimetableSlot(slot: TimetableSlotEntity) = timetableDao.updateSlot(slot)
    suspend fun deleteTimetableSlot(slot: TimetableSlotEntity) = timetableDao.deleteSlot(slot)

    // Study Sessions
    suspend fun logStudySession(subject: String, durationMinutes: Int, mode: String, notes: String = ""): Long {
        return studySessionDao.insertSession(
            StudySessionEntity(
                subject = subject,
                durationMinutes = durationMinutes,
                mode = mode,
                notes = notes
            )
        )
    }

    // Exams
    suspend fun insertExam(exam: ExamCountdownEntity): Long = examCountdownDao.insertExam(exam)
    suspend fun updateExam(exam: ExamCountdownEntity) = examCountdownDao.updateExam(exam)
    suspend fun updateExamReadiness(id: Long, readiness: Int) = examCountdownDao.updateReadiness(id, readiness)
    suspend fun deleteExam(exam: ExamCountdownEntity) = examCountdownDao.deleteExam(exam)

    // Flashcards
    suspend fun insertFlashcard(flashcard: FlashcardEntity): Long = flashcardDao.insertFlashcard(flashcard)
    suspend fun updateFlashcardMastery(id: Long, isMastered: Boolean) = flashcardDao.updateMastery(id, isMastered)
    suspend fun deleteFlashcard(flashcard: FlashcardEntity) = flashcardDao.deleteFlashcard(flashcard)

    // Past Papers
    suspend fun insertPastPaper(paper: PastPaperEntity): Long = pastPaperDao.insertPastPaper(paper)
    suspend fun updatePastPaper(paper: PastPaperEntity) = pastPaperDao.updatePastPaper(paper)
    suspend fun deletePastPaper(paper: PastPaperEntity) = pastPaperDao.deletePastPaper(paper)
}
