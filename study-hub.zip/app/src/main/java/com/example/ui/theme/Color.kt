package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary & Brand Colors
val PrimaryIndigo = Color(0xFF4F46E5)
val PrimaryIndigoDark = Color(0xFF818CF8)
val PrimaryIndigoContainer = Color(0xFFEEF2FF)
val PrimaryIndigoContainerDark = Color(0xFF312E81)

val SecondaryCyan = Color(0xFF0284C7)
val SecondaryCyanDark = Color(0xFF38BDF8)
val SecondaryCyanContainer = Color(0xFFE0F2FE)
val SecondaryCyanContainerDark = Color(0xFF075985)

val TertiaryEmerald = Color(0xFF059669)
val TertiaryEmeraldDark = Color(0xFF34D399)
val TertiaryEmeraldContainer = Color(0xFFD1FAE5)
val TertiaryEmeraldContainerDark = Color(0xFF064E3B)

val AccentAmber = Color(0xFFD97706)
val AccentAmberDark = Color(0xFFFBBF24)

val AccentRose = Color(0xFFE11D48)
val AccentRoseDark = Color(0xFFFB7185)

// Neutral Backgrounds & Surfaces
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

val BackgroundDark = Color(0xFF0B0F19)
val SurfaceDark = Color(0xFF131B2E)
val SurfaceVariantDark = Color(0xFF1E293B)
val OutlineDark = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
