package com.example.model

data class ExamSubQuestion(
    val label: String, // e.g. "1.1.1" or "2.1"
    val questionText: String,
    val marks: Int,
    val memoAnswer: String, // Complete worked solution with marking ticks
    val markingTips: String = "",
    val formulaOrDiagramNote: String? = null,
    val suggestedTimeMinutes: Int = 3
)

data class ExamQuestion(
    val questionNumber: String, // e.g. "QUESTION 1"
    val topicTitle: String, // e.g. "ALGEBRA & EXPONENTS" or "NEWTON'S LAWS"
    val totalMarks: Int,
    val contextOrStimulus: String? = null, // passage, diagram description, data table
    val subQuestions: List<ExamSubQuestion>
)

data class ExamSection(
    val sectionLetter: String, // e.g. "SECTION A"
    val sectionTitle: String, // e.g. "ALGEBRA, EQUATIONS AND CALCULUS"
    val totalMarks: Int,
    val instructions: String? = null,
    val questions: List<ExamQuestion>
)

data class PastPaperDocument(
    val id: Long,
    val paperId: Long,
    val examTitle: String,
    val subject: String,
    val grade: String,
    val year: Int,
    val termOrSeason: String,
    val paperCode: String,
    val durationMinutes: Int = 180, // 3 hours default for standard matric papers
    val totalMarks: Int = 150,
    val generalInstructions: List<String>,
    val sections: List<ExamSection>
)
