package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AssignmentDao {
    @Query("SELECT * FROM assignments ORDER BY dueDateEpochMs ASC")
    fun getAllAssignments(): Flow<List<AssignmentEntity>>

    @Query("SELECT * FROM assignments WHERE id = :id")
    suspend fun getAssignmentById(id: Long): AssignmentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignment(assignment: AssignmentEntity): Long

    @Update
    suspend fun updateAssignment(assignment: AssignmentEntity)

    @Query("UPDATE assignments SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)

    @Delete
    suspend fun deleteAssignment(assignment: AssignmentEntity)

    @Query("DELETE FROM assignments WHERE id = :id")
    suspend fun deleteAssignmentById(id: Long)
}

@Dao
interface TimetableDao {
    @Query("SELECT * FROM timetable_slots ORDER BY dayOfWeek ASC, startHour ASC, startMinute ASC")
    fun getAllSlots(): Flow<List<TimetableSlotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSlot(slot: TimetableSlotEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSlots(slots: List<TimetableSlotEntity>)

    @Update
    suspend fun updateSlot(slot: TimetableSlotEntity)

    @Delete
    suspend fun deleteSlot(slot: TimetableSlotEntity)

    @Query("DELETE FROM timetable_slots WHERE id = :id")
    suspend fun deleteSlotById(id: Long)
}

@Dao
interface StudySessionDao {
    @Query("SELECT * FROM study_sessions ORDER BY timestampEpochMs DESC")
    fun getAllSessions(): Flow<List<StudySessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySessionEntity): Long

    @Query("SELECT SUM(durationMinutes) FROM study_sessions WHERE timestampEpochMs >= :sinceEpochMs")
    fun getMinutesSince(sinceEpochMs: Long): Flow<Int?>
}

@Dao
interface ExamCountdownDao {
    @Query("SELECT * FROM exam_countdowns ORDER BY examDateEpochMs ASC")
    fun getAllExams(): Flow<List<ExamCountdownEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExam(exam: ExamCountdownEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExams(exams: List<ExamCountdownEntity>)

    @Update
    suspend fun updateExam(exam: ExamCountdownEntity)

    @Query("UPDATE exam_countdowns SET readinessScore = :readiness WHERE id = :id")
    suspend fun updateReadiness(id: Long, readiness: Int)

    @Delete
    suspend fun deleteExam(exam: ExamCountdownEntity)

    @Query("DELETE FROM exam_countdowns WHERE id = :id")
    suspend fun deleteExamById(id: Long)
}

@Dao
interface FlashcardDao {
    @Query("SELECT * FROM flashcards ORDER BY id ASC")
    fun getAllFlashcards(): Flow<List<FlashcardEntity>>

    @Query("SELECT * FROM flashcards WHERE gradeLevel = :gradeLevel")
    fun getFlashcardsByGrade(gradeLevel: String): Flow<List<FlashcardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcard(flashcard: FlashcardEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcards(flashcards: List<FlashcardEntity>)

    @Query("UPDATE flashcards SET isMastered = :isMastered, timesReviewed = timesReviewed + 1 WHERE id = :id")
    suspend fun updateMastery(id: Long, isMastered: Boolean)

    @Delete
    suspend fun deleteFlashcard(flashcard: FlashcardEntity)

    @Query("SELECT COUNT(*) FROM flashcards")
    suspend fun getCount(): Int
}

@Dao
interface PastPaperDao {
    @Query("SELECT * FROM past_papers ORDER BY year DESC, paperNumber ASC")
    fun getAllPastPapers(): Flow<List<PastPaperEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPastPaper(paper: PastPaperEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPastPapers(papers: List<PastPaperEntity>)

    @Update
    suspend fun updatePastPaper(paper: PastPaperEntity)

    @Delete
    suspend fun deletePastPaper(paper: PastPaperEntity)

    @Query("SELECT COUNT(*) FROM past_papers")
    suspend fun getCount(): Int
}

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY fullName ASC")
    fun getAllStudents(): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students WHERE isLoggedIn = 1 LIMIT 1")
    fun getCurrentLoggedInStudent(): Flow<StudentEntity?>

    @Query("SELECT * FROM students WHERE email = :email LIMIT 1")
    suspend fun getStudentByEmail(email: String): StudentEntity?

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    suspend fun getStudentById(id: Long): StudentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: StudentEntity): Long

    @Update
    suspend fun updateStudent(student: StudentEntity)

    @Query("UPDATE students SET isLoggedIn = 0")
    suspend fun logOutAllStudents()

    @Query("UPDATE students SET isLoggedIn = CASE WHEN id = :id THEN 1 ELSE 0 END")
    suspend fun setLoggedInStudent(id: Long)

    @Delete
    suspend fun deleteStudent(student: StudentEntity)

    @Query("SELECT COUNT(*) FROM students")
    suspend fun getStudentCount(): Int
}

