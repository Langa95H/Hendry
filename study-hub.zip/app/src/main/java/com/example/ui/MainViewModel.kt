package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.repository.PresetData
import com.example.data.repository.RevisionGuideItem
import com.example.data.repository.StudyHubRepository
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

data class MainUiState(
    val selectedGrade: GradeLevel = GradeLevel.GRADE_12,
    val selectedTab: Int = 0, // 0 = Dashboard/Home, 1 = Assignments, 2 = Study & Timer, 3 = Exam Prep
    val assignments: List<AssignmentEntity> = emptyList(),
    val timetableSlots: List<TimetableSlotEntity> = emptyList(),
    val studySessions: List<StudySessionEntity> = emptyList(),
    val exams: List<ExamCountdownEntity> = emptyList(),
    val flashcards: List<FlashcardEntity> = emptyList(),
    val pastPapers: List<PastPaperEntity> = emptyList(),
    val revisionGuides: List<RevisionGuideItem> = emptyList(),
    val todayFocusMinutes: Int = 0,
    val dailyGoalMinutes: Int = 120,

    // Student Auth & Profile State
    val currentStudent: StudentEntity? = null,
    val allRegisteredStudents: List<StudentEntity> = emptyList(),
    val isAuthLoading: Boolean = false,
    val authErrorMessage: String? = null,
    val authSuccessMessage: String? = null,
    val isProfileDialogOpen: Boolean = false,
    val isEditProfileDialogOpen: Boolean = false,

    // Timer State
    val timerMode: TimerMode = TimerMode.CLASSIC_POMODORO,
    val timerSubject: String = "Mathematics & Calculus",
    val timerSecondsRemaining: Int = 25 * 60,
    val isTimerRunning: Boolean = false,
    val isBreakActive: Boolean = false,
    val pomodoroCyclesCompleted: Int = 0,
    val selectedAmbientSound: String = "None",

    // Filter states
    val assignmentFilterStatus: AssignmentStatus? = null,
    val assignmentSearchQuery: String = "",
    val assignmentSelectedSubject: String = "All",
    val examSelectedSubject: String = "All",
    val flashcardFilterMastered: Boolean? = null,
    val activeFlashcardIndex: Int = 0,
    val isCardFlipped: Boolean = false,

    // Gemini Study Coach State (Exclusively for Study & Revision)
    val geminiStudyMessages: List<com.example.data.api.StudyChatMessage> = emptyList(),
    val isGeminiStudyLoading: Boolean = false,
    val geminiStudyError: String? = null,
    val geminiStudyPromptInput: String = "",
    val geminiStudySelectedSubject: String = "Mathematics & Calculus",
    val geminiStudySelectedTopic: String = ""
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: StudyHubRepository
    private val geminiStudyService = com.example.data.api.GeminiStudyService()
    private val _uiState = MutableStateFlow(
        MainUiState(
            currentStudent = PresetData.getDefaultStudents().firstOrNull { it.isLoggedIn } ?: PresetData.getDefaultStudents().firstOrNull(),
            revisionGuides = PresetData.getRevisionGuides()
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null

    init {
        val db = AppDatabase.getInstance(application)
        repository = StudyHubRepository(
            db.assignmentDao(),
            db.timetableDao(),
            db.studySessionDao(),
            db.examCountdownDao(),
            db.flashcardDao(),
            db.pastPaperDao(),
            db.studentDao()
        )

        viewModelScope.launch {
            try {
                repository.initializePresetDataIfEmpty()
            } catch (e: Exception) {
                android.util.Log.e("MainViewModel", "Failed to seed preset data", e)
            }
        }

        observeData()
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.currentStudent
                .catch { e -> android.util.Log.e("MainViewModel", "Error in currentStudent flow", e) }
                .collect { student ->
                    _uiState.update { state ->
                        val grade = student?.gradeLevel?.let { GradeLevel.fromName(it) } ?: state.selectedGrade
                        val goal = student?.dailyGoalMinutes ?: state.dailyGoalMinutes
                        state.copy(
                            currentStudent = student,
                            selectedGrade = grade,
                            dailyGoalMinutes = goal
                        )
                    }
                }
        }
        viewModelScope.launch {
            repository.allStudents
                .catch { e -> android.util.Log.e("MainViewModel", "Error in allStudents flow", e) }
                .collect { students ->
                    _uiState.update { it.copy(allRegisteredStudents = students) }
                }
        }
        viewModelScope.launch {
            repository.allAssignments
                .catch { e -> android.util.Log.e("MainViewModel", "Error in allAssignments flow", e) }
                .collect { assignments ->
                    _uiState.update { it.copy(assignments = assignments) }
                }
        }
        viewModelScope.launch {
            repository.allTimetableSlots
                .catch { e -> android.util.Log.e("MainViewModel", "Error in allTimetableSlots flow", e) }
                .collect { slots ->
                    _uiState.update { it.copy(timetableSlots = slots) }
                }
        }
        viewModelScope.launch {
            repository.allStudySessions
                .catch { e -> android.util.Log.e("MainViewModel", "Error in allStudySessions flow", e) }
                .collect { sessions ->
                    val cal = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    val todayStart = cal.timeInMillis
                    val todayMinutes = sessions
                        .filter { it.timestampEpochMs >= todayStart }
                        .sumOf { it.durationMinutes }

                    _uiState.update { it.copy(studySessions = sessions, todayFocusMinutes = todayMinutes) }
                }
        }
        viewModelScope.launch {
            repository.allExams
                .catch { e -> android.util.Log.e("MainViewModel", "Error in allExams flow", e) }
                .collect { exams ->
                    _uiState.update { it.copy(exams = exams) }
                }
        }
        viewModelScope.launch {
            repository.allFlashcards
                .catch { e -> android.util.Log.e("MainViewModel", "Error in allFlashcards flow", e) }
                .collect { flashcards ->
                    _uiState.update { it.copy(flashcards = flashcards) }
                }
        }
        viewModelScope.launch {
            repository.allPastPapers
                .catch { e -> android.util.Log.e("MainViewModel", "Error in allPastPapers flow", e) }
                .collect { pastPapers ->
                    _uiState.update { it.copy(pastPapers = pastPapers) }
                }
        }
    }

    fun setGrade(grade: GradeLevel) {
        _uiState.update { it.copy(selectedGrade = grade, activeFlashcardIndex = 0, isCardFlipped = false) }
    }

    fun setTab(tabIndex: Int) {
        _uiState.update { it.copy(selectedTab = tabIndex) }
    }

    // Assignment Operations
    fun addAssignment(
        title: String,
        subject: String,
        gradeLevel: GradeLevel,
        dueDateEpochMs: Long,
        priority: AssignmentPriority,
        weightPercent: Int,
        estimatedHours: Double,
        notes: String,
        checklistJson: String
    ) {
        viewModelScope.launch {
            repository.insertAssignment(
                AssignmentEntity(
                    title = title,
                    subject = subject,
                    gradeLevel = gradeLevel.name,
                    dueDateEpochMs = dueDateEpochMs,
                    priority = priority.name,
                    status = AssignmentStatus.TODO.name,
                    weightPercent = weightPercent,
                    estimatedHours = estimatedHours,
                    notes = notes,
                    checklistJson = checklistJson
                )
            )
        }
    }

    fun updateAssignment(assignment: AssignmentEntity) {
        viewModelScope.launch {
            repository.updateAssignment(assignment)
        }
    }

    fun toggleAssignmentStatus(assignment: AssignmentEntity) {
        val nextStatus = when (assignment.status) {
            AssignmentStatus.TODO.name -> AssignmentStatus.IN_PROGRESS.name
            AssignmentStatus.IN_PROGRESS.name -> AssignmentStatus.COMPLETED.name
            else -> AssignmentStatus.TODO.name
        }
        viewModelScope.launch {
            repository.updateAssignmentStatus(assignment.id, nextStatus)
        }
    }

    fun deleteAssignment(assignment: AssignmentEntity) {
        viewModelScope.launch {
            repository.deleteAssignment(assignment)
        }
    }

    fun setAssignmentFilter(status: AssignmentStatus?) {
        _uiState.update { it.copy(assignmentFilterStatus = status) }
    }

    fun setAssignmentSearch(query: String) {
        _uiState.update { it.copy(assignmentSearchQuery = query) }
    }

    fun setAssignmentSubjectFilter(subject: String) {
        _uiState.update { it.copy(assignmentSelectedSubject = subject) }
    }

    // Timetable Operations
    fun addTimetableSlot(
        dayOfWeek: Int,
        startHour: Int,
        startMinute: Int,
        durationMinutes: Int,
        subject: String,
        topic: String,
        gradeLevel: GradeLevel,
        colorHex: Long
    ) {
        viewModelScope.launch {
            repository.insertTimetableSlot(
                TimetableSlotEntity(
                    dayOfWeek = dayOfWeek,
                    startHour = startHour,
                    startMinute = startMinute,
                    durationMinutes = durationMinutes,
                    subject = subject,
                    topic = topic,
                    gradeLevel = gradeLevel.name,
                    colorHex = colorHex
                )
            )
        }
    }

    fun deleteTimetableSlot(slot: TimetableSlotEntity) {
        viewModelScope.launch {
            repository.deleteTimetableSlot(slot)
        }
    }

    // Timer & Pomodoro Operations
    fun setTimerMode(mode: TimerMode) {
        timerJob?.cancel()
        _uiState.update {
            it.copy(
                timerMode = mode,
                timerSecondsRemaining = mode.workMinutes * 60,
                isTimerRunning = false,
                isBreakActive = false
            )
        }
    }

    fun setTimerSubject(subject: String) {
        _uiState.update { it.copy(timerSubject = subject) }
    }

    fun setAmbientSound(sound: String) {
        _uiState.update { it.copy(selectedAmbientSound = sound) }
    }

    fun toggleTimer() {
        if (_uiState.value.isTimerRunning) {
            pauseTimer()
        } else {
            startTimer()
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        _uiState.update { it.copy(isTimerRunning = true) }

        timerJob = viewModelScope.launch {
            while (_uiState.value.isTimerRunning && _uiState.value.timerSecondsRemaining > 0) {
                delay(1000)
                _uiState.update { it.copy(timerSecondsRemaining = it.timerSecondsRemaining - 1) }
            }

            if (_uiState.value.timerSecondsRemaining <= 0) {
                handleTimerCompletion()
            }
        }
    }

    private fun pauseTimer() {
        timerJob?.cancel()
        _uiState.update { it.copy(isTimerRunning = false) }
    }

    fun resetTimer() {
        timerJob?.cancel()
        val mode = _uiState.value.timerMode
        val duration = if (_uiState.value.isBreakActive) mode.breakMinutes * 60 else mode.workMinutes * 60
        _uiState.update {
            it.copy(
                timerSecondsRemaining = duration,
                isTimerRunning = false
            )
        }
    }

    private fun handleTimerCompletion() {
        val currentState = _uiState.value
        if (!currentState.isBreakActive) {
            // Work session completed! Log it to database
            val studyDuration = currentState.timerMode.workMinutes
            viewModelScope.launch {
                repository.logStudySession(
                    subject = currentState.timerSubject,
                    durationMinutes = studyDuration,
                    mode = currentState.timerMode.title,
                    notes = "Completed ${currentState.timerMode.title} study block"
                )
            }
            // Switch to break
            _uiState.update {
                it.copy(
                    isBreakActive = true,
                    timerSecondsRemaining = it.timerMode.breakMinutes * 60,
                    isTimerRunning = false,
                    pomodoroCyclesCompleted = it.pomodoroCyclesCompleted + 1
                )
            }
        } else {
            // Break finished, switch back to work
            _uiState.update {
                it.copy(
                    isBreakActive = false,
                    timerSecondsRemaining = it.timerMode.workMinutes * 60,
                    isTimerRunning = false
                )
            }
        }
    }

    // Flashcard & Study Deck Operations
    fun toggleCardFlip() {
        _uiState.update { it.copy(isCardFlipped = !it.isCardFlipped) }
    }

    fun nextCard(filteredCards: List<FlashcardEntity>) {
        if (filteredCards.isEmpty()) return
        val nextIdx = (_uiState.value.activeFlashcardIndex + 1) % filteredCards.size
        _uiState.update { it.copy(activeFlashcardIndex = nextIdx, isCardFlipped = false) }
    }

    fun prevCard(filteredCards: List<FlashcardEntity>) {
        if (filteredCards.isEmpty()) return
        val prevIdx = if (_uiState.value.activeFlashcardIndex - 1 < 0) filteredCards.size - 1 else _uiState.value.activeFlashcardIndex - 1
        _uiState.update { it.copy(activeFlashcardIndex = prevIdx, isCardFlipped = false) }
    }

    fun markCardMastery(card: FlashcardEntity, isMastered: Boolean, filteredCards: List<FlashcardEntity>) {
        viewModelScope.launch {
            repository.updateFlashcardMastery(card.id, isMastered)
        }
        nextCard(filteredCards)
    }

    fun addCustomFlashcard(
        gradeLevel: GradeLevel,
        subject: String,
        topic: String,
        question: String,
        answer: String,
        formulaOrHint: String
    ) {
        viewModelScope.launch {
            repository.insertFlashcard(
                FlashcardEntity(
                    gradeLevel = gradeLevel.name,
                    subject = subject,
                    topic = topic,
                    question = question,
                    answer = answer,
                    formulaOrHint = formulaOrHint,
                    isMastered = false,
                    timesReviewed = 0,
                    isUserCreated = true
                )
            )
        }
    }

    // Exam Countdown Operations
    fun addExam(
        title: String,
        subject: String,
        gradeLevel: GradeLevel,
        examDateEpochMs: Long,
        paperName: String,
        syllabusTopics: String,
        readinessScore: Int
    ) {
        viewModelScope.launch {
            repository.insertExam(
                ExamCountdownEntity(
                    title = title,
                    subject = subject,
                    gradeLevel = gradeLevel.name,
                    examDateEpochMs = examDateEpochMs,
                    paperName = paperName,
                    syllabusTopics = syllabusTopics,
                    readinessScore = readinessScore
                )
            )
        }
    }

    fun updateExamReadiness(exam: ExamCountdownEntity, score: Int) {
        viewModelScope.launch {
            repository.updateExamReadiness(exam.id, score)
        }
    }

    fun deleteExam(exam: ExamCountdownEntity) {
        viewModelScope.launch {
            repository.deleteExam(exam)
        }
    }

    // Past Papers
    fun addPastPaper(
        gradeLevel: GradeLevel,
        subject: String,
        year: Int,
        termOrSeason: String,
        paperNumber: String,
        totalMarks: Int,
        userScore: Int?,
        isCompleted: Boolean,
        isTimed: Boolean,
        keyLearnings: String
    ) {
        viewModelScope.launch {
            repository.insertPastPaper(
                PastPaperEntity(
                    gradeLevel = gradeLevel.name,
                    subject = subject,
                    year = year,
                    termOrSeason = termOrSeason,
                    paperNumber = paperNumber,
                    totalMarks = totalMarks,
                    userScore = userScore,
                    isCompleted = isCompleted,
                    isTimed = isTimed,
                    keyLearnings = keyLearnings
                )
            )
        }
    }

    fun updatePastPaper(paper: PastPaperEntity) {
        viewModelScope.launch {
            repository.updatePastPaper(paper)
        }
    }

    fun deletePastPaper(paper: PastPaperEntity) {
        viewModelScope.launch {
            repository.deletePastPaper(paper)
        }
    }

    // Student Authentication & Profile Management
    fun registerStudent(
        fullName: String,
        email: String,
        password: String,
        gradeLevel: GradeLevel,
        schoolName: String,
        targetAverage: Int,
        dailyGoalMinutes: Int,
        avatarKey: String,
        favoriteSubject: String = "Mathematics & Sciences",
        bio: String = ""
    ) {
        if (fullName.isBlank()) {
            _uiState.update { it.copy(authErrorMessage = "Please enter your full name.") }
            return
        }
        if (email.isBlank() || !email.contains("@")) {
            _uiState.update { it.copy(authErrorMessage = "Please enter a valid school/personal email.") }
            return
        }
        if (password.length < 4) {
            _uiState.update { it.copy(authErrorMessage = "Password must be at least 4 characters long.") }
            return
        }

        _uiState.update { it.copy(isAuthLoading = true, authErrorMessage = null, authSuccessMessage = null) }
        viewModelScope.launch {
            val result = repository.registerStudent(
                fullName = fullName,
                email = email,
                passwordHash = password,
                gradeLevel = gradeLevel.name,
                schoolName = schoolName,
                targetAverage = targetAverage,
                dailyGoalMinutes = dailyGoalMinutes,
                avatarKey = avatarKey,
                favoriteSubject = favoriteSubject,
                bio = bio
            )
            result.onSuccess { student ->
                _uiState.update {
                    it.copy(
                        isAuthLoading = false,
                        authErrorMessage = null,
                        authSuccessMessage = "Welcome, ${student.fullName}! Your student profile is ready.",
                        selectedGrade = gradeLevel,
                        dailyGoalMinutes = dailyGoalMinutes
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isAuthLoading = false,
                        authErrorMessage = error.message ?: "Failed to register account."
                    )
                }
            }
        }
    }

    fun loginStudent(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.update { it.copy(authErrorMessage = "Please provide both email and password.") }
            return
        }
        _uiState.update { it.copy(isAuthLoading = true, authErrorMessage = null, authSuccessMessage = null) }
        viewModelScope.launch {
            val result = repository.loginStudent(email, password)
            result.onSuccess { student ->
                val grade = GradeLevel.fromName(student.gradeLevel)
                _uiState.update {
                    it.copy(
                        isAuthLoading = false,
                        authErrorMessage = null,
                        authSuccessMessage = "Welcome back, ${student.fullName}!",
                        selectedGrade = grade,
                        dailyGoalMinutes = student.dailyGoalMinutes
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isAuthLoading = false,
                        authErrorMessage = error.message ?: "Login failed. Please check credentials."
                    )
                }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _uiState.update {
                it.copy(
                    currentStudent = null,
                    isProfileDialogOpen = false,
                    isEditProfileDialogOpen = false,
                    authErrorMessage = null,
                    authSuccessMessage = "You have been logged out safely."
                )
            }
        }
    }

    fun switchStudentAccount(studentId: Long) {
        viewModelScope.launch {
            repository.switchStudentAccount(studentId)
            _uiState.update { it.copy(isProfileDialogOpen = false) }
        }
    }

    fun updateStudentProfile(
        fullName: String,
        schoolName: String,
        gradeLevel: GradeLevel,
        targetAverage: Int,
        dailyGoalMinutes: Int,
        avatarKey: String,
        favoriteSubject: String,
        bio: String
    ) {
        val current = _uiState.value.currentStudent ?: return
        val updated = current.copy(
            fullName = fullName.trim().ifBlank { current.fullName },
            schoolName = schoolName.trim().ifBlank { current.schoolName },
            gradeLevel = gradeLevel.name,
            targetAverage = targetAverage,
            dailyGoalMinutes = dailyGoalMinutes,
            avatarKey = avatarKey,
            favoriteSubject = favoriteSubject,
            bio = bio
        )
        viewModelScope.launch {
            repository.updateStudentProfile(updated)
            _uiState.update {
                it.copy(
                    isEditProfileDialogOpen = false,
                    selectedGrade = gradeLevel,
                    dailyGoalMinutes = dailyGoalMinutes,
                    authSuccessMessage = "Profile updated successfully!"
                )
            }
        }
    }

    fun clearAuthMessages() {
        _uiState.update { it.copy(authErrorMessage = null, authSuccessMessage = null) }
    }

    fun openProfileDialog() {
        _uiState.update { it.copy(isProfileDialogOpen = true) }
    }

    fun closeProfileDialog() {
        _uiState.update { it.copy(isProfileDialogOpen = false) }
    }

    fun openEditProfileDialog() {
        _uiState.update { it.copy(isEditProfileDialogOpen = true, isProfileDialogOpen = false) }
    }

    fun closeEditProfileDialog() {
        _uiState.update { it.copy(isEditProfileDialogOpen = false) }
    }

    // ==========================================
    // Gemini Study Coach (Exclusively for Study & Revision)
    // ==========================================

    fun setGeminiStudyInput(text: String) {
        _uiState.update { it.copy(geminiStudyPromptInput = text, geminiStudyError = null) }
    }

    fun setGeminiStudySubject(subject: String) {
        _uiState.update { it.copy(geminiStudySelectedSubject = subject) }
    }

    fun setGeminiStudyTopic(topic: String) {
        _uiState.update { it.copy(geminiStudySelectedTopic = topic) }
    }

    fun sendGeminiStudyQuestion(customQuestion: String? = null) {
        val question = customQuestion ?: _uiState.value.geminiStudyPromptInput.trim()
        if (question.isBlank()) return

        val userMessage = com.example.data.api.StudyChatMessage(
            sender = com.example.data.api.MessageSender.STUDENT,
            text = question
        )

        val updatedMessages = _uiState.value.geminiStudyMessages + userMessage
        _uiState.update {
            it.copy(
                geminiStudyMessages = updatedMessages,
                geminiStudyPromptInput = "",
                isGeminiStudyLoading = true,
                geminiStudyError = null
            )
        }

        viewModelScope.launch {
            val result = geminiStudyService.askStudyTutor(
                question = question,
                subject = _uiState.value.geminiStudySelectedSubject,
                gradeLevel = _uiState.value.selectedGrade,
                conversationHistory = updatedMessages
            )

            result.fold(
                onSuccess = { responseText ->
                    val botMessage = com.example.data.api.StudyChatMessage(
                        sender = com.example.data.api.MessageSender.GEMINI_TUTOR,
                        text = responseText
                    )
                    _uiState.update {
                        it.copy(
                            geminiStudyMessages = it.geminiStudyMessages + botMessage,
                            isGeminiStudyLoading = false
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isGeminiStudyLoading = false,
                            geminiStudyError = error.message ?: "Failed to receive study guidance from Gemini."
                        )
                    }
                }
            )
        }
    }

    fun requestGeminiConceptExplanation(topic: String, subject: String = _uiState.value.geminiStudySelectedSubject) {
        if (topic.isBlank()) return
        val userPrompt = "Explain the concept of '$topic' in $subject with key definitions, formulas, and an exam example."
        sendGeminiStudyQuestion(userPrompt)
    }

    fun requestGeminiPracticeQuestions(topic: String, subject: String = _uiState.value.geminiStudySelectedSubject) {
        if (topic.isBlank()) return
        val userPrompt = "Generate 3 high-yield practice revision questions with worked solutions on '$topic' in $subject."
        sendGeminiStudyQuestion(userPrompt)
    }

    fun requestGeminiCheatSheet(topic: String, subject: String = _uiState.value.geminiStudySelectedSubject) {
        if (topic.isBlank()) return
        val userPrompt = "Create a quick revision cheat-sheet and key formulas for '$topic' in $subject."
        sendGeminiStudyQuestion(userPrompt)
    }

    fun retryLastGeminiQuestion() {
        val lastStudentMessage = _uiState.value.geminiStudyMessages.lastOrNull { it.sender == com.example.data.api.MessageSender.STUDENT }
        if (lastStudentMessage != null) {
            _uiState.update {
                it.copy(
                    isGeminiStudyLoading = true,
                    geminiStudyError = null
                )
            }

            viewModelScope.launch {
                val result = geminiStudyService.askStudyTutor(
                    question = lastStudentMessage.text,
                    subject = _uiState.value.geminiStudySelectedSubject,
                    gradeLevel = _uiState.value.selectedGrade,
                    conversationHistory = _uiState.value.geminiStudyMessages
                )

                result.fold(
                    onSuccess = { responseText ->
                        val botMessage = com.example.data.api.StudyChatMessage(
                            sender = com.example.data.api.MessageSender.GEMINI_TUTOR,
                            text = responseText
                        )
                        _uiState.update {
                            it.copy(
                                geminiStudyMessages = it.geminiStudyMessages + botMessage,
                                isGeminiStudyLoading = false
                            )
                        }
                    },
                    onFailure = { error ->
                        _uiState.update {
                            it.copy(
                                isGeminiStudyLoading = false,
                                geminiStudyError = error.message ?: "Failed to receive study guidance from Gemini."
                            )
                        }
                    }
                )
            }
        }
    }

    fun clearGeminiStudyChat() {
        _uiState.update {
            it.copy(
                geminiStudyMessages = emptyList(),
                geminiStudyError = null
            )
        }
    }
}

