package com.example.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String = "",
    val selectedIcon: ImageVector? = null,
    val unselectedIcon: ImageVector? = null,
    val testTag: String = ""
) {
    data object Auth : Screen(route = "auth")

    data object Dashboard : Screen(
        route = "dashboard",
        title = "Dashboard",
        selectedIcon = Icons.Filled.Dashboard,
        unselectedIcon = Icons.Outlined.Dashboard,
        testTag = "nav_home"
    )

    data object TaskManagement : Screen(
        route = "tasks",
        title = "Tasks",
        selectedIcon = Icons.Filled.Assignment,
        unselectedIcon = Icons.Outlined.Assignment,
        testTag = "nav_assignments"
    )

    data object StudySchedule : Screen(
        route = "study",
        title = "Study & Timer",
        selectedIcon = Icons.Filled.Timer,
        unselectedIcon = Icons.Outlined.Timer,
        testTag = "nav_study"
    )

    data object ExamPrep : Screen(
        route = "exam_prep",
        title = "Exam Prep",
        selectedIcon = Icons.Filled.School,
        unselectedIcon = Icons.Outlined.School,
        testTag = "nav_exam_prep"
    )

    companion object {
        val bottomNavItems = listOf(
            Dashboard,
            TaskManagement,
            StudySchedule,
            ExamPrep
        )

        fun fromRoute(route: String?): Screen {
            return when (route) {
                Auth.route -> Auth
                Dashboard.route -> Dashboard
                TaskManagement.route -> TaskManagement
                StudySchedule.route -> StudySchedule
                ExamPrep.route -> ExamPrep
                else -> Dashboard
            }
        }
    }
}
