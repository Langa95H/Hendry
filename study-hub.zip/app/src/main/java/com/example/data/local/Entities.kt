package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "assignments")
data class AssignmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String,
    val gradeLevel: String, // GRADE_10, GRADE_11, GRADE_12
    val dueDateEpochMs: Long,
    val priority: String, // URGENT, MEDIUM, LOW
    val status: String, // TODO, IN_PROGRESS, COMPLETED
    val weightPercent: Int = 10,
    val estimatedHours: Double = 2.0,
    val notes: String = "",
    val checklistJson: String = "[]", // JSON array of checklist items
    val scoreAchieved: Double? = null,
    val maxScore: Double? = null,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "timetable_slots")
data class TimetableSlotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayOfWeek: Int, // 1 = Monday, ..., 7 = Sunday
    val startHour: Int, // e.g. 14 for 2 PM
    val startMinute: Int, // e.g. 0
    val durationMinutes: Int, // e.g. 60
    val subject: String,
    val topic: String,
    val gradeLevel: String,
    val colorHex: Long
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val durationMinutes: Int,
    val mode: String,
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "exam_countdowns")
data class ExamCountdownEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String,
    val gradeLevel: String,
    val examDateEpochMs: Long,
    val paperName: String = "Paper 1",
    val syllabusTopics: String = "",
    val readinessScore: Int = 50 // 0 - 100%
)

@Entity(tableName = "flashcards")
data class FlashcardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gradeLevel: String,
    val subject: String,
    val topic: String,
    val question: String,
    val answer: String,
    val formulaOrHint: String = "",
    val isMastered: Boolean = false,
    val timesReviewed: Int = 0,
    val isUserCreated: Boolean = false
)

@Entity(tableName = "past_papers")
data class PastPaperEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gradeLevel: String,
    val subject: String,
    val year: Int,
    val termOrSeason: String, // "Mid-Year", "Finals", "Term 1"
    val paperNumber: String, // "Paper 1 (Core)", "Paper 2 (Applications)"
    val totalMarks: Int = 100,
    val userScore: Int? = null,
    val isCompleted: Boolean = false,
    val isTimed: Boolean = true,
    val keyLearnings: String = ""
)

@Entity(tableName = "students")
data class StudentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val email: String,
    val passwordHash: String, // stored password
    val gradeLevel: String, // GRADE_10, GRADE_11, GRADE_12
    val schoolName: String = "High School Academy",
    val targetAverage: Int = 85, // target academic score %
    val dailyGoalMinutes: Int = 120,
    val avatarKey: String = "grad_cap", // grad_cap, science, book, math, trophy, rocket, star
    val favoriteSubject: String = "Mathematics & Sciences",
    val bio: String = "Dedicated high school student aiming for academic excellence.",
    val isLoggedIn: Boolean = false,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)
