package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

data class AvatarOption(
    val key: String,
    val label: String,
    val icon: ImageVector,
    val primaryColor: Color,
    val secondaryColor: Color
)

val AvailableAvatars = listOf(
    AvatarOption("grad_cap", "Scholar", Icons.Default.School, Color(0xFF3B82F6), Color(0xFF1D4ED8)),
    AvatarOption("science", "Scientist", Icons.Default.Science, Color(0xFF10B981), Color(0xFF047857)),
    AvatarOption("math", "Mathematician", Icons.Default.Calculate, Color(0xFF8B5CF6), Color(0xFF6D28D9)),
    AvatarOption("book", "Researcher", Icons.Default.MenuBook, Color(0xFFF59E0B), Color(0xFFD97706)),
    AvatarOption("trophy", "Distinction", Icons.Default.EmojiEvents, Color(0xFFEC4899), Color(0xFFBE185D)),
    AvatarOption("rocket", "Achiever", Icons.Default.RocketLaunch, Color(0xFF06B6D4), Color(0xFF0E7490)),
    AvatarOption("star", "Honor Roll", Icons.Default.Star, Color(0xFFF97316), Color(0xFFC2410C)),
    AvatarOption("art", "Creative", Icons.Default.Palette, Color(0xFF6366F1), Color(0xFF4338CA))
)

fun getAvatarOption(key: String): AvatarOption {
    return AvailableAvatars.firstOrNull { it.key == key } ?: AvailableAvatars[0]
}

@Composable
fun StudentAvatar(
    avatarKey: String,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    iconSize: Dp = size * 0.55f,
    showBorder: Boolean = false,
    borderColor: Color = MaterialTheme.colorScheme.primary,
    onClick: (() -> Unit)? = null
) {
    val option = getAvatarOption(avatarKey)
    val gradient = Brush.linearGradient(
        colors = listOf(option.primaryColor, option.secondaryColor)
    )

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .then(
                if (showBorder) Modifier.border(2.dp, borderColor, CircleShape)
                else Modifier
            )
            .background(brush = gradient)
            .then(
                if (onClick != null) Modifier.clickable { onClick() }
                else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = option.icon,
            contentDescription = option.label,
            tint = Color.White,
            modifier = Modifier.size(iconSize)
        )
    }
}
