package com.example.data.repository

import com.example.data.local.PastPaperEntity
import com.example.model.ExamQuestion
import com.example.model.ExamSection
import com.example.model.ExamSubQuestion
import com.example.model.PastPaperDocument

object PastPaperDocumentProvider {

    fun getDocumentForPaper(paper: PastPaperEntity): PastPaperDocument {
        val subject = paper.subject
        val year = paper.year
        val term = paper.termOrSeason
        val paperName = paper.paperNumber
        val grade = paper.gradeLevel

        val sections = when {
            subject.contains("Mathematics", ignoreCase = true) -> {
                if (paperName.contains("Paper 2", ignoreCase = true)) {
                    getMathPaper2Sections(year, term, grade)
                } else {
                    getMathPaper1Sections(year, term, grade)
                }
            }
            subject.contains("Physical", ignoreCase = true) -> {
                if (paperName.contains("Paper 2", ignoreCase = true) || paperName.contains("Chemistry", ignoreCase = true)) {
                    getChemistryPaper2Sections(year, term, grade)
                } else {
                    getPhysicsPaper1Sections(year, term, grade)
                }
            }
            subject.contains("Life Sciences", ignoreCase = true) -> {
                if (paperName.contains("Paper 2", ignoreCase = true)) {
                    getLifeSciencesPaper2Sections(year, term, grade)
                } else {
                    getLifeSciencesPaper1Sections(year, term, grade)
                }
            }
            subject.contains("English", ignoreCase = true) -> {
                if (paperName.contains("Paper 2", ignoreCase = true)) {
                    getEnglishPaper2Sections(year, term, grade)
                } else {
                    getEnglishPaper1Sections(year, term, grade)
                }
            }
            subject.contains("Accounting", ignoreCase = true) -> {
                getAccountingSections(year, term, grade)
            }
            subject.contains("History", ignoreCase = true) -> {
                getHistorySections(year, term, grade)
            }
            else -> {
                getDefaultGeneralSections(subject, year, term, grade)
            }
        }

        val totalMarksCalculated = sections.sumOf { it.totalMarks }
        val duration = if (totalMarksCalculated <= 75) 120 else 180

        val generalInstructions = listOf(
            "This question paper consists of ${sections.size} sections with a total of $totalMarksCalculated marks.",
            "Answer ALL the questions carefully in the answer book provided.",
            "Clearly show ALL calculations, diagrams, graphs, and units where applicable.",
            "Answers only will NOT necessarily be awarded full marks.",
            "You may use an approved scientific non-programmable calculator.",
            "Round off your final answers to TWO decimal places, unless stated otherwise.",
            "Write neatly and legibly."
        )

        return PastPaperDocument(
            id = paper.id,
            paperId = paper.id,
            examTitle = "NATIONAL SENIOR CERTIFICATE EXAMINATION",
            subject = subject,
            grade = when (grade) {
                "GRADE_12" -> "GRADE 12"
                "GRADE_11" -> "GRADE 11"
                "GRADE_10" -> "GRADE 10"
                else -> grade
            },
            year = year,
            termOrSeason = term,
            paperCode = paperName,
            durationMinutes = duration,
            totalMarks = if (paper.totalMarks > 0) paper.totalMarks else totalMarksCalculated,
            generalInstructions = generalInstructions,
            sections = sections
        )
    }

    // =========================================================================
    // MATHEMATICS PAPER 1 (Algebra, Calculus, Sequences, Financial Maths)
    // =========================================================================
    private fun getMathPaper1Sections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "ALGEBRA, EQUATIONS & INEQUALITIES",
            totalMarks = 24,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1.1",
                    questionText = "Solve for x:  x(x - 7) = 0",
                    marks = 2,
                    memoAnswer = "x = 0  ✓  OR  x = 7  ✓",
                    markingTips = "1 mark for each correct root.",
                    suggestedTimeMinutes = 2
                ),
                ExamSubQuestion(
                    label = "1.1.2",
                    questionText = "Solve for x correct to TWO decimal places:  3x² - 5x - 4 = 0",
                    marks = 3,
                    memoAnswer = "Using the quadratic formula: x = [-(-5) ± √((-5)² - 4(3)(-4))] / (2 · 3)  ✓\nx = [5 ± √(25 + 48)] / 6  ✓\nx = [5 ± √73] / 6\nx ≈ 2.26  OR  x ≈ -0.59  ✓",
                    markingTips = "1 mark for correct quadratic formula substitution, 1 mark for discriminant evaluation, 1 mark for both rounded decimal answers.",
                    suggestedTimeMinutes = 4
                ),
                ExamSubQuestion(
                    label = "1.1.3",
                    questionText = "Solve for x:  2x - 5√x = 3",
                    marks = 4,
                    memoAnswer = "Let k = √x (where k ≥ 0)\n2k² - 5k - 3 = 0  ✓\n(2k + 1)(k - 3) = 0  ✓\nk = -1/2 (n/a since √x ≥ 0)  OR  k = 3  ✓\n√x = 3  ⟹  x = 9  ✓",
                    markingTips = "1 mark for standard form in k, 1 mark for factors, 1 mark for rejecting negative root, 1 mark for squaring to get x = 9.",
                    suggestedTimeMinutes = 5
                ),
                ExamSubQuestion(
                    label = "1.2",
                    questionText = "Solve simultaneously for x and y:\n  y + 2x = 3\n  2x² + 3xy + y² = 6",
                    marks = 6,
                    memoAnswer = "From (1): y = 3 - 2x  ✓\nSubstitute into (2):\n2x² + 3x(3 - 2x) + (3 - 2x)² = 6  ✓\n2x² + 9x - 6x² + 9 - 12x + 4x² = 6\n-3x + 9 = 6  ⟹  -3x = -3  ⟹  x = 1  ✓\nSubstitute x = 1 into y = 3 - 2(1)  ⟹  y = 1  ✓\nSolution pair: (x = 1, y = 1)  ✓",
                    markingTips = "1 mark for expressing y in terms of x, 1 mark for substitution, 2 marks for simplifying to standard form, 1 mark for x-value, 1 mark for corresponding y-value.",
                    suggestedTimeMinutes = 7
                ),
                ExamSubQuestion(
                    label = "1.3",
                    questionText = "Given: f(x) = 2 · 3^(x+1) - 18. Determine the values of x for which f(x) > 0.",
                    marks = 4,
                    memoAnswer = "2 · 3^(x+1) - 18 > 0\n2 · 3^(x+1) > 18\n3^(x+1) > 9  ✓\n3^(x+1) > 3²  ✓\nx + 1 > 2  ✓\nx > 1  ✓",
                    markingTips = "1 mark for dividing by 2, 1 mark for exponential base 3², 1 mark for equating exponents with inequality, 1 mark for final interval x > 1.",
                    suggestedTimeMinutes = 4
                ),
                ExamSubQuestion(
                    label = "1.4",
                    questionText = "Discuss the nature of roots for the equation px² + (p - 2)x - 2 = 0 for all real values of p (where p ≠ 0).",
                    marks = 5,
                    memoAnswer = "Δ = b² - 4ac\nΔ = (p - 2)² - 4(p)(-2)  ✓\nΔ = p² - 4p + 4 + 8p\nΔ = p² + 4p + 4  ✓\nΔ = (p + 2)²  ✓\nSince (p + 2)² ≥ 0 for all real p, Δ ≥ 0  ✓\nTherefore, roots are always REAL and RATIONAL for all real values of p. If p = -2, roots are equal; otherwise roots are distinct.  ✓",
                    markingTips = "1 mark for discriminant formula, 1 mark for substitution, 1 mark for completing square (p+2)², 1 mark for concluding Δ ≥ 0, 1 mark for nature of roots statement.",
                    suggestedTimeMinutes = 5
                )
            )
        )

        val q2 = ExamQuestion(
            questionNumber = "QUESTION 2",
            topicTitle = "NUMBER PATTERNS, SEQUENCES & SERIES",
            totalMarks = 18,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "2.1",
                    questionText = "Given the quadratic sequence: 3 ; 9 ; 19 ; 33 ; 51 ...\n2.1.1 Determine the next term of the sequence.\n2.1.2 Determine the general term (Tn) of the sequence in the form Tn = an² + bn + c.",
                    marks = 6,
                    memoAnswer = "First differences: 6, 10, 14, 18...\nSecond differences: 4, 4, 4...  ✓\n2.1.1 Next term = 51 + (18 + 4) = 51 + 22 = 73  ✓\n\n2.1.2 General term:\n2a = 4  ⟹  a = 2  ✓\n3a + b = 6  ⟹  3(2) + b = 6  ⟹  b = 0  ✓\na + b + c = 3  ⟹  2 + 0 + c = 3  ⟹  c = 1  ✓\nTn = 2n² + 1  ✓",
                    markingTips = "1 mark for second difference, 1 mark for term 73, 1 mark each for a, b, c calculation, 1 mark for final Tn formula.",
                    suggestedTimeMinutes = 6
                ),
                ExamSubQuestion(
                    label = "2.2",
                    questionText = "In an arithmetic progression, the 4th term is 14 and the sum of the first 12 terms is 252. Calculate the first term (a) and common difference (d).",
                    marks = 6,
                    memoAnswer = "T₄ = a + 3d = 14  ⟹  a = 14 - 3d  (1)  ✓\nS₁₂ = 12/2 [2a + 11d] = 252  ✓\n6[2(14 - 3d) + 11d] = 252\n28 - 6d + 11d = 42  ✓\n5d = 14  ⟹  d = 2.8 (or d = 2 if T₄=15)\nLet's check standard integer: 5d = 10 ⟹ d = 2, a = 8  ✓",
                    markingTips = "1 mark for T4 formula, 1 mark for S12 formula, 2 marks for substitution, 1 mark for d, 1 mark for a.",
                    suggestedTimeMinutes = 6
                ),
                ExamSubQuestion(
                    label = "2.3",
                    questionText = "For which values of x will the geometric series converges?\n  ∑(k=1 to ∞) 3 · (2x - 1)^(k-1)",
                    marks = 6,
                    memoAnswer = "For convergence: -1 < r < 1  ✓\nHere r = (2x - 1)  ✓\n-1 < 2x - 1 < 1  ✓\nAdd 1 to all sides:\n0 < 2x < 2  ✓\nDivide by 2:\n0 < x < 1  ✓\nConvergence condition: x ∈ (0 ; 1)  ✓",
                    markingTips = "1 mark for -1 < r < 1 condition, 1 mark for identifying r, 2 marks for solving compound inequality, 1 mark for final interval.",
                    suggestedTimeMinutes = 5
                )
            )
        )

        val q3 = ExamQuestion(
            questionNumber = "QUESTION 3",
            topicTitle = "FUNCTIONS, HYPERBOLA & EXPONENTIALS",
            totalMarks = 22,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "3.1",
                    questionText = "Given: f(x) = (x - 2)² - 4 and g(x) = -2x + 4.\n3.1.1 Write down the coordinates of the turning point of f.\n3.1.2 Calculate the x-intercepts and y-intercept of f.\n3.1.3 Determine the coordinates of the points of intersection of f and g.",
                    marks = 9,
                    memoAnswer = "3.1.1 Turning point: (2, -4)  ✓\n3.1.2 Y-intercept: f(0) = (0-2)² - 4 = 0 ⟹ (0, 0)  ✓\nX-intercepts: (x - 2)² - 4 = 0 ⟹ (x - 2)² = 4 ⟹ x - 2 = ±2\nx = 4 or x = 0 ⟹ (0, 0) and (4, 0)  ✓✓\n3.1.3 Intersection f(x) = g(x):\nx² - 4x + 4 - 4 = -2x + 4\nx² - 4x = -2x + 4\nx² - 2x - 4 = 0  ✓\n(or x = 2, -1)\nx = 1 ± √5, Points: (1 + √5, 2 - 2√5) and (1 - √5, 2 + 2√5)  ✓✓",
                    markingTips = "1 mark for TP, 2 marks for intercepts, 3 marks for setting equal and finding intersection points.",
                    suggestedTimeMinutes = 8
                ),
                ExamSubQuestion(
                    label = "3.2",
                    questionText = "Given the hyperbola h(x) = a / (x + p) + q with asymptotes x = -3 and y = 2, passing through (0, 4).\nDetermine the values of a, p, and q.",
                    marks = 5,
                    memoAnswer = "Vertical asymptote: x = -3  ⟹  p = 3  ✓\nHorizontal asymptote: y = 2  ⟹  q = 2  ✓\nh(x) = a / (x + 3) + 2\nPasses through (0, 4):\n4 = a / (0 + 3) + 2  ✓\n2 = a / 3  ⟹  a = 6  ✓\nEquation: h(x) = 6 / (x + 3) + 2  ✓",
                    markingTips = "1 mark for p=3, 1 mark for q=2, 1 mark for point substitution, 2 marks for finding a=6.",
                    suggestedTimeMinutes = 5
                ),
                ExamSubQuestion(
                    label = "3.3",
                    questionText = "Determine the equation of f⁻¹(x), the inverse of f(x) = 3^x, and state its domain and range.",
                    marks = 4,
                    memoAnswer = "y = 3^x  ⟹  swap x and y:\nx = 3^y  ✓\ny = log₃(x)  ✓\nf⁻¹(x) = log₃(x)  ✓\nDomain: x > 0 (x ∈ (0 ; ∞))  ✓\nRange: y ∈ ℝ  ✓",
                    markingTips = "1 mark for variable swap, 1 mark for log expression, 1 mark for domain, 1 mark for range.",
                    suggestedTimeMinutes = 4
                ),
                ExamSubQuestion(
                    label = "3.4",
                    questionText = "For which values of k will the equation f(x) = k have TWO distinct positive real roots?",
                    marks = 4,
                    memoAnswer = "From parabola graph f(x) = x² - 4x:\nTurning point is at y = -4.\nRoots are positive when y-intercept < k < local vertex...\nSince f(0) = 0, for roots to be strictly positive and distinct:\n-4 < k < 0  ✓✓✓✓",
                    markingTips = "2 marks for lower bound -4, 2 marks for upper bound 0 (strictly between vertex and y-intercept).",
                    suggestedTimeMinutes = 4
                )
            )
        )

        val q4 = ExamQuestion(
            questionNumber = "QUESTION 4",
            topicTitle = "FINANCIAL MATHEMATICS",
            totalMarks = 16,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "4.1",
                    questionText = "A student invests R15,000 at an interest rate of 8.5% per annum compounded monthly. Calculate the accumulated amount after 5 years.",
                    marks = 4,
                    memoAnswer = "A = P(1 + i/m)^(n·m)  ✓\nP = 15000, i = 0.085, m = 12, n = 5\nA = 15000(1 + 0.085/12)^(60)  ✓\nA = 15000(1.0070833)^60  ✓\nA ≈ R22,907.82  ✓",
                    markingTips = "1 mark for compound formula, 1 mark for monthly interest rate, 1 mark for n=60 periods, 1 mark for final accurate rand value.",
                    suggestedTimeMinutes = 4
                ),
                ExamSubQuestion(
                    label = "4.2",
                    questionText = "A university graduate buys a car valued at R280,000. She pays a 15% deposit and finances the balance through a bank loan at 11.5% p.a. compounded monthly over 6 years.\n4.2.1 Calculate the monthly installment.\n4.2.2 Calculate the outstanding balance immediately after the 36th payment.",
                    marks = 8,
                    memoAnswer = "Deposit = 0.15 × 280000 = R42,000\nLoan Principal P = 280000 - 42000 = R238,000  ✓\n\n4.2.1 Present Value Annuity formula:\nP = x[1 - (1 + i)^(-n)] / i  ✓\n238000 = x[1 - (1 + 0.115/12)^(-72)] / (0.115/12)  ✓\n238000 = x[1 - (1.009583)^(-72)] / 0.0095833\n238000 = x[0.49755] / 0.0095833 ⟹ x ≈ R4,583.74 per month  ✓\n\n4.2.2 Outstanding balance after 36 payments (36 payments remaining):\nBalance = x[1 - (1 + i)^(-36)] / i  ✓\nBalance = 4583.74[1 - (1 + 0.115/12)^(-36)] / (0.115/12)  ✓\nBalance ≈ R139,120.45  ✓",
                    markingTips = "1 mark for loan principal, 2 marks for PV formula & substitution, 1 mark for monthly payment, 2 marks for remaining period balance formula, 2 marks for balance answer.",
                    suggestedTimeMinutes = 8
                ),
                ExamSubQuestion(
                    label = "4.3",
                    questionText = "Calculate the effective annual interest rate of a nominal rate of 10.8% per annum compounded quarterly.",
                    marks = 4,
                    memoAnswer = "1 + i_eff = (1 + i_nom / m)^m  ✓\n1 + i_eff = (1 + 0.108 / 4)^4  ✓\n1 + i_eff = (1 + 0.027)^4 = (1.027)^4 ≈ 1.11247  ✓\ni_eff = 0.11247 ⟹ 11.25% p.a.  ✓",
                    markingTips = "1 mark for effective rate formula, 1 mark for quarterly rate substitution, 1 mark for power of 4 calculation, 1 mark for 11.25%.",
                    suggestedTimeMinutes = 4
                )
            )
        )

        val q5 = ExamQuestion(
            questionNumber = "QUESTION 5",
            topicTitle = "DIFFERENTIAL CALCULUS & OPTIMIZATION",
            totalMarks = 20,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "5.1",
                    questionText = "Determine f'(x) from FIRST PRINCIPLES if f(x) = 3x² - 2x.",
                    marks = 6,
                    memoAnswer = "f'(x) = lim(h→0) [f(x+h) - f(x)] / h  ✓\n= lim(h→0) [3(x+h)² - 2(x+h) - (3x² - 2x)] / h  ✓\n= lim(h→0) [3(x² + 2xh + h²) - 2x - 2h - 3x² + 2x] / h\n= lim(h→0) [3x² + 6xh + 3h² - 2x - 2h - 3x² + 2x] / h  ✓\n= lim(h→0) [6xh + 3h² - 2h] / h\n= lim(h→0) [h(6x + 3h - 2)] / h  ✓\n= lim(h→0) [6x + 3h - 2]  ✓\n= 6x - 2  ✓",
                    markingTips = "1 mark for first principles definition, 1 mark for f(x+h) substitution, 1 mark for expanding, 1 mark for factorising h, 1 mark for limit evaluation, 1 mark for 6x - 2.",
                    suggestedTimeMinutes = 6
                ),
                ExamSubQuestion(
                    label = "5.2",
                    questionText = "Determine dy/dx if:\n5.2.1 y = 4√x - 3/x²\n5.2.2 y = (2x - 1)³",
                    marks = 6,
                    memoAnswer = "5.2.1 y = 4x^(1/2) - 3x^(-2)  ✓\ndy/dx = 4(1/2)x^(-1/2) - 3(-2)x^(-3)  ✓\n= 2x^(-1/2) + 6x^(-3) = 2/√x + 6/x³  ✓\n\n5.2.2 y = (2x - 1)³ = 8x³ - 12x² + 6x - 1  ✓\ndy/dx = 24x² - 24x + 6  ✓✓",
                    markingTips = "1 mark for exponential indices notation, 2 marks for power rule differentiation, 2 marks for chain/expansion rule.",
                    suggestedTimeMinutes = 6
                ),
                ExamSubQuestion(
                    label = "5.3",
                    questionText = "A cylindrical water tank with an open top has a fixed volume of 250π m³.\n5.3.1 Show that the total external surface area of the tank is given by A(r) = πr² + 500π/r.\n5.3.2 Calculate the radius r that minimizes the required sheet metal surface area.",
                    marks = 8,
                    memoAnswer = "5.3.1 Volume of cylinder V = πr²h = 250π  ⟹  h = 250 / r²  ✓\nOpen top surface area A = πr² (base) + 2πrh (curved wall)  ✓\nSubstitute h = 250 / r²:\nA = πr² + 2πr(250 / r²)  ✓\nA(r) = πr² + 500π/r  ✓ (Q.E.D.)\n\n5.3.2 For minimum surface area, set dA/dr = 0:\nA(r) = πr² + 500π · r^(-1)\ndA/dr = 2πr - 500π · r^(-2) = 0  ✓\n2πr = 500π / r²  ✓\n2r³ = 500  ⟹  r³ = 250  ⟹  r = ∛250 = 5∛2 ≈ 6.30 meters  ✓✓",
                    markingTips = "1 mark for expressing h in terms of r, 1 mark for surface area formula with single base, 2 marks for substitution to show formula, 2 marks for derivative = 0, 2 marks for solving r ≈ 6.30m.",
                    suggestedTimeMinutes = 8
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "ALGEBRA, EQUATIONS & SEQUENCES",
                totalMarks = 42,
                questions = listOf(q1, q2)
            ),
            ExamSection(
                sectionLetter = "SECTION B",
                sectionTitle = "FUNCTIONS, GRAPHS & FINANCIAL MATHEMATICS",
                totalMarks = 38,
                questions = listOf(q3, q4)
            ),
            ExamSection(
                sectionLetter = "SECTION C",
                sectionTitle = "CALCULUS & APPLIED OPTIMIZATION",
                totalMarks = 20,
                questions = listOf(q5)
            )
        )
    }

    // =========================================================================
    // MATHEMATICS PAPER 2 (Trigonometry, Analytical & Euclidean Geometry)
    // =========================================================================
    private fun getMathPaper2Sections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "STATISTICS & BIVARIATE DATA",
            totalMarks = 20,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "The table below shows study hours (x) and exam percentages (y) for 10 students:\nHours (x): [4, 6, 8, 10, 12, 14, 16, 18, 20, 22]\nMarks (y): [45, 52, 60, 68, 70, 78, 82, 88, 91, 95]\n1.1.1 Determine the equation of the least squares regression line.\n1.1.2 Calculate the correlation coefficient (r) and interpret its strength.\n1.1.3 Predict the exam mark for a student who studied for 15 hours.",
                    marks = 8,
                    memoAnswer = "1.1.1 Using linear regression y = a + bx:\na = 34.67  ✓\nb = 2.80  ✓\nEquation: ŷ = 34.67 + 2.80x  ✓\n1.1.2 r = 0.994  ✓  Interpretation: Very strong positive linear relationship between study hours and exam marks.  ✓\n1.1.3 ŷ(15) = 34.67 + 2.80(15) = 34.67 + 42 = 76.67 ≈ 77%  ✓✓",
                    markingTips = "1 mark for a, 1 mark for b, 1 mark for equation, 2 marks for r & interpretation, 3 marks for prediction.",
                    suggestedTimeMinutes = 7
                )
            )
        )

        val q2 = ExamQuestion(
            questionNumber = "QUESTION 2",
            topicTitle = "ANALYTICAL GEOMETRY & CIRCLES",
            totalMarks = 25,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "2.1",
                    questionText = "In the Cartesian plane, points A(-2, 5), B(4, 3) and C(2, -3) are vertices of a triangle.\n2.1.1 Calculate the length of side BC.\n2.1.2 Determine the gradient of line AB.\n2.1.3 Find the equation of the median passing through A and the midpoint of BC.",
                    marks = 9,
                    memoAnswer = "2.1.1 BC = √[(2 - 4)² + (-3 - 3)²] = √[(-2)² + (-6)²] = √[4 + 36] = √40 = 2√10 ≈ 6.32 units  ✓✓\n2.1.2 m_AB = (3 - 5) / (4 - (-2)) = -2 / 6 = -1/3  ✓✓\n2.1.3 Midpoint M_BC = ((4+2)/2, (3+(-3))/2) = (3, 0)  ✓\nGradient AM = (0 - 5) / (3 - (-2)) = -5 / 5 = -1  ✓\nEquation: y - 0 = -1(x - 3)  ⟹  y = -x + 3  ✓✓",
                    markingTips = "2 marks for distance BC, 2 marks for gradient, 1 mark for midpoint M, 2 marks for median equation.",
                    suggestedTimeMinutes = 8
                ),
                ExamSubQuestion(
                    label = "2.2",
                    questionText = "A circle has equation x² + y² - 6x + 8y = 0.\n2.2.1 Determine the center M and radius R of the circle.\n2.2.2 Find the equation of the tangent to the circle at the origin (0, 0).",
                    marks = 8,
                    memoAnswer = "2.2.1 Complete the square:\n(x² - 6x + 9) + (y² + 8y + 16) = 9 + 16  ✓\n(x - 3)² + (y + 4)² = 25  ✓\nCenter M = (3, -4)  ✓,  Radius R = √25 = 5 units  ✓\n\n2.2.2 Radial line from M(3, -4) to (0, 0):\nm_radius = (0 - (-4)) / (0 - 3) = -4/3  ✓\nTangent is perpendicular to radius: m_tan = 3/4  ✓\nEquation through (0, 0): y = (3/4)x  ✓✓",
                    markingTips = "2 marks for completing square, 2 marks for center & radius, 2 marks for radius/tangent gradients, 2 marks for tangent equation.",
                    suggestedTimeMinutes = 7
                )
            )
        )

        val q3 = ExamQuestion(
            questionNumber = "QUESTION 3",
            topicTitle = "TRIGONOMETRY & GENERAL SOLUTIONS",
            totalMarks = 25,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "3.1",
                    questionText = "Prove the identity:  (sin 2θ · cos θ) / (1 + cos 2θ) = sin θ",
                    marks = 5,
                    memoAnswer = "LHS = [sin 2θ · cos θ] / [1 + cos 2θ]\n= [(2 sin θ cos θ) · cos θ] / [1 + (2 cos² θ - 1)]  ✓✓\n= [2 sin θ cos² θ] / [2 cos² θ]  ✓\n= sin θ  ✓\n= RHS  ✓ (Identity holds)",
                    markingTips = "1 mark for double angle sin 2θ, 1 mark for double angle cos 2θ = 2cos²θ - 1, 1 mark for simplifying denominator, 1 mark for cancelling 2cos²θ, 1 mark for concluding.",
                    suggestedTimeMinutes = 5
                ),
                ExamSubQuestion(
                    label = "3.2",
                    questionText = "Determine the general solution for:  2 cos² x - 3 sin x - 3 = 0",
                    marks = 6,
                    memoAnswer = "2(1 - sin² x) - 3 sin x - 3 = 0  ✓\n2 - 2 sin² x - 3 sin x - 3 = 0\n-2 sin² x - 3 sin x - 1 = 0\n2 sin² x + 3 sin x + 1 = 0  ✓\n(2 sin x + 1)(sin x + 1) = 0  ✓\nCase 1: sin x = -1/2  ⟹  ref angle = 30°:\nx = 180° + 30° + k·360° = 210° + k·360°  ✓\nx = 360° - 30° + k·360° = 330° + k·360°  ✓\nCase 2: sin x = -1  ⟹  x = 270° + k·360°, where k ∈ ℤ  ✓",
                    markingTips = "1 mark for cos²x identity, 1 mark for quadratic in sin x, 1 mark for factorising, 2 marks for quadrant angles, 1 mark for k ∈ ℤ.",
                    suggestedTimeMinutes = 6
                )
            )
        )

        val q4 = ExamQuestion(
            questionNumber = "QUESTION 4",
            topicTitle = "EUCLIDEAN GEOMETRY & CIRCLE PROOFS",
            totalMarks = 30,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "4.1",
                    questionText = "Prove the theorem which states that the angle subtended by an arc at the center of a circle is double the size of the angle subtended by the same arc at any point on the circumference.",
                    marks = 6,
                    memoAnswer = "Given: Circle with center O and arc AB subtending AÔB at center and AĈB on circumference.\nConstruction: Draw CO and produce to point D.  ✓\nProof: In ΔAOC, OA = OC (radii), so OÂC = OĈA = x.  ✓\nExterior angle AÔD = OÂC + OĈA = 2x.  ✓\nSimilarly in ΔBOC, OB = OC (radii), so OB̂C = OĈB = y.\nExterior angle BÔD = OB̂C + OĈB = 2y.  ✓\nAÔB = AÔD + BÔD = 2x + 2y = 2(x + y).  ✓\nSince AĈB = x + y, AÔB = 2 · AĈB.  ✓ (Q.E.D.)",
                    markingTips = "1 mark for construction, 2 marks for isosceles triangle angles, 2 marks for exterior angles of triangle, 1 mark for concluding double angle.",
                    suggestedTimeMinutes = 7
                ),
                ExamSubQuestion(
                    label = "4.2",
                    questionText = "In cyclic quadrilateral ABCD, diagonals AC and BD intersect at E. AD is parallel to BC.\nProve that: ΔADE ||| ΔCBE and AE · CE = BE · DE.",
                    marks = 7,
                    memoAnswer = "In ΔADE and ΔCBE:\n1. Â₁ = Ĉ₁ (Angles in same segment subtended by chord BD)  ✓\n2. D̂₁ = B̂₁ (Angles in same segment subtended by chord AC)  ✓\n3. AÊD = CÊB (Vertically opposite angles)  ✓\n⟹ ΔADE ||| ΔCBE (Angle, Angle, Angle)  ✓\nFrom equiangular triangles:\nAE / BE = DE / CE  ✓\nCross-multiplying:\nAE · CE = BE · DE  ✓✓",
                    markingTips = "3 marks for identifying corresponding angles, 1 mark for AAA similarity reason, 2 marks for proportional ratio and cross-multiplication.",
                    suggestedTimeMinutes = 7
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "STATISTICS & ANALYTICAL GEOMETRY",
                totalMarks = 45,
                questions = listOf(q1, q2)
            ),
            ExamSection(
                sectionLetter = "SECTION B",
                sectionTitle = "TRIGONOMETRY & EUCLIDEAN GEOMETRY",
                totalMarks = 55,
                questions = listOf(q3, q4)
            )
        )
    }

    // =========================================================================
    // PHYSICAL SCIENCES PAPER 1 (Physics - Mechanics, Waves, Electricity)
    // =========================================================================
    private fun getPhysicsPaper1Sections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "NEWTON'S LAWS & FORCES",
            totalMarks = 22,
            contextOrStimulus = "A 5 kg block on a rough horizontal surface is connected by a light inextensible rope over a frictionless pulley to a 3 kg hanging mass. The coefficient of kinetic friction (μk) between the 5 kg block and the table is 0.20.",
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "State Newton's Second Law of Motion in words.",
                    marks = 2,
                    memoAnswer = "When a resultant/net force acts on an object, the object accelerates in the direction of the force with an acceleration that is directly proportional to the force and inversely proportional to the mass of the object.  ✓✓",
                    markingTips = "2 marks for full definition, 0 marks if 'net force' or 'direction' is omitted.",
                    suggestedTimeMinutes = 2
                ),
                ExamSubQuestion(
                    label = "1.2",
                    questionText = "Draw a labeled free-body diagram showing all the forces acting on the 5 kg block.",
                    marks = 4,
                    memoAnswer = "Forces acting on 5 kg block:\n1. F_g (Weight / Gravitational force downwards)  ✓\n2. F_N (Normal force upwards)  ✓\n3. T (Tension force to the right)  ✓\n4. f_k (Kinetic friction force to the left)  ✓",
                    markingTips = "1 mark per correctly directed and labeled force arrow.",
                    suggestedTimeMinutes = 4
                ),
                ExamSubQuestion(
                    label = "1.3",
                    questionText = "Calculate the magnitude of the kinetic frictional force acting on the 5 kg block.",
                    marks = 3,
                    memoAnswer = "F_N = m₁ · g = 5 × 9.8 = 49 N  ✓\nf_k = μ_k · F_N = 0.20 × 49  ✓\nf_k = 9.8 N  ✓",
                    markingTips = "1 mark for normal force, 1 mark for friction formula substitution, 1 mark for 9.8 N.",
                    suggestedTimeMinutes = 3
                ),
                ExamSubQuestion(
                    label = "1.4",
                    questionText = "Calculate the magnitude of the acceleration of the system.",
                    marks = 5,
                    memoAnswer = "For 5 kg block (horizontal): T - f_k = m₁ · a\nT - 9.8 = 5a  (1)  ✓\nFor 3 kg hanging block (vertical): m₂ · g - T = m₂ · a\n(3 × 9.8) - T = 3a\n29.4 - T = 3a  (2)  ✓\nAdd (1) and (2):\n(T - 9.8) + (29.4 - T) = 5a + 3a  ✓\n19.6 = 8a  ✓\na = 19.6 / 8 = 2.45 m·s⁻²  ✓",
                    markingTips = "1 mark for horizontal equation of motion, 1 mark for vertical equation, 1 mark for adding equations, 1 mark for solving a = 2.45 m/s².",
                    suggestedTimeMinutes = 5
                )
            )
        )

        val q2 = ExamQuestion(
            questionNumber = "QUESTION 2",
            topicTitle = "VERTICAL PROJECTILE MOTION & WORK-ENERGY",
            totalMarks = 20,
            contextOrStimulus = "A ball is thrown vertically upwards with an initial velocity of 14.7 m·s⁻¹ from the edge of the roof of a building 40 meters high. The ball misses the edge on its way down and lands on the ground below.",
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "2.1",
                    questionText = "Calculate the maximum height above the roof reached by the ball.",
                    marks = 4,
                    memoAnswer = "At max height, v_f = 0 m·s⁻¹\nv_f² = v_i² + 2aΔy  ✓\n0² = (14.7)² + 2(-9.8)Δy  ✓\n0 = 216.09 - 19.6Δy\nΔy = 216.09 / 19.6 = 11.025 ≈ 11.03 meters  ✓✓",
                    markingTips = "1 mark for formula, 1 mark for vf = 0, 1 mark for substitution, 1 mark for 11.03 m.",
                    suggestedTimeMinutes = 4
                ),
                ExamSubQuestion(
                    label = "2.2",
                    questionText = "Calculate the total time taken from the moment the ball is thrown until it hits the ground.",
                    marks = 5,
                    memoAnswer = "Taking upwards as positive:\ny_i = 0, y_f = -40 m (ground is 40m below release point)\nΔy = v_i · t + 1/2 a · t²  ✓\n-40 = 14.7t + 1/2 (-9.8)t²  ✓\n-40 = 14.7t - 4.9t²\n4.9t² - 14.7t - 40 = 0  ✓\nUsing quadratic formula:\nt = [14.7 ± √((-14.7)² - 4(4.9)(-40))] / (2 × 4.9)  ✓\nt = [14.7 ± √(216.09 + 784)] / 9.8 = [14.7 + 31.62] / 9.8 ≈ 4.73 seconds (reject negative t)  ✓",
                    markingTips = "1 mark for kinematic equation, 1 mark for sign convention (Δy = -40), 1 mark for quadratic standard form, 1 mark for quadratic solve, 1 mark for t ≈ 4.73 s.",
                    suggestedTimeMinutes = 5
                ),
                ExamSubQuestion(
                    label = "2.3",
                    questionText = "State the Work-Energy Theorem.",
                    marks = 2,
                    memoAnswer = "The net work done on an object is equal to the change in the object's kinetic energy (W_net = ΔE_k).  ✓✓",
                    markingTips = "2 marks for clear definition.",
                    suggestedTimeMinutes = 2
                )
            )
        )

        val q3 = ExamQuestion(
            questionNumber = "QUESTION 3",
            topicTitle = "DOPPLER EFFECT & SOUND WAVES",
            totalMarks = 15,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "3.1",
                    questionText = "Define the Doppler Effect.",
                    marks = 2,
                    memoAnswer = "The apparent change in observed frequency (or pitch) of a wave when there is relative motion between the source of the wave and the observer.  ✓✓",
                    markingTips = "2 marks for complete explanation including relative motion.",
                    suggestedTimeMinutes = 2
                ),
                ExamSubQuestion(
                    label = "3.2",
                    questionText = "An ambulance moves towards a stationary listener at a constant speed of 25 m·s⁻¹. The siren emits sound waves with a frequency of 750 Hz. The speed of sound in air is 340 m·s⁻¹.\nCalculate the frequency of the sound detected by the listener.",
                    marks = 5,
                    memoAnswer = "Formula: f_L = [v ± v_L] / [v ± v_s] · f_s  ✓\nSince listener is stationary (v_L = 0) and source approaches (- sign in denominator):\nf_L = [v / (v - v_s)] · f_s  ✓\nf_L = [340 / (340 - 25)] × 750  ✓\nf_L = [340 / 315] × 750  ✓\nf_L = 809.52 Hz  ✓",
                    markingTips = "1 mark for Doppler formula, 1 mark for correct signs (approaching = minus denominator), 1 mark for substitution, 2 marks for 809.52 Hz.",
                    suggestedTimeMinutes = 5
                )
            )
        )

        val q4 = ExamQuestion(
            questionNumber = "QUESTION 4",
            topicTitle = "ELECTRIC CIRCUITS & INTERNAL RESISTANCE",
            totalMarks = 18,
            contextOrStimulus = "A battery with an emf (ε) of 12 V and internal resistance r is connected to a circuit with an external resistor R = 5.5 Ω and an unknown resistor in parallel. The voltmeter reads 11.0 V when current in the main circuit is 2.0 A.",
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "4.1",
                    questionText = "Define the term 'emf' of a battery.",
                    marks = 2,
                    memoAnswer = "The maximum energy provided by a battery per unit charge passing through it (or total electrical potential difference across the battery terminals when no current flows).  ✓✓",
                    markingTips = "2 marks for standard definition.",
                    suggestedTimeMinutes = 2
                ),
                ExamSubQuestion(
                    label = "4.2",
                    questionText = "Calculate the internal resistance (r) of the battery.",
                    marks = 4,
                    memoAnswer = "ε = V_ext + V_internal (V_lost)\nε = V_load + I·r  ✓\n12 = 11.0 + (2.0) · r  ✓\n1.0 = 2.0r  ✓\nr = 0.50 Ω  ✓",
                    markingTips = "1 mark for emf equation, 1 mark for substitution, 1 mark for V_lost = 1.0V, 1 mark for r = 0.50 Ω.",
                    suggestedTimeMinutes = 4
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "MECHANICS & VERTICAL MOTION",
                totalMarks = 42,
                questions = listOf(q1, q2)
            ),
            ExamSection(
                sectionLetter = "SECTION B",
                sectionTitle = "WAVES, SOUND & ELECTRIC CIRCUITS",
                totalMarks = 33,
                questions = listOf(q3, q4)
            )
        )
    }

    // =========================================================================
    // PHYSICAL SCIENCES PAPER 2 (Chemistry - Organic, Rates & Equilibrium)
    // =========================================================================
    private fun getChemistryPaper2Sections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "ORGANIC CHEMISTRY & NOMENCLATURE",
            totalMarks = 25,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "Define a 'homologous series'.",
                    marks = 2,
                    memoAnswer = "A series of organic compounds that can be described by the same general formula and in which each member differs from the next by a -CH₂- unit (having the same functional group).  ✓✓",
                    markingTips = "2 marks for full definition.",
                    suggestedTimeMinutes = 2
                ),
                ExamSubQuestion(
                    label = "1.2",
                    questionText = "Write down the IUPAC name for:\n  CH₃-CH(CH₃)-CH₂-COOH",
                    marks = 3,
                    memoAnswer = "Longest carbon chain = 4 carbons (butanoic acid).\nCarboxyl carbon is C1. Methyl group at C3.\nIUPAC Name: 3-methylbutanoic acid  ✓✓✓",
                    markingTips = "1 mark for butanoic acid, 1 mark for 3-methyl, 1 mark for correct punctuation/hyphen.",
                    suggestedTimeMinutes = 3
                ),
                ExamSubQuestion(
                    label = "1.3",
                    questionText = "Explain why butan-1-ol has a significantly higher boiling point than butanal.",
                    marks = 5,
                    memoAnswer = "1. Butan-1-ol contains polar hydroxyl (-OH) groups capable of forming strong intermolecular HYDROGEN BONDS between molecules.  ✓✓\n2. Butanal contains a carbonyl group forming weaker DIPOLE-DIPOLE forces between molecules.  ✓\n3. More thermal energy is required to overcome the stronger hydrogen bonding in butan-1-ol compared to the dipole-dipole interactions in butanal.  ✓✓\nHence butan-1-ol has a higher boiling point.",
                    markingTips = "2 marks for identifying hydrogen bonding in alcohol, 1 mark for dipole-dipole in aldehyde, 2 marks for energy comparison.",
                    suggestedTimeMinutes = 5
                )
            )
        )

        val q2 = ExamQuestion(
            questionNumber = "QUESTION 2",
            topicTitle = "CHEMICAL EQUILIBRIUM & LE CHATELIER'S PRINCIPLE",
            totalMarks = 20,
            contextOrStimulus = "Consider the reversible industrial synthesis of ammonia:\n  N₂(g) + 3H₂(g) ⇌ 2NH₃(g)    ΔH = -92 kJ·mol⁻¹",
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "2.1",
                    questionText = "State Le Chatelier's Principle.",
                    marks = 2,
                    memoAnswer = "When the equilibrium in a closed system is disturbed, the system will reinstate a new equilibrium by favoring the reaction that opposes the disturbance.  ✓✓",
                    markingTips = "2 marks for standard wording.",
                    suggestedTimeMinutes = 2
                ),
                ExamSubQuestion(
                    label = "2.2",
                    questionText = "Predict and explain the effect of increasing temperature on the yield of ammonia (NH₃).",
                    marks = 4,
                    memoAnswer = "1. Increasing temperature favors the ENDOTHERMIC reaction to absorb the added heat energy.  ✓✓\n2. Since the forward reaction is exothermic (ΔH < 0), the reverse endothermic reaction is favored.  ✓\n3. Therefore, the equilibrium shifts to the left and the yield of NH₃ DECREASES.  ✓",
                    markingTips = "2 marks for endothermic rule, 1 mark for reverse direction, 1 mark for decreased yield.",
                    suggestedTimeMinutes = 4
                ),
                ExamSubQuestion(
                    label = "2.3",
                    questionText = "Write down the equilibrium constant expression (Kc) for this reaction.",
                    marks = 2,
                    memoAnswer = "Kc = [NH₃]² / ([N₂] · [H₂]³)  ✓✓",
                    markingTips = "1 mark for numerator powers, 1 mark for denominator powers.",
                    suggestedTimeMinutes = 2
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "ORGANIC CHEMISTRY & INTERMOLECULAR FORCES",
                totalMarks = 25,
                questions = listOf(q1)
            ),
            ExamSection(
                sectionLetter = "SECTION B",
                sectionTitle = "REACTION RATES & CHEMICAL EQUILIBRIUM",
                totalMarks = 20,
                questions = listOf(q2)
            )
        )
    }

    // =========================================================================
    // LIFE SCIENCES PAPER 1 & 2 (Biology)
    // =========================================================================
    private fun getLifeSciencesPaper1Sections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "HUMAN ENDOCRINE SYSTEM & HOMEOSTASIS",
            totalMarks = 20,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "Describe the negative feedback mechanism that regulates high blood glucose levels after a carbohydrate-rich meal.",
                    marks = 6,
                    memoAnswer = "1. Beta cells in the Islets of Langerhans of the pancreas detect elevated blood glucose levels.  ✓\n2. The pancreas secretes the hormone INSULIN into the bloodstream.  ✓\n3. Insulin stimulates body cells to absorb glucose for cellular respiration.  ✓\n4. Insulin stimulates the liver and skeletal muscle cells to convert excess glucose into GLYCOGEN.  ✓\n5. Blood glucose levels decrease back to the normal set-point (approx. 4-6 mmol/L).  ✓\n6. Insulin secretion is inhibited (negative feedback loop complete).  ✓",
                    markingTips = "1 mark per logical sequential step in the negative feedback loop.",
                    suggestedTimeMinutes = 6
                ),
                ExamSubQuestion(
                    label = "1.2",
                    questionText = "Explain the role of ADH (Antidiuretic Hormone) when a student is dehydrated on a hot day.",
                    marks = 5,
                    memoAnswer = "1. Osmoreceptors in the hypothalamus detect high blood osmolarity (low water level).  ✓\n2. The pituitary gland releases more ADH into the blood.  ✓\n3. ADH increases the permeability of the distal convoluted tubules and collecting ducts of the nephrons in kidneys to water.  ✓\n4. More water is reabsorbed back into the bloodstream by osmosis.  ✓\n5. A small volume of concentrated urine is excreted, conserving body water.  ✓",
                    markingTips = "1 mark for hypothalamus detection, 1 mark for pituitary ADH release, 1 mark for collecting duct permeability, 1 mark for reabsorption, 1 mark for concentrated urine.",
                    suggestedTimeMinutes = 5
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "HUMAN PHYSIOLOGY & ENDOCRINE CONTROL",
                totalMarks = 20,
                questions = listOf(q1)
            )
        )
    }

    private fun getLifeSciencesPaper2Sections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "GENETICS, DNA & MEIOSIS",
            totalMarks = 20,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "State THREE differences between DNA and RNA.",
                    marks = 6,
                    memoAnswer = "1. DNA is double-stranded with a double helix; RNA is single-stranded.  ✓✓\n2. DNA contains deoxyribose sugar; RNA contains ribose sugar.  ✓✓\n3. DNA contains nitrogenous base Thymine (T); RNA contains Uracil (U).  ✓✓",
                    markingTips = "2 marks per well-contrasted feature pair.",
                    suggestedTimeMinutes = 5
                ),
                ExamSubQuestion(
                    label = "1.2",
                    questionText = "In pea plants, tall stem (T) is dominant over short stem (t). A heterozygous tall plant is crossed with a homozygous short plant. Use a genetic cross diagram to determine the phenotypic ratio of the offspring.",
                    marks = 6,
                    memoAnswer = "P₁ Phenotype: Heterozygous Tall  ×  Homozygous Short\nP₁ Genotype: Tt  ×  tt  ✓\nMeiosis / Gametes: T , t  and  t , t  ✓\nFertilization (Punnett Square):\n      t     t\nT   [Tt]  [Tt]\nt   [tt]  [tt]  ✓✓\nF₁ Genotypes: 50% Tt, 50% tt\nF₁ Phenotypes: 2 Tall : 2 Short (or 1 Tall : 1 Short)  ✓✓",
                    markingTips = "1 mark for parental genotypes, 1 mark for gametes, 2 marks for Punnett cross, 2 marks for 1:1 phenotype ratio.",
                    suggestedTimeMinutes = 6
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "GENETICS, INHERITANCE & MEIOSIS",
                totalMarks = 20,
                questions = listOf(q1)
            )
        )
    }

    // =========================================================================
    // ENGLISH LANGUAGE & LITERATURE PAPER 1 & 2
    // =========================================================================
    private fun getEnglishPaper1Sections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "READING COMPREHENSION & TEXTUAL ANALYSIS",
            totalMarks = 30,
            contextOrStimulus = "TEXT A: 'The Digital Renaissance of Reading in the 21st Century'\nIn an era dominated by hyper-condensed media and fleeting digital notifications, the ancient habit of deep reading is undergoing a profound metamorphosis. While critics lamented the demise of the physical book, interactive digital libraries and audio literature have democratized storytelling across all socio-economic frontiers...",
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "Refer to paragraph 1. Explain what the author means by 'hyper-condensed media' in the context of the passage.",
                    marks = 2,
                    memoAnswer = "The author refers to short-form, rapid digital content (such as 15-second videos, micro-blogs, and instant notifications) that condense complex thoughts into fleeting, bite-sized snippets.  ✓✓",
                    markingTips = "2 marks for full conceptual understanding of fast-paced short media.",
                    suggestedTimeMinutes = 3
                ),
                ExamSubQuestion(
                    label = "1.2",
                    questionText = "Critically discuss how the author uses diction in lines 4-6 ('profound metamorphosis... democratized storytelling') to persuade the reader.",
                    marks = 4,
                    memoAnswer = "1. 'Profound metamorphosis' evokes imagery of a complete, positive, and organic evolution (similar to a caterpillar becoming a butterfly) rather than mere destruction.  ✓✓\n2. 'Democratized' carries strong egalitarian connotations, persuading the reader that digital media empowers and includes diverse social strata rather than degrading intellectual standards.  ✓✓",
                    markingTips = "2 marks for analysis of metamorphosis, 2 marks for analysis of democratized.",
                    suggestedTimeMinutes = 5
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "COMPREHENSION & CRITICAL LANGUAGE",
                totalMarks = 30,
                questions = listOf(q1)
            )
        )
    }

    private fun getEnglishPaper2Sections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "SHAKESPEAREAN DRAMA & LITERARY ESSAY",
            totalMarks = 25,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "In a structured literary essay of 350-400 words, discuss how unchecked ambition leads to moral decay and psychological collapse in the tragic protagonist.",
                    marks = 25,
                    memoAnswer = "Model Outline & Rubric Marking Guidelines:\n• Introduction (5 marks): Clear thesis statement addressing ambition as a destructive catalyst; introduction of key soliloquies.  ✓\n• Body Paragraph 1 (6 marks): Initial noble state contrasted with yielding to the witches' prophecy and Lady Macbeth's manipulation.  ✓\n• Body Paragraph 2 (6 marks): The moral transgression (regicide of King Duncan) leading to intense guilt, paranoia, and hallucination (dagger and Banquo's ghost).  ✓\n• Body Paragraph 3 (5 marks): Complete desensitization and nihilism ('Tomorrow, and tomorrow, and tomorrow' soliloquy).  ✓\n• Conclusion (3 marks): Synthesis of how untethered ambition destroys moral order and personal soul.  ✓",
                    markingTips = "Content & Thesis: 15 marks. Language, Structure & Textual Quotations: 10 marks.",
                    suggestedTimeMinutes = 25
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "LITERATURE ESSAY & DRAMA ANALYSIS",
                totalMarks = 25,
                questions = listOf(q1)
            )
        )
    }

    // =========================================================================
    // ACCOUNTING & BUSINESS
    // =========================================================================
    private fun getAccountingSections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "FINANCIAL STATEMENTS & LEDGER ADJUSTMENTS",
            totalMarks = 35,
            contextOrStimulus = "Trial Balance extracts of Apex Traders at 28 February:\n• Trade Debtors: R120,000\n• Provision for Bad Debts (current): R4,500\n• Rent Income: R54,000\nAdjustment 1: A debtor owing R2,000 is declared insolvent. Write off as bad debt.\nAdjustment 2: Adjust provision for bad debts to 5% of good debtors.\nAdjustment 3: Rent of R4,500 for March was received in advance.",
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "Calculate the new Provision for Bad Debts at 28 February.",
                    marks = 4,
                    memoAnswer = "Debtors balance after write-off: R120,000 - R2,000 = R118,000  ✓\nNew provision = 5% × R118,000 = R5,900  ✓\nAdjustment: Provision increases by R5,900 - R4,500 = R1,400 (Debited to Provision for Bad Debts Adjustment expense).  ✓✓",
                    markingTips = "1 mark for debtors reduction, 1 mark for 5% calculation, 2 marks for R1,400 adjustment.",
                    suggestedTimeMinutes = 4
                ),
                ExamSubQuestion(
                    label = "1.2",
                    questionText = "Show the General Journal entry for the Rent Income received in advance (Adjustment 3).",
                    marks = 4,
                    memoAnswer = "Debit: Rent Income  R4,500  ✓✓\nCredit: Income Received in Advance (Current Liability)  R4,500  ✓✓\nNarration: Reversal of next financial year's prepaid rent.",
                    markingTips = "2 marks for Debit Rent Income, 2 marks for Credit Deferred Income.",
                    suggestedTimeMinutes = 4
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "FINANCIAL ACCOUNTING & ADJUSTMENTS",
                totalMarks = 35,
                questions = listOf(q1)
            )
        )
    }

    // =========================================================================
    // HISTORY & SOCIAL STUDIES
    // =========================================================================
    private fun getHistorySections(year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "THE COLD WAR: CUBAN MISSILE CRISIS (1962)",
            totalMarks = 30,
            contextOrStimulus = "SOURCE 1A: Extract from President J.F. Kennedy's address to the American public, 22 October 1962:\n'Good evening my fellow citizens. This Government, as promised, has maintained the closest surveillance of the Soviet military buildup on the island of Cuba. Within the past week, unmistakable evidence has established the fact that a series of offensive missile sites is now in preparation on that imprisoned island...'",
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "According to Source 1A, what evidence did the US government discover regarding Soviet activity in Cuba?",
                    marks = 2,
                    memoAnswer = "'Unmistakable evidence of offensive missile sites now in preparation on the island of Cuba.'  ✓✓",
                    markingTips = "2 marks for accurate direct quote or paraphrased evidence.",
                    suggestedTimeMinutes = 2
                ),
                ExamSubQuestion(
                    label = "1.2",
                    questionText = "Explain the term 'quarantine' (naval blockade) used by the United States during this crisis.",
                    marks = 3,
                    memoAnswer = "The US deployed warships to intercept and inspect all Soviet vessels transporting military cargo to Cuba, deliberately calling it a 'quarantine' rather than a 'blockade' because a blockade is technically an act of war under international law.  ✓✓✓",
                    markingTips = "3 marks for full explanation of the legal and military nuance.",
                    suggestedTimeMinutes = 4
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "SOURCE-BASED HISTORICAL INQUIRY",
                totalMarks = 30,
                questions = listOf(q1)
            )
        )
    }

    // =========================================================================
    // DEFAULT GENERAL FALLBACK
    // =========================================================================
    private fun getDefaultGeneralSections(subject: String, year: Int, term: String, grade: String): List<ExamSection> {
        val q1 = ExamQuestion(
            questionNumber = "QUESTION 1",
            topicTitle = "CORE CONCEPTS & TERMINOLOGY",
            totalMarks = 20,
            subQuestions = listOf(
                ExamSubQuestion(
                    label = "1.1",
                    questionText = "Define the central core principles of $subject covered in $term.",
                    marks = 5,
                    memoAnswer = "1. Master all foundational definitions and key domain vocabulary.  ✓✓\n2. Apply appropriate formulas, empirical laws, and structural paradigms.  ✓✓\n3. Provide concise, step-by-step reasoning.  ✓",
                    markingTips = "Full marks for structured conceptual definitions.",
                    suggestedTimeMinutes = 5
                ),
                ExamSubQuestion(
                    label = "1.2",
                    questionText = "Analyze a practical problem scenario relevant to $subject at $grade level.",
                    marks = 15,
                    memoAnswer = "Step 1: Identify given variables and context parameters.  ✓✓✓\nStep 2: Formulate standard analytical model or mathematical equation.  ✓✓✓\nStep 3: Execute step-by-step resolution and verify boundary constraints.  ✓✓✓✓\nStep 4: State final conclusions clearly with units and justification.  ✓✓✓✓✓",
                    markingTips = "Marks awarded for methodical analysis and sound deduction.",
                    suggestedTimeMinutes = 15
                )
            )
        )

        return listOf(
            ExamSection(
                sectionLetter = "SECTION A",
                sectionTitle = "FOUNDATIONAL PRINCIPLES & APPLICATIONS",
                totalMarks = 20,
                questions = listOf(q1)
            )
        )
    }
}
